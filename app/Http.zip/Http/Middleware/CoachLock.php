<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class CoachLock
{
    public function handle(Request $request, Closure $next)
{
    $user = $request->user();
    if (!$user) return redirect()->route('login');

    // Not a coach → force client role and go to apply
    if (!($user->is_coach ?? false)) {
        session(['active_role' => 'client']);
        return redirect()->route('coach.apply');
    }

    $status    = (string) ($user->coach_verification_status ?? 'draft');
    $submitted = (bool) ($user->coach_kyc_submitted ?? false);
    $hasEverSubmitted = $submitted || in_array($status, ['pending','approved','rejected'], true);

    // ❗ NEW FIX: If approved, always send to coach dashboard (never pending page)
    if ($status === 'approved') {
        session(['active_role' => 'coach']);
        return $next($request);
    }

    // For all non-approved cases, lock to client mode
    session(['active_role' => 'client']);

    // Pending & previously submitted → go to locked under-review page
    if ($status === 'pending' && $hasEverSubmitted) {
        return redirect()->route('coach.review');
    }

    // Rejected but coach account exists → resubmit KYC instead of pending page
    if ($status === 'rejected') {
        return redirect()->route('coach.kyc.show');
    }

    // Anything else → go to KYC upload page
    return redirect()->route('coach.kyc.show');
}
}
