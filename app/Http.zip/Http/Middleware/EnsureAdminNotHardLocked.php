<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class EnsureAdminNotHardLocked
{
    public function handle(Request $request, Closure $next)
    {
        $u = $request->user();

        if ($u && in_array($u->role, ['admin','manager'], true)) {
            if ((bool)$u->is_locked) {
                Auth::logout();

                // Redirect to a simple locked screen
                return redirect()->route('admin.locked.notice');
            }
        }

        return $next($request);
    }
}
