<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class AdminOrManager
{
    public function handle(Request $request, Closure $next)
    {
        // ✅ single guard strategy (web)
        $user = auth()->user();

        // Not logged in → go to admin login
        if (! $user) {
            return $this->toAdminLogin($request);
        }

        // Disabled staff → logout & go to admin login with message
        if (! (bool) ($user->is_active ?? true)) {
            auth()->logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();

            return $this->toAdminLogin($request)
                ->withErrors(['email' => __('Your account is disabled.')]);
        }

        // Only admin/manager allowed in /admin
        $role = strtolower((string) ($user->role ?? ''));
        if (! in_array($role, ['admin', 'manager'], true)) {
            // If you prefer redirect instead of 403:
            // return redirect()->route('home');
            abort(403, __('Unauthorized.'));
        }

        return $next($request);
    }

    private function toAdminLogin(Request $request)
    {
        // For ajax/json requests, return proper response instead of redirect
        if ($request->expectsJson()) {
            return response()->json(['message' => 'Unauthenticated.'], 401);
        }

        return redirect()->route('admin.login');
    }
}
