<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as Middleware;

class VerifyCsrfToken extends Middleware
{
    protected $except = [
        'stripe/webhook',        // ✅ no leading slash
        'api/stripe/webhook',    // (optional) in case you hit the API route too
    ];
}
