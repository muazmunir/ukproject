<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class CoachOnboardingGate
{
    public function handle(Request $request, Closure $next)
    {
        $user = $request->user();
        if (!$user) return redirect()->route('login');

        $route = optional($request->route())->getName(); // coach.apply, coach.kyc.show, coach.review, etc.

        $isCoach   = (bool) ($user->is_coach ?? false);
        $status    = (string) ($user->coach_verification_status ?? 'draft');
        $submitted = (bool) ($user->coach_kyc_submitted ?? false);

        // Not a coach: let them access apply/kyc routes normally
        if (!$isCoach) {
            return $next($request);
        }

        // ---------- HARD GUARD FOR REVIEW PAGE ----------
        // Approved must never see review
        if ($route === 'coach.review' && $status === 'approved') {
            session(['active_role' => 'coach']);
            return redirect()->route('coach.home');
        }

        // Only pending should see review
        if ($route === 'coach.review' && $status !== 'pending') {
            session(['active_role' => 'client']);
            return redirect()->route('coach.kyc.show');
        }

        // ---------- FLOW CONTROL ----------
        // Pending: force them onto review (unless already there)
        if ($submitted && $status === 'pending') {
            session(['active_role' => 'client']); // keep locked in client mode while pending
            if ($route !== 'coach.review') {
                return redirect()->route('coach.review');
            }
            return $next($request);
        }

        // Approved: allow onboarding routes, but also allow coach area via coach.lock group
        if ($status === 'approved') {
            // don't force redirect here; just allow
            return $next($request);
        }

        // Draft / rejected: allow apply + kyc routes; block review already handled above
        session(['active_role' => 'client']);
        return $next($request);
    }
}
