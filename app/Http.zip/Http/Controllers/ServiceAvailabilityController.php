<?php
// app/Http/Controllers/ServiceAvailabilityController.php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Service;
use App\Models\CoachWeeklyHour;
use App\Models\CoachUnavailability;
use App\Models\CoachAvailabilityOverride;
use Carbon\CarbonImmutable;
use Carbon\CarbonPeriod;

class ServiceAvailabilityController extends Controller
{
    // ---------- Helpers ----------

    
    private function safeTz(?string $tz, ?string $fallback = null): string
    {
        $fallback = $fallback ?: config('app.timezone', 'UTC');
        $tz = is_string($tz) ? trim($tz) : '';
        try { return $tz ? (new \DateTimeZone($tz))->getName() : $fallback; }
        catch (\Throwable) { return $fallback; }
    }

    /** Does an ISO end with an explicit offset or Z? */
    private function isoHasOffset(string $iso): bool
    {
        return (bool) preg_match('/([+-]\d{2}:\d{2}|Z)$/', $iso);
    }

    /** Parse any ISO string to UTC; respect embedded offset if present */
    private function parseIsoToUtc(string $iso, string $fallbackTz): CarbonImmutable
    {
        return $this->isoHasOffset($iso)
            ? CarbonImmutable::parse($iso)->utc()
            : CarbonImmutable::parse($iso, $fallbackTz)->utc();
    }

    /** Pair of bounds → UTC */
    private function boundsToUtc(string $start, string $end, string $fallbackTz): array
    {
        $a = $this->parseIsoToUtc($start, $fallbackTz);
        $b = $this->parseIsoToUtc($end,   $fallbackTz);
        if ($b->lte($a)) { $b = $a->addMinute(); }
        return [$a, $b];
    }

    /**
     * GET /services/{service}/availability?start=&end=&tz=
     * Returns background events for:
     *  - weekly availability bands (painted in COACH TZ with explicit offset)
     *  - unavailability ranges (stored UTC → Z)
     *  - availability overrides (stored UTC → Z)
     */
    public function show(Request $r, Service $service)
    {
        $coach = $service->coach;
        abort_unless($coach, 404);

        // Coach TZ (authoritative for weekly windows)
        $coachTz = $this->safeTz(
            $coach->timezone
            ?? optional($coach->profile)->timezone
            ?? optional($coach->coachProfile)->timezone
            ?? null
        );

        // Viewer TZ (client) only matters for how start/end query is interpreted if it has no offset
        $viewTz = $this->safeTz($r->query('tz') ?: $coachTz);

        $startQ = $r->query('start');
        $endQ   = $r->query('end');
        if (!$startQ || !$endQ) {
            return response()->json(['message' => 'start/end required'], 422);
        }

        // Visible bounds in UTC; if start/end include an offset, we trust that.
        $visStartUtc = $this->parseIsoToUtc($startQ, $viewTz);
        $visEndUtc   = $this->parseIsoToUtc($endQ,   $viewTz);

        // Pull rows intersecting window
        $un = CoachUnavailability::query()
            ->where('coach_id', $coach->id)
            ->where(function($q) use ($visStartUtc,$visEndUtc) {
                $q->whereBetween('start_utc', [$visStartUtc,$visEndUtc])
                  ->orWhereBetween('end_utc',   [$visStartUtc,$visEndUtc])
                  ->orWhere(function($q2) use ($visStartUtc,$visEndUtc) {
                      $q2->where('start_utc','<=',$visStartUtc)->where('end_utc','>=',$visEndUtc);
                  });
            })->get(['start_utc','end_utc','reason']);

        $ov = CoachAvailabilityOverride::query()
            ->where('coach_id', $coach->id)
            ->where(function($q) use ($visStartUtc,$visEndUtc) {
                $q->whereBetween('start_utc', [$visStartUtc,$visEndUtc])
                  ->orWhereBetween('end_utc',   [$visStartUtc,$visEndUtc])
                  ->orWhere(function($q2) use ($visStartUtc,$visEndUtc) {
                      $q2->where('start_utc','<=',$visStartUtc)->where('end_utc','>=',$visEndUtc);
                  });
            })->get(['start_utc','end_utc','reason']);

        $weekly = CoachWeeklyHour::where('coach_id', $coach->id)
            ->orderBy('weekday')->orderBy('start_time')->get(['weekday','start_time','end_time']);

        $events = [];

        // 1) Weekly availability — paint per day in COACH TZ (emit ISO with offset)
        if ($weekly->count()) {
            $coachDayStart = $visStartUtc->setTimezone($coachTz)->startOfDay();
            $coachDayEnd = $visEndUtc->setTimezone($coachTz)->endOfDay();


            if ($coachDayEnd->gte($coachDayStart)) {
                $period = CarbonPeriod::create($coachDayStart, '1 day', $coachDayEnd);
                foreach ($period as $coachLocalDay) {
                    $weekday = (int) $coachLocalDay->dayOfWeek; // 0..6 in coach TZ
                    foreach ($weekly->where('weekday', $weekday) as $row) {
                        $startLocalCoach = CarbonImmutable::parse($coachLocalDay->format('Y-m-d').' '.$row->start_time, $coachTz);
                        $endLocalCoach   = CarbonImmutable::parse($coachLocalDay->format('Y-m-d').' '.$row->end_time,   $coachTz);
                        if ($endLocalCoach->lte($startLocalCoach)) {
                            // overnight window (cross-midnight)
                            $endLocalCoach = $endLocalCoach->addDay();
                        }

                        $events[] = [
                            'start'      => $startLocalCoach->toIso8601String(), // includes offset like +05:00
                            'end'        => $endLocalCoach->toIso8601String(),
                            'display'    => 'background',
                            'classNames' => ['avail-blue','fc-bg-event'], // matches your CSS
                            'extendedProps' => ['type' => 'weekly'],
                        ];
                    }
                }
            }
        }

        // 2) Unavailability — stored UTC → Z
        foreach ($un as $u) {
            $events[] = [
                'start'      => $u->start_utc->toIso8601String(), // Z
                'end'        => $u->end_utc->toIso8601String(),
                'display'    => 'background',
                'classNames' => ['unavail-red','fc-bg-event'],
                'extendedProps' => ['type' => 'unavailability', 'reason' => $u->reason],
            ];
        }

        // 3) Availability overrides — stored UTC → Z (we’ll still paint them “available”)
        foreach ($ov as $o) {
            $events[] = [
                'start'      => $o->start_utc->toIso8601String(), // Z
                'end'        => $o->end_utc->toIso8601String(),
                'display'    => 'background',
                'classNames' => ['avail-blue','fc-bg-event'],
                'extendedProps' => ['type' => 'override', 'reason' => $o->reason],
            ];
        }

        // Debug payload guard (optional): uncomment if needed
        return response()->json([
            'debug' => compact('coachTz','viewTz','startQ','endQ','visStartUtc','visEndUtc'),
            'events' => $events
          ]);
          

        // return response()->json($events);
    }

    public function day(Request $r, Service $service)
{
    $coach = $service->coach;
    abort_unless($coach, 404);

    $coachTz = $this->safeTz(
        $coach->timezone
        ?? optional($coach->profile)->timezone
        ?? optional($coach->coachProfile)->timezone
        ?? null
    );

    $date = $r->query('date');         // YYYY-MM-DD (coach-local)
    if (!$date) return response()->json(['windows'=>[], 'slots'=>[]], 422);
    
       // NEW: which TZ produced that date string?
       $viewTz = $this->safeTz($r->query('tz') ?: $coachTz);
    
       // Interpret YYYY-MM-DD as midnight in viewer TZ,
       // then convert that instant to coach TZ and take the COACH day bounds.
       $viewMid = \Carbon\CarbonImmutable::createFromFormat('Y-m-d H:i', "$date 00:00", $viewTz);
       $coachMid = $viewMid->setTimezone($coachTz);
       $d0 = $coachMid->startOfDay();
       $d1 = $d0->addDay();

    // --- Package-driven parameters ---
    $hpd  = (float) $r->query('hpd', 0);      // hours per day, e.g. 3.0
    $step = (int)   $r->query('step', 30);    // step minutes between consecutive slots
    if ($step < 5)  $step = 5;
    if ($step % 5)  $step = 30; // normalize to a sane grid
    $slotMinutes = (int) round($hpd * 60);    // full slot length (must fit entirely in availability)

    // Coach-local day bounds
    

    // 1) Weekly windows for that weekday (coach-local)
    $weekday = (int)$d0->dayOfWeek; // 0..6
    $weeklyRows = CoachWeeklyHour::where('coach_id',$coach->id)->where('weekday',$weekday)->get();
    $weekly = [];
    foreach ($weeklyRows as $row) {
       // AFTER (use the mapped coach day)
$ds = $d0->toDateString();
 // coach-local YYYY-MM-DD of the clicked day
$s = CarbonImmutable::parse($ds.' '.$row->start_time, $coachTz);
$e = CarbonImmutable::parse($ds.' '.$row->end_time,   $coachTz);

        if ($e->lte($s)) $e = $e->addDay(); // overnight
        // clip to day
        $s = $s->max($d0); $e = $e->min($d1);
        if ($e->gt($s)) $weekly[] = [$s,$e];
    }

    // 2) Unavailability (DB: UTC) -> coach local segments overlapping day
    $un = CoachUnavailability::where('coach_id',$coach->id)
        ->where(function($q) use($d0,$d1){
            $q->whereBetween('start_utc', [$d0->utc(), $d1->utc()])
              ->orWhereBetween('end_utc',   [$d0->utc(), $d1->utc()])
              ->orWhere(function($q2) use($d0,$d1){
                  $q2->where('start_utc','<=',$d0->utc())->where('end_utc','>=',$d1->utc());
              });
        })->get();
    $unLocal = [];
    foreach ($un as $u) {
        $s = $u->start_utc->setTimezone($coachTz)->max($d0);
        $e = $u->end_utc->setTimezone($coachTz)->min($d1);
        if ($e->gt($s)) $unLocal[] = [$s,$e];
    }

    // 3) Overrides (DB: UTC) -> coach local
    $ov = CoachAvailabilityOverride::where('coach_id',$coach->id)
        ->where(function($q) use($d0,$d1){
            $q->whereBetween('start_utc', [$d0->utc(), $d1->utc()])
              ->orWhereBetween('end_utc',   [$d0->utc(), $d1->utc()])
              ->orWhere(function($q2) use($d0,$d1){
                  $q2->where('start_utc','<=',$d0->utc())->where('end_utc','>=',$d1->utc());
              });
        })->get();
    $ovLocal = [];
    foreach ($ov as $o) {
        $s = $o->start_utc->setTimezone($coachTz)->max($d0);
        $e = $o->end_utc->setTimezone($coachTz)->min($d1);
        if ($e->gt($s)) $ovLocal[] = [$s,$e];
    }

    // helper: subtract blocks from windows
    $subtract = function(array $wins, array $blocks) {
        $out = [];
        foreach ($wins as [$ws,$we]) {
            $segments = [[$ws,$we]];
            foreach ($blocks as [$bs,$be]) {
                $next = [];
                foreach ($segments as [$ss,$se]) {
                    if ($be->lte($ss) || $bs->gte($se)) { $next[] = [$ss,$se]; continue; }
                    if ($bs->gt($ss)) $next[] = [$ss,$bs];
                    if ($be->lt($se)) $next[] = [$be,$se];
                }
                $segments = $next;
                if (!$segments) break;
            }
            foreach ($segments as $seg) if ($seg[1]->gt($seg[0])) $out[] = $seg;
        }
        return $out;
    };

    // Final coach-local free windows: (weekly − unavailability) ∪ overrides
    $weeklyMinusUn = $subtract($weekly, $unLocal);
    $final = array_merge($weeklyMinusUn, $ovLocal);
    usort($final, fn($a,$b) => $a[0] <=> $b[0]);

    // Merge overlapping/touching
    $merged = [];
    foreach ($final as [$s,$e]) {
        if (!$merged) { $merged[] = [$s,$e]; continue; }
        [$ps,$pe] = $merged[count($merged)-1];
        if ($s->lte($pe)) {
            $merged[count($merged)-1] = [$ps, $e->max($pe)];
        } else {
            $merged[] = [$s,$e];
        }
    }

    // --- Emit package-sized rolling windows ---
   // --- Emit package-sized rolling windows ---
$windows = array_map(fn($w)=>[
    'start'=>$w[0]->utc()->toIso8601String(),
    'end'  =>$w[1]->utc()->toIso8601String()
], $merged);

// If no hpd provided, just return windows
if ($slotMinutes <= 0) {
    return response()->json(['windows'=>$windows, 'slots'=>[]]);
}

// Floor to the previous boundary (not ceil), then move forward in steps.
// Generate slots while start <= (e - slotMinutes).
$floorToQuantum = function(CarbonImmutable $t, int $q = 30) {
    $t = $t->setSecond(0);
    $m = $t->minute % $q;
    return $t->subMinutes($m);
};

$slots = [];
foreach ($merged as [$s,$e]) {
    if (!$s instanceof CarbonImmutable) $s = CarbonImmutable::create($s);
    if (!$e instanceof CarbonImmutable) $e = CarbonImmutable::create($e);
    // Normalise seconds to 0 to avoid 00:00:01 drift
    $s = $s->setSecond(0);
    $e = $e->setSecond(0);

    $scan        = $floorToQuantum($s, $step ?: 30);
    $latestStart = $e->subMinutes($slotMinutes);

    // advance scan in step until it’s inside the free window
    while ($scan->lt($s)) {
        $scan = $scan->addMinutes($step);
    }

    while ($scan->lte($latestStart)) {
        $slotEnd = $scan->addMinutes($slotMinutes);
        $slots[] = [
            'start' => $scan->utc()->toIso8601String(),
            'end'   => $slotEnd->utc()->toIso8601String(),
        ];
        $scan = $scan->addMinutes($step);
    }
}
// For debug, capture coach-local ranges in strings
$fmtRangeList = function(array $pairs) use ($coachTz) {
    return array_map(function($p) use ($coachTz) {
        [$s,$e] = $p;
        return [
            's' => $s->setTimezone($coachTz)->format('Y-m-d H:i:s T'),
            'e' => $e->setTimezone($coachTz)->format('Y-m-d H:i:s T'),
        ];
    }, $pairs);
};

$debugCoach = [
    'coachTz'   => $coachTz,
    'viewTz'    => $viewTz ?? null,
    'inputDate' => $date,
    'coachDay'  => [$d0->format('Y-m-d H:i:s T'), $d1->format('Y-m-d H:i:s T')],
    'weekly'    => $fmtRangeList($weekly),
    'unLocal'   => $fmtRangeList($unLocal),
    'ovLocal'   => $fmtRangeList($ovLocal),
    'finalBeforeMerge' => $fmtRangeList(array_merge($weeklyMinusUn, $ovLocal)),
    'merged'    => $fmtRangeList($merged),
    'hpd'       => $hpd,
    'step'      => $step,
];

if ($r->boolean('debug')) {
    return response()->json([
        'debug'   => $debugCoach,
        'windows' => $windows,
        'slots'   => $slots,
    ]);
}


return response()->json(['windows'=>$windows, 'slots'=>$slots]);
}


}



