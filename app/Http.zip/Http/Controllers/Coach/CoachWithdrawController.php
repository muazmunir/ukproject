<?php

namespace App\Http\Controllers\Coach;

use App\Http\Controllers\Controller;
use App\Models\CoachWithdrawal;
use App\Models\CoachPayoutMethod;
use App\Models\Users;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class CoachWithdrawController extends Controller
{
    public function index(Request $request)
    {
        $u = $request->user();
        abort_unless(($u->is_coach ?? false), 403);

        $kycOk = (($u->coach_verification_status ?? null) === 'approved');

        $methods = CoachPayoutMethod::where('coach_id', $u->id)
            ->orderByDesc('is_default')
            ->orderByDesc('id')
            ->get();

        $withdrawals = CoachWithdrawal::where('coach_id', $u->id)
            ->orderByDesc('id')
            ->limit(20)
            ->get();

        $processingMinor = (int) CoachWithdrawal::where('coach_id', $u->id)
            ->where('status','processing')
            ->sum('amount_minor');

        return view('coach.withdraw.index', [
            'u' => $u,
            'kycOk' => $kycOk,
            'withdrawableMinor' => (int)($u->withdrawable_minor ?? 0),
            'processingMinor' => $processingMinor,
            'methods' => $methods,
            'withdrawals' => $withdrawals,
        ]);
    }

    public function storeMethod(Request $request)
    {
        $u = $request->user();
        abort_unless(($u->is_coach ?? false), 403);

        $data = $request->validate([
            'type'  => ['required', Rule::in(['stripe','paypal'])],
            'label' => ['nullable','string','max:40'],
            'email' => ['required','email','max:190'],
            'make_default' => ['nullable','boolean'],
        ]);

        return DB::transaction(function () use ($u, $data) {
            // if making default, clear previous
            $makeDefault = (bool)($data['make_default'] ?? false);

            if ($makeDefault) {
                CoachPayoutMethod::where('coach_id', $u->id)->update(['is_default' => false]);
            }

            // If no methods exist yet, force first to default
            $hasAny = CoachPayoutMethod::where('coach_id', $u->id)->exists();
            $isDefault = $makeDefault || ! $hasAny;

            CoachPayoutMethod::create([
                'coach_id' => $u->id,
                'type' => $data['type'],
                'label' => $data['label'] ?: null,
                'details' => [
                    // For now, we store email (later Stripe Connect will store acct id)
                    'email' => $data['email'],
                ],
                'is_default' => $isDefault,
            ]);

            return back()->with('ok', __('Payout method saved.'));
        });
    }

    public function makeDefault(Request $request, CoachPayoutMethod $method)
    {
        $u = $request->user();
        abort_unless(($u->is_coach ?? false), 403);
        abort_unless($method->coach_id === $u->id, 403);

        return DB::transaction(function () use ($u, $method) {
            CoachPayoutMethod::where('coach_id', $u->id)->update(['is_default' => false]);
            $method->is_default = true;
            $method->save();

            return back()->with('ok', __('Default payout method updated.'));
        });
    }

    public function destroyMethod(Request $request, CoachPayoutMethod $method)
    {
        $u = $request->user();
        abort_unless(($u->is_coach ?? false), 403);
        abort_unless($method->coach_id === $u->id, 403);

        return DB::transaction(function () use ($u, $method) {
            $wasDefault = (bool)$method->is_default;
            $method->delete();

            // If default deleted, pick newest as default
            if ($wasDefault) {
                $next = CoachPayoutMethod::where('coach_id', $u->id)->orderByDesc('id')->first();
                if ($next) {
                    $next->is_default = true;
                    $next->save();
                }
            }

            return back()->with('ok', __('Payout method removed.'));
        });
    }

    public function store(Request $request)
    {
        $u = $request->user();
        abort_unless(($u->is_coach ?? false), 403);

        if (($u->coach_verification_status ?? null) !== 'approved') {
            return back()->with('error', __('Complete KYC before withdrawing.'));
        }

        $data = $request->validate([
            'amount' => ['required','numeric','min:1'],
            'payout_method_id' => ['required','integer'],
        ]);

        $amountMinor = (int) round(((float)$data['amount']) * 100);
        if ($amountMinor < 500) return back()->with('error', __('Minimum withdrawal is $5.00'));

        return DB::transaction(function () use ($u, $data, $amountMinor) {

            $user = Users::lockForUpdate()->find($u->id);

            // ✅ Backend hard-stop: cannot exceed balance
            $available = (int)($user->withdrawable_minor ?? 0);
            if ($amountMinor > $available) {
                return back()->with('error', __('Insufficient withdrawable balance.'));
            }

            $method = CoachPayoutMethod::where('coach_id', $user->id)
                ->where('id', $data['payout_method_id'])
                ->lockForUpdate()
                ->first();

            if (! $method) {
                return back()->with('error', __('Invalid payout method.'));
            }

            // Reserve money immediately
            $user->withdrawable_minor = $available - $amountMinor;
            $user->save();

            CoachWithdrawal::create([
                'coach_id' => $user->id,
                'payout_method_id' => $method->id,

                'amount_minor' => $amountMinor,
                'currency' => 'USD',

                // snapshot for audit
                'method' => $method->type,
                'payout_details' => $method->details,

                'status' => 'processing',
                'requested_at' => now(),
                'release_at' => now()->addDays(7),
            ]);

            return redirect()->route('coach.withdraw.index')
                ->with('ok', __('Withdrawal requested. It will be released automatically within 7 days.'));
        });
    }

  

}
