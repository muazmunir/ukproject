<?php

namespace App\Http\Controllers\Coach;

use App\Http\Controllers\Controller;
use App\Models\Dispute;
use App\Models\DisputeAttachment;
use App\Models\DisputeMessage;
use App\Models\Reservation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;

class CoachDisputeController extends Controller
{
    public function index()
    {
        $uid = (int) auth()->id();

       $disputes = Dispute::with(['reservation.service','reservation.package'])
    ->where('coach_id', $uid)
    ->orderByDesc('last_message_at')
    ->orderByDesc('id')
    ->paginate(10);


        return view('coach.disputes.index', compact('disputes'));
    }

    public function create(Reservation $reservation)
    {
        $uid = (int) auth()->id();

        // coach can only dispute their own reservation
        $coachId = (int) ($reservation->service?->coach_id ?? $reservation->coach_id);
        abort_unless($coachId === $uid, 403);

        // prevent duplicate coach dispute for same reservation
       $dispute = Dispute::where('reservation_id', $reservation->id)->first();
if ($dispute) {
    return redirect()->route('coach.disputes.show', $dispute);
}


        $titles = config('disputes.titles.coach', []);

        return view('coach.disputes.create', compact('reservation','titles'));
    }

    public function store(Request $r, Reservation $reservation)
    {
        $uid = (int) auth()->id();

        $coachId = (int) ($reservation->service?->coach_id ?? $reservation->coach_id);
        abort_unless($coachId === $uid, 403);

        $titles = config('disputes.titles.coach', []);
        $allowedKeys = array_keys($titles);

        $data = $r->validate([
            'title_key'    => ['required', Rule::in($allowedKeys)],
            'description'  => ['required','string','max:5000'],
            'files.*'      => ['nullable','file','max:20480',
                'mimetypes:image/jpeg,image/png,image/webp,video/mp4,video/webm,video/quicktime'
            ],
        ]);

        return DB::transaction(function () use ($reservation, $uid, $data, $r, $titles) {


            $existing = Dispute::where('reservation_id', $reservation->id)
        ->lockForUpdate()
        ->first();

    if ($existing) {
        return redirect()->route('coach.disputes.show', $existing)
            ->with('info', 'This booking is already in dispute.');
    }
            $dispute = Dispute::create([
                'reservation_id' => $reservation->id,

                'opened_by_role'    => 'coach',
                'opened_by_user_id' => $uid,

                'client_id' => $reservation->client_id,
                'coach_id'  => $reservation->service?->coach_id ?? $reservation->coach_id,

                'title_key'   => $data['title_key'],
                'title_label' => $titles[$data['title_key']] ?? $data['title_key'],
                'description' => $data['description'],

                'status' => 'open',
                'last_message_at' => now(),
            ]);

            // initial message
           $msg = DisputeMessage::create([
  'dispute_id'      => $dispute->id,
  'sender_user_id'  => $uid,
  'sender_role'     => 'coach',
  'channel'         => 'coach',
  'message'         => $data['description'],
]);


            // attachments
            if ($r->hasFile('files')) {
                foreach ($r->file('files') as $file) {
                    $path = $file->store("disputes/{$dispute->id}", 'public');

                    DisputeAttachment::create([
                        'dispute_id' => $dispute->id,
                        'message_id' => $msg->id,
                        'disk'       => 'public',
                        'path'       => $path,
                        'filename'   => $file->getClientOriginalName(),
                        'mime'       => $file->getMimeType(),
                        'size'       => $file->getSize(),
                    ]);
                }
            }

            // mark reservation disputed + hold settlement
            $reservation->forceFill([
                'disputed_by_coach_at' => now(),
                'settlement_status'    => 'in_dispute',
            ])->save();

            return redirect()
                ->route('coach.disputes.show', $dispute)
                ->with('success','Dispute submitted. Admin will review.');
        });
    }

 public function show(Dispute $dispute)
{
    $uid = (int) auth()->id();
    abort_unless((int)$dispute->coach_id === $uid, 403);

    $dispute->load([
        'reservation.service.coach',
        'reservation.package',
    ]);

    $messages = DisputeMessage::with(['sender', 'attachments'])
        ->where('dispute_id', $dispute->id)
        ->where(function ($q) {
            $q->where('sender_role', 'coach')
              ->orWhere(function ($q2) {
                  $q2->where('sender_role', 'admin')
                     ->where(function ($q3) {
                         $q3->where('target_role', 'coach')
                            ->orWhere('channel', 'coach'); // fallback if old data
                     });
              });
        })
        ->orderBy('id')
        ->get();

    return view('coach.disputes.show', compact('dispute', 'messages'));
}





    public function message(Request $r, Dispute $dispute)
    {
        $uid = (int) auth()->id();

        abort_unless((int)$dispute->coach_id === $uid, 403);

        $st = strtolower((string)$dispute->status);
abort_unless(in_array($st, ['open','in_review'], true), 403);


        $data = $r->validate([
            'message' => ['nullable','string','max:5000'],
            'files.*' => ['nullable','file','max:20480',
                'mimetypes:image/jpeg,image/png,image/webp,video/mp4,video/webm,video/quicktime'
            ],
        ]);

        if (empty(trim((string)($data['message'] ?? ''))) && !$r->hasFile('files')) {
            return back()->withErrors(['message' => 'Please type a message or attach a file.']);
        }

        return DB::transaction(function () use ($dispute, $uid, $data, $r) {

          $msg = DisputeMessage::create([
    'dispute_id' => $dispute->id,
    'sender_user_id' => $uid,
    'sender_role' => 'coach',
    'channel' => 'coach',
    'message' => $data['message'] ?? null,
]);


            if ($r->hasFile('files')) {
                foreach ($r->file('files') as $file) {
                    $path = $file->store("disputes/{$dispute->id}", 'public');

                    DisputeAttachment::create([
                        'dispute_id' => $dispute->id,
                        'message_id' => $msg->id,
                        'disk'       => 'public',
                        'path'       => $path,
                        'filename'   => $file->getClientOriginalName(),
                        'mime'       => $file->getMimeType(),
                        'size'       => $file->getSize(),
                    ]);
                }
            }

            $dispute->forceFill(['last_message_at' => now()])->save();

            return back()->with('success','Message sent.');
        });
    }
}
