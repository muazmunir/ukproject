<?php

namespace App\Http\Controllers\Coach;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Reservation;
use Carbon\CarbonImmutable;

class CoachDashboardController extends Controller
{
  


    public function messages()       { return view('coach.messages'); }
    public function calendar()       { return view('coach.calendar'); }
    public function services()       { return view('coach.services'); }
    public function bookings()       { return view('coach.bookings'); }
    public function disputes()       { return view('coach.disputes'); }
    public function qualifications() { return view('coach.qualifications'); }

    public function index(Request $request)


    {

        $user = $request->user();               // ✅ ADD THIS
    $coachId = (int) $user->id;  
        

        // Prefer app timezone (or whatever you want). If you truly store everything in UTC, keep 'UTC'.
        $tz  = config('app.timezone', 'UTC');
        $now = CarbonImmutable::now($tz);

        // Inputs
        $range = strtolower((string) $request->query('range', 'lifetime')); // default lifetime
        $from  = $request->query('from');
        $to    = $request->query('to');

        // These help monthly/yearly navigation from UI
        $year  = (int) $request->query('year',  $now->year);
        $month = (int) $request->query('month', $now->month);

        // Optional: for daily navigation (YYYY-MM-DD)
        $day   = $request->query('day'); // ex: 2025-12-23

        // Output label + window
        $periodLabel = 'All time';
        $dateFrom = null;
        $dateTo   = null;

        // Normalize lifetime/all
        if (in_array($range, ['all', 'lifetime'], true)) {
            $range = 'lifetime';
        }

        // If UI sends from/to, treat it as custom regardless
        if ($range === 'custom' || $from || $to) {
            $range = 'custom';
        }

        // Determine date window
        switch ($range) {
            case 'daily': {
                $baseDay = $day
                    ? CarbonImmutable::parse($day, $tz)
                    : $now;

                $dateFrom = $baseDay->startOfDay();
                $dateTo   = $baseDay->endOfDay();
                $periodLabel = $baseDay->format('Y-m-d');
                break;
            }

            case 'weekly': {
                // ISO week (Mon-Sun). Change startOfWeek/endOfWeek if you want Sun-Sat.
                $dateFrom = $now->startOfWeek()->startOfDay();
                $dateTo   = $now->endOfWeek()->endOfDay();
                $periodLabel = $dateFrom->format('Y-m-d') . ' → ' . $dateTo->format('Y-m-d');
                break;
            }

            case 'monthly': {
                $baseMonth = $now->setYear($year)->setMonth($month);
                $dateFrom = $baseMonth->startOfMonth()->startOfDay();
                $dateTo   = $baseMonth->endOfMonth()->endOfDay();
                $periodLabel = $baseMonth->format('F Y');
                break;
            }

            case 'yearly': {
                $baseYear = $now->setYear($year);
                $dateFrom = $baseYear->startOfYear()->startOfDay();
                $dateTo   = $baseYear->endOfYear()->endOfDay();
                $periodLabel = (string) $year;
                break;
            }

            case 'custom': {
                $dateFrom = $from ? CarbonImmutable::parse($from, $tz)->startOfDay() : null;
                $dateTo   = $to   ? CarbonImmutable::parse($to,   $tz)->endOfDay()   : null;

                $periodLabel = trim(
                    ($dateFrom ? $dateFrom->format('Y-m-d') : '…') .
                    ' → ' .
                    ($dateTo ? $dateTo->format('Y-m-d') : '…')
                );
                break;
            }

            case 'lifetime':
            default: {
                // No window
                $dateFrom = null;
                $dateTo   = null;
                $periodLabel = 'All time';
                break;
            }
        }

        // Base query: coach reservations
        $base = Reservation::query()->where('coach_id', $coachId);

        // ✅ Gross/Net: completed reservations filtered by completed_at within window
        $completed = (clone $base)->where('status', 'completed');

        if ($dateFrom) $completed->where('completed_at', '>=', $dateFrom);
        if ($dateTo)   $completed->where('completed_at', '<=', $dateTo);

        $grossMinor = (int) $completed->sum('coach_gross_minor');
        $netMinor   = (int) $completed->sum('coach_earned_minor');

        // ✅ Penalties: sum coach_penalty_minor filtered by cancelled_at/updated_at within window
        $penaltiesQ = (clone $base)->where('coach_penalty_minor', '>', 0);

        if ($dateFrom) {
            $penaltiesQ->where(function ($q) use ($dateFrom) {
                $q->where('cancelled_at', '>=', $dateFrom)
                  ->orWhere('updated_at', '>=', $dateFrom);
            });
        }
        if ($dateTo) {
            $penaltiesQ->where(function ($q) use ($dateTo) {
                $q->where('cancelled_at', '<=', $dateTo)
                  ->orWhere('updated_at', '<=', $dateTo);
            });
        }

        $penaltiesMinor = (int) $penaltiesQ->sum('coach_penalty_minor');

        // Currency
        $currency = (string) (Reservation::where('coach_id', $coachId)->value('currency') ?? 'USD');

        // Recent list (completed + penalized) in same window
        $rows = (clone $base)
            ->when($dateFrom, function ($q) use ($dateFrom) {
                $q->where(function ($qq) use ($dateFrom) {
                    $qq->where('completed_at', '>=', $dateFrom)
                       ->orWhere('cancelled_at', '>=', $dateFrom)
                       ->orWhere('updated_at', '>=', $dateFrom);
                });
            })
            ->when($dateTo, function ($q) use ($dateTo) {
                $q->where(function ($qq) use ($dateTo) {
                    $qq->where('completed_at', '<=', $dateTo)
                       ->orWhere('cancelled_at', '<=', $dateTo)
                       ->orWhere('updated_at', '<=', $dateTo);
                });
            })
            ->orderByDesc('completed_at')
            ->orderByDesc('updated_at')
            ->select([
                'id','status','settlement_status','completed_at',
                'coach_gross_minor','coach_earned_minor','coach_penalty_minor'
            ])
            ->paginate(10);

        // Formatter (minor -> money)
       $fmt = function (int $minor) {
    $amount = number_format($minor / 100, 2);
    return '$' . $amount;
};


        $payload = [
            'currency'    => $currency,
            'periodLabel' => $periodLabel,
            'gross'       => $fmt($grossMinor),
            'net'         => $fmt($netMinor),
            'penalties'   => $fmt($penaltiesMinor),

            // Optional: handy for frontend (so you can show active filter / debug)
            'range'       => $range,
            'dateFrom'    => $dateFrom?->toIso8601String(),
            'dateTo'      => $dateTo?->toIso8601String(),

            'tiles_html'  => view('coach.partials.dashboard_tiles', compact('grossMinor','netMinor','penaltiesMinor','fmt'))->render(),
            'table_html'  => view('coach.partials.dashboard_table', compact('rows','fmt'))->render(),
            'meta_html'   => view('coach.partials.dashboard_meta', compact('currency','periodLabel'))->render(),
        ];

        if ($request->ajax()) {
            return response()->json($payload);
        }

        $coachKycState = ($user->coach_kyc_submitted ?? false)
    ? (string) $user->coach_verification_status
    : null;

        return view('coach.home', compact(
            'coachKycState',
            'grossMinor',
            'netMinor',
            'penaltiesMinor',
            'rows',
            'currency',
            'periodLabel',
            'fmt',
        ));
    }
}
