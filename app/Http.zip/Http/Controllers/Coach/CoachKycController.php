<?php

namespace App\Http\Controllers\Coach;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;



class CoachKycController extends Controller
{
public function show(Request $request)
{
    $user = $request->user();

    if (!($user->is_coach ?? false)) {
        return redirect()->route('coach.apply');
    }

    $submitted = (bool) ($user->coach_kyc_submitted ?? false);
    $status    = (string) ($user->coach_verification_status ?? 'draft');

    if ($submitted && $status === 'pending') {
        return redirect()->route('coach.review');
    }

    if ($status === 'approved') {
        return redirect()->route('coach.home');
    }

    // rejected -> allow resubmit
    // draft -> allow submit
    return view('coach.apply'); // ✅ make a separate blade
}




    public function store(Request $request)
    {
        $user = $request->user();

        // If already approved, block re-submit (optional)
        if ($user->coach_verification_status === 'approved') {
            return back()->with('ok', __('You are already approved as a coach.'));
        }

        // Base validation
        $rules = [
            'profile_photo' => ['required','image','mimes:jpg,jpeg,png,webp','max:4096'],
            'id_type'       => ['required', Rule::in(['passport','driving_license'])],
        ];

        // Conditional validation
        if ($request->id_type === 'passport') {
            $rules['passport_image'] = ['required','image','mimes:jpg,jpeg,png,webp','max:4096'];
        }

        if ($request->id_type === 'driving_license') {
            $rules['dl_front'] = ['required','image','mimes:jpg,jpeg,png,webp','max:4096'];
            $rules['dl_back']  = ['required','image','mimes:jpg,jpeg,png,webp','max:4096'];
        }

        $validated = $request->validate($rules);

        // storage:link should be used
        // Files path: storage/app/public/kyc/coaches/{userId}/...
        $baseDir = "kyc/coaches/{$user->id}";

        // Store profile photo
        $profilePhotoPath = $request->file('profile_photo')->store($baseDir, 'public');

        // Clear previous ID files if re-submitting (optional but clean)
        // We'll only clear the ID files that are not needed anymore
        $passportPath = null;
        $dlFrontPath = null;
        $dlBackPath = null;

        if ($validated['id_type'] === 'passport') {
            $passportPath = $request->file('passport_image')->store($baseDir, 'public');

            // remove old DL files if exist
            if ($user->coach_dl_front) Storage::disk('public')->delete($user->coach_dl_front);
            if ($user->coach_dl_back)  Storage::disk('public')->delete($user->coach_dl_back);
        }

        if ($validated['id_type'] === 'driving_license') {
            $dlFrontPath = $request->file('dl_front')->store($baseDir, 'public');
            $dlBackPath  = $request->file('dl_back')->store($baseDir, 'public');

            // remove old passport file if exist
            if ($user->coach_passport_image) Storage::disk('public')->delete($user->coach_passport_image);
        }

        // remove old profile photo (optional)
        if ($user->coach_profile_photo) {
            Storage::disk('public')->delete($user->coach_profile_photo);
        }
if (! ($user->is_coach ?? false)) {
    $user->is_coach = 1;
}
        // Update user fields
     $user->forceFill([
    'coach_kyc_submitted'        => 1,
    'coach_verification_status' => 'pending',
    'coach_profile_photo'       => $profilePhotoPath,
    'coach_id_type'             => $validated['id_type'],
    'coach_passport_image'      => $passportPath,
    'coach_dl_front'            => $dlFrontPath,
    'coach_dl_back'             => $dlBackPath,
    
])->save();

session(['active_role' => 'coach']);

return redirect()->route('coach.review')
    ->with('ok', __('Your Documents Were Submitted And Are Under Review.'));
     }
    }