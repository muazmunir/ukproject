<?php
// app/Http/Controllers/PaymentController.php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Stripe\StripeClient;
use Carbon\CarbonImmutable;

use App\Models\Service;
use App\Models\ServicePackage;
use App\Models\Reservation;
use App\Models\ReservationSlot;
use App\Models\Payment;
use App\Models\ServiceFee;

class PaymentController extends Controller
{
    private function stripe(): StripeClient {
        return new StripeClient(config('services.stripe.secret'));
    }

    /**
     * Create or update a pending Reservation + PaymentIntent and return its client_secret
     */
    public function createIntent(Request $r)
    {
        $data = $r->validate([
            'service_id'        => ['required','integer','exists:services,id'],
            'package_id'        => ['required','integer','exists:service_packages,id'],
            'client_tz'         => ['nullable','string'],
            'environment'       => ['nullable','string','max:120'],
            'note'              => ['nullable','string','max:2000'],
            'days'              => ['required','array','min:1'],
            'days.*.date'       => ['required','date_format:Y-m-d'],
            'days.*.start'      => ['required','date'],   // ISO 8601 OK
            'days.*.end'        => ['required','date'],
            'payment_intent_id' => ['nullable','string'],
        ]);

        $service  = Service::with('coach')->findOrFail($data['service_id']);
        $package  = ServicePackage::findOrFail($data['package_id']);
        if ($package->service_id !== $service->id) {
    abort(409, 'This package no longer belongs to the selected service.');
}

        $clientTz = $data['client_tz'] ?: config('app.timezone','UTC');

        // ---------- Pricing: base + fees ----------
        // hours
       // ---- TOTAL HOURS (same rules as PayPal) ----
if (!is_null($package->total_hours) && $package->total_hours > 0) {
    $totalHours = (float) $package->total_hours;
} else {
    $totalHours = 0.0;
    foreach ($data['days'] as $d) {
        $start = CarbonImmutable::parse($d['start']);
        $end   = CarbonImmutable::parse($d['end']);
        $minutes = $end->diffInRealMinutes($start, true);
        $totalHours += $minutes / 60;
    }
    $totalHours = round($totalHours, 2);
}


        // base price: prefer package total_price; fallback to hourly_rate * hours
        $base = 0.0;
        if (!is_null($package->total_price) && $package->total_price > 0) {
            $base = (float) $package->total_price;
        } elseif (!is_null($package->hourly_rate) && $package->hourly_rate > 0) {
            $base = (float) $package->hourly_rate * $totalHours;
        }

        // ✅ CLIENT FEES ONLY (same logic as PayPal)
        $clientFeeRow = ServiceFee::where('is_active', true)
            ->where(function ($q) {
                $q->where('party', 'client')
                  ->orWhere('slug', 'client_commission');
            })
            ->first();

        $fees = 0.0;
        if ($clientFeeRow) {
            $fees = $clientFeeRow->type === 'percent'
                ? round($base * ((float) $clientFeeRow->amount / 100), 2)
                : round((float) $clientFeeRow->amount, 2);
        }

        $subtotal       = round($base, 2);              // service price only
        $total          = round($subtotal + $fees, 2);   // what client pays
        $subtotalMinor  = (int) round($subtotal * 100);
        $feesMinor      = (int) round($fees * 100);
        $amountMinor    = (int) round($total * 100);    // Stripe amount

        $stripe = $this->stripe();

        // ---------- Persist reservation + PI ----------
        return DB::transaction(function () use (
            $data, $service, $package, $clientTz,
            $subtotalMinor, $feesMinor, $amountMinor, $totalHours, $stripe
        ) {
            // Try to reuse reservation if a PI already exists and points to one
            $reservation = null;
            if (!empty($data['payment_intent_id'])) {
                try {
                    $pi = $stripe->paymentIntents->retrieve($data['payment_intent_id']);
                    $resIdMeta = $pi->metadata['reservation_id'] ?? null;
                    if ($resIdMeta) {
                        $reservation = Reservation::find($resIdMeta);
                    }
                } catch (\Throwable $e) {
                    // ignore; we'll create a brand new PI
                }
            }

            if (!$reservation) {
                // Create reservation draft
                $reservation = Reservation::create([
                    'service_id'        => $service->id,
                    'package_id'        => $package->id,
                    'client_id'         => auth()->id(),
                    'coach_id'          => $service->coach_id ?? null,
                    'client_tz'         => $clientTz,
                    'environment'       => $data['environment'] ?? null,
                    'note'              => $data['note'] ?? null,

                   'service_title_snapshot' => $service->title,
    'package_name_snapshot'  => $package->name,
    'package_hourly_rate'    => $package->hourly_rate,
    'package_total_price'    => $package->total_price,
    'package_hours_per_day'  => $package->hours_per_day,
    'package_total_days'     => $package->total_days,
    'package_total_hours'    => $package->total_hours,
    'priced_at'              => now(),



                    'currency'          => 'USD',
                    'subtotal_minor'    => $subtotalMinor,
                    'fees_minor'        => $feesMinor,
                    'total_minor'       => $amountMinor,
                    'total_hours'       => $totalHours,
                    'status' => 'pending',

                    'payment_status'    => 'requires_payment',
                    'provider'          => 'stripe',
                ]);

                // Write the selected slots (convert to UTC)
                foreach ($data['days'] as $d) {
                    $startUtc = CarbonImmutable::parse($d['start'])->utc();
                    $endUtc   = CarbonImmutable::parse($d['end'])->utc();

                    ReservationSlot::create([
                        'reservation_id' => $reservation->id,
                        'slot_date'      => $d['date'],
                        'start_utc'      => $startUtc,
                        'end_utc'        => $endUtc,
                    ]);
                }
           } else {
    // Update existing reservation draft with latest pricing + notes
    $reservation->update([
        'client_tz'      => $clientTz,
        'environment'    => $data['environment'] ?? null,
        'note'           => $data['note'] ?? null,

        'subtotal_minor' => $subtotalMinor,
        'fees_minor'     => $feesMinor,
        'total_minor'    => $amountMinor,
        'total_hours'    => $totalHours,

        'status'         => 'pending',
        'payment_status' => 'requires_payment',
        'provider'       => 'stripe',
        'priced_at'      => now(),
    ]);

    // ✅ refresh slots (important if user changes times before paying)
    ReservationSlot::where('reservation_id', $reservation->id)->delete();

    foreach ($data['days'] as $d) {
        ReservationSlot::create([
            'reservation_id' => $reservation->id,
            'slot_date'      => $d['date'],
            'start_utc'      => CarbonImmutable::parse($d['start'])->utc(),
            'end_utc'        => CarbonImmutable::parse($d['end'])->utc(),
        ]);
    }
}


            // Create or update the PaymentIntent
            if (empty($data['payment_intent_id'])) {
                $pi = $stripe->paymentIntents->create([
                    'amount'               => $amountMinor,
                    'currency'             => 'usd',
                    'payment_method_types' => ['card', 'klarna'],
                    'capture_method'       => 'automatic',
                    'metadata'             => [
                        'reservation_id' => (string) $reservation->id,
                        'user_id'        => (string) (auth()->id() ?? 0),
                        'service_id'     => (string) $service->id,
                        'package_id'     => (string) $package->id,
                    ],
                ], [
                    'idempotency_key' => 'pi:new:res-'.$reservation->id,
                ]);
            } else {
                $pi = $stripe->paymentIntents->update($data['payment_intent_id'], [
                    'amount'   => $amountMinor,
                    'metadata' => ['reservation_id' => (string) $reservation->id],
                ]);
            }

            // Store PI on reservation for convenience
            $reservation->update(['payment_intent_id' => $pi->id]);

            return response()->json([
                'payment_intent_id' => $pi->id,
                'client_secret'     => $pi->client_secret,
                'reservation_id'    => $reservation->id,
            ]);
        });
    }

    /**
     * Browser landing page. Webhook is source of truth; this only displays status.
     */
    public function success(Request $r)
    {
        $piId = $r->query('pi');
        if (!$piId) {
            return view('payments.success')->with([
                'status'  => 'unknown',
                'pi_id'   => null,
                'message' => 'Missing PaymentIntent id.',
            ]);
        }

        try {
            $pi = $this->stripe()->paymentIntents->retrieve($piId, []);
        } catch (\Throwable $e) {
            Log::warning('Stripe PI retrieve error on success()', ['e'=>$e->getMessage()]);
            $pi = null;
        }

        $status = $pi->status ?? 'unknown';

        return view('payments.success')->with([
            'status'  => $status,
            'pi_id'   => $piId,
            'message' => $status === 'succeeded'
                ? 'Payment succeeded. Your reservation is confirmed.'
                : ($status === 'processing'
                    ? 'Your payment is processing. You’ll get a confirmation once it succeeds.'
                    : 'We could not confirm the payment yet.'),
        ]);
    }

    /**
     * Stripe → your server. Marks reservation paid and writes a Payment row.
     */
    public function webhook(Request $request)
    {
        // Debug logs (fine for local)
        echo ">>> Webhook received at " . now() . PHP_EOL;
        echo ">>> Stripe-Signature: " . ($request->header('Stripe-Signature') ?? 'none') . PHP_EOL;

        \Log::info('stripe/webhook received', [
            'sig'  => $request->header('Stripe-Signature'),
            'body' => $request->getContent()
        ]);

        $payload = $request->getContent();
        $sig     = $request->header('Stripe-Signature');
        $secret  = config('services.stripe.webhook_secret');

        try {
            $event = \Stripe\Webhook::constructEvent($payload, $sig, $secret);
            echo ">>> Event validated: " . $event->type . PHP_EOL;
        } catch (\Throwable $e) {
            echo ">>> Webhook validation failed: " . $e->getMessage() . PHP_EOL;
            return response('Invalid signature', 400);
        }

        echo ">>> Proceeding with event: " . $event->type . PHP_EOL;

        switch ($event->type) {
            case 'payment_intent.succeeded':
            case 'payment_intent.processing':
            case 'payment_intent.payment_failed': {
                /** @var \Stripe\PaymentIntent $pi */
                $pi = $event->data->object;

                $reservationId = $pi->metadata['reservation_id'] ?? null;
                if (!$reservationId) break;

                DB::transaction(function () use ($pi, $reservationId) {
                    /** @var Reservation|null $res */
                    $res = Reservation::lockForUpdate()->find($reservationId);
                    if (!$res) return;

                    $newPaymentStatus = match ($pi->status) {
                        'succeeded'  => 'paid',
                        'processing' => 'requires_payment',
                        default      => 'failed',
                    };

                    // Upsert payment row (idempotent on provider_payment_id = PI id)
                    $pay = Payment::firstOrNew([
                        'provider'            => 'stripe',
                        'provider_payment_id' => $pi->id,
                    ]);

                    // If a charge exists, capture receipt + method brand
                    $latestChargeId = $pi->latest_charge ?? null;
                    $receipt        = null;
                    $method         = null;

                    if ($latestChargeId) {
                        try {
                            $ch = $this->stripe()->charges->retrieve($latestChargeId);
                            $receipt = $ch->receipt_url ?? null;

                            $details = $ch->payment_method_details ?? null;
                            $brand   = null;

                            if ($details && isset($details->card)) {
                                // Card payment
                                $brand = $details->card->brand ?? null;
                            }

                            // Klarna or other types: use the generic type (e.g. "klarna")
                            $method = strtoupper($brand ?: ($details->type ?? 'card'));
                        } catch (\Throwable $e) {
                            // ignore
                        }
                    }

                    // 🔐 keep payments breakdown in sync with reservation
                    $pay->fill([
                        'reservation_id'         => $res->id,
                        'method'                 => $method ?: 'CARD',
                        'status'                 => $pi->status,
                        'currency'               => strtoupper($pi->currency ?? 'USD'),
                        'amount_total'           => (int) $pi->amount,
                        'provider_charge_id'     => $latestChargeId,
                        'receipt_url'            => $receipt,
                        'succeeded_at'           => $pi->status === 'succeeded' ? now() : $pay->succeeded_at,
                        'meta'                   => json_encode($pi, JSON_UNESCAPED_SLASHES),

                        // 💰 fee breakdown (client side only at this stage)
                        'service_subtotal_minor' => $res->subtotal_minor,
                        'client_fee_minor'       => $res->fees_minor,
                        'coach_fee_minor'        => $pay->coach_fee_minor ?? 0,   // filled later at escrow release
                        'coach_earnings'         => $pay->coach_earnings ?? 0,    // filled later
                        'platform_fee'           => $res->fees_minor + ($pay->coach_fee_minor ?? 0),
                    ]);

                    $pay->save();

                   $isPaid = ($pi->status === 'succeeded');

$res->update([
    'status'            => $isPaid ? 'booked' : 'pending',
    'payment_status'    => $newPaymentStatus,
    'provider'          => 'stripe',
    'payment_intent_id' => $pi->id,
    'booked_at'         => $isPaid ? ($res->booked_at ?? now()) : $res->booked_at,
]);

                });

                break;
            }

            case 'charge.succeeded': {
                /** @var \Stripe\Charge $ch */
                $ch   = $event->data->object;
                $piId = $ch->payment_intent ?? null;
                if (!$piId) break;

                $pi = $this->stripe()->paymentIntents->retrieve($piId);
                $reservationId = $pi->metadata['reservation_id'] ?? null;
                if (!$reservationId) break;

                DB::transaction(function () use ($ch, $pi, $reservationId) {
                    $res = Reservation::lockForUpdate()->find($reservationId);
                    if (!$res) return;

                    $pay = Payment::firstOrNew([
                        'provider'            => 'stripe',
                        'provider_payment_id' => $pi->id,
                    ]);

                    // Detect card vs Klarna (or other) safely
                    $details = $ch->payment_method_details ?? null;
                    $brand   = null;
                    if ($details && isset($details->card)) {
                        $brand = $details->card->brand ?? null;   // e.g. visa, mastercard
                    }
                    $method = strtoupper($brand ?: ($details->type ?? 'card')); // e.g. KLARNA

                    $pay->fill([
                        'reservation_id'         => $res->id,
                        'method'                 => $method,
                        'status'                 => $pi->status,
                        'currency'               => strtoupper($ch->currency ?? 'USD'),
                        'amount_total'           => (int) $ch->amount,
                        'provider_charge_id'     => $ch->id,
                        'receipt_url'            => $ch->receipt_url ?? null,
                        'succeeded_at'           => now(),
                        'meta'                   => json_encode($ch, JSON_UNESCAPED_SLASHES),

                        // keep same breakdown here too
                        'service_subtotal_minor' => $res->subtotal_minor,
                        'client_fee_minor'       => $res->fees_minor,
                        'coach_fee_minor'        => $pay->coach_fee_minor ?? 0,
                        'coach_earnings'         => $pay->coach_earnings ?? 0,
                        'platform_fee'           => $res->fees_minor + ($pay->coach_fee_minor ?? 0),
                    ]);
                    $pay->save();

                $res->update([
    'status'         => 'booked',
    'payment_status' => 'paid',
    'booked_at'      => $res->booked_at ?? now(),
]);

                });

                break;
            }
        }

        return response()->json(['received' => true]);
    }
}
