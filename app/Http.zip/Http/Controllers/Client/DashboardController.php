<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Conversation;
use App\Models\Reservation;
use App\Services\ReservationUiService;

class DashboardController extends Controller
{
    public function home(Request $request, ReservationUiService $ui)
    {
        $user = $request->user();

        // default tab
        $tab = $request->query('tab', 'my');

        // base query (always eager load)
        $q = Reservation::query()
            ->with(['service.coach', 'package', 'slots', 'clientDispute'])
            ->where('client_id', $user->id);

        // keep normal columns + allow subselect aliases
        $q->addSelect('reservations.*');

        // next slot that is NOT completed (used for In Progress ordering)
        $q->selectSub(function ($sub) {
            $sub->from('reservation_slots')
                ->selectRaw('MIN(start_utc)')
                ->whereColumn('reservation_slots.reservation_id', 'reservations.id')
                ->whereRaw("LOWER(TRIM(session_status)) <> 'completed'");
        }, 'next_start_utc');

        // last slot end (used for Completed ordering)
        $q->selectSub(function ($sub) {
            $sub->from('reservation_slots')
                ->selectRaw('MAX(end_utc)')
                ->whereColumn('reservation_slots.reservation_id', 'reservations.id');
        }, 'last_end_utc');

        // -----------------------------
        // TAB FILTERS
        // -----------------------------
        if ($tab === 'refunded') {
            $q->whereIn('settlement_status', ['refunded','refunded_partial'])
              ->orderByDesc('updated_at')
              ->orderByDesc('id');
        }
        elseif ($tab === 'dispute') {
            $q->where(function ($w) {
                $w->whereNotNull('disputed_by_client_at')
                  ->orWhereNotNull('disputed_by_coach_at');
            })
            ->orderByDesc('updated_at')
            ->orderByDesc('id');
        }
        elseif ($tab === 'cancelled') {
            $q->where(function ($w) {
                  $w->whereIn('status', ['cancelled','canceled'])
                    ->orWhereNotNull('cancelled_at');
              })
              ->whereNotIn('settlement_status', ['refunded','refunded_partial'])
              ->orderByDesc('cancelled_at')
              ->orderByDesc('updated_at');
        }
        elseif ($tab === 'completed') {

            $q->where('payment_status', 'paid')

              // exclude refunded
              ->whereNotIn('settlement_status', ['refunded','refunded_partial'])

              // exclude disputes
              ->whereNull('disputed_by_client_at')
              ->whereNull('disputed_by_coach_at')

              // exclude cancelled
              ->where(function ($w) {
                  $w->whereNotIn('status', ['cancelled','canceled'])
                    ->whereNull('cancelled_at');
              })

              // STRICT: every slot must be exactly "completed"
              ->whereHas('slots')
              ->whereDoesntHave('slots', function ($s) {
                  $s->whereRaw("LOWER(TRIM(session_status)) <> 'completed'");
              })

              // sort by last slot end desc
              ->orderByDesc('last_end_utc')
              ->orderByDesc('id');

        }
        elseif ($tab === 'in_progress') {

            $q->where('payment_status', 'paid')

              // exclude refunded
              ->whereNotIn('settlement_status', ['refunded','refunded_partial'])

              // exclude disputes
              ->whereNull('disputed_by_client_at')
              ->whereNull('disputed_by_coach_at')

              // exclude cancelled
              ->where(function ($w) {
                  $w->whereNotIn('status', ['cancelled','canceled'])
                    ->whereNull('cancelled_at');
              })

              // must have slots
              ->whereHas('slots')

              // NOT all slots completed => at least one slot where status != completed
              ->whereHas('slots', function ($s) {
                  $s->whereRaw("LOWER(TRIM(session_status)) <> 'completed'");
              })

              // if coach didn't come or both didn't come, this booking is refund-track
              ->whereDoesntHave('slots', function ($s) {
                  $s->whereIn('session_status', ['no_show_coach', 'no_show_both']);
              })

              // order by next upcoming slot that is NOT completed
              ->orderByRaw('next_start_utc IS NULL')
              ->orderBy('next_start_utc', 'asc')
              ->orderByDesc('id');
        }
        else {
            // "my" = everything (history)
            $q->whereIn('payment_status', ['paid','refunded','partial_refund','refunded_partial','failed','pending'])
              ->orderByDesc('created_at')
              ->orderByDesc('id');
        }

        // one paginator used for ALL tabs
        $bookings = $q->paginate(8)->appends(['tab' => $tab]);

        // timezone for UI calculations
        $tz = $user->timezone ?? config('app.timezone','UTC');

        // attach computed flags for CARD UI
        $bookings->getCollection()->transform(function ($res) use ($tz, $ui) {
            $flags = $ui->postSessionFlags($res, $tz);

            $res->ui_can_complete        = (bool)($flags['canCompleteClient'] ?? false);

            // independent client dispute (base flag + ensure no clientDispute exists)
          $res->ui_can_dispute = (bool)(($flags['canDisputeClientBase'] ?? false) && empty($res->dispute));


            $res->ui_dispute_window_ends = $flags['disputeWindowEnds'] ?? null;
            $res->ui_last_slot_end       = $flags['lastSlotEnd'] ?? null;

            $res->ui_total_slots         = $flags['totalSlots'] ?? 0;
            $res->ui_completed_slots     = $flags['clientCompletedSlots'] ?? 0;
            $res->ui_all_finished        = $flags['allSessionsFinished'] ?? false;

            return $res;
        });

        // optional: keep your old cancelledBookings block for backward compatibility
        $cancelledBookings = ($tab === 'cancelled')
            ? $bookings
            : Reservation::with(['service.coach', 'package', 'slots'])
                ->where('client_id', $user->id)
                ->where(function ($w) {
                    $w->whereIn('status', ['cancelled','canceled'])
                      ->orWhereNotNull('cancelled_at');
                })
                ->orderByDesc('cancelled_at')
                ->orderByDesc('updated_at')
                ->paginate(5, ['*'], 'cancelled_page');

        return view('client.home', [
            'tab'               => $tab,
            'bookings'          => $bookings,
            'cancelledBookings' => $cancelledBookings,
            'tz'                => $tz, // ✅ pass tz if your blade needs it
        ]);
    }

    /**
     * Client messages page (inside client.layout)
     */
    public function messages(Request $request)
    {
        $user = $request->user();

        $conversations = Conversation::with(['service', 'coach', 'client'])
           ->where('client_id', $user->id)

            ->whereHas('messages')
            ->orderByDesc('last_message_at')
            ->orderByDesc('updated_at')
            ->get();

        if ($conversations->isEmpty()) {
            return view('client.messages', [
                'conversations' => $conversations,
                'conversation'  => null,
            ]);
        }

        $activeId = $request->integer('conversation');

        if ($activeId) {
            $conversation = $conversations->firstWhere('id', $activeId) ?? $conversations->first();
        } else {
            $conversation = $conversations->first();
        }

        $conversation->load([
            'service',
            'coach',
            'client',
            'messages.sender',
            'messages.service',
        ]);

        $conversation->messages()
            ->whereNull('read_at')
            ->where('sender_id', '!=', $user->id)
            ->update(['read_at' => now()]);

        return view('client.messages', [
            'conversations' => $conversations,
            'conversation'  => $conversation,
        ]);
    }

    public function disputeCreate()
    {
        return view('client.disputes-create');
    }

    public function disputeIndex()
    {
        return view('client.disputes-index');
    }

    public function profileEdit()
    {
        return view('client.profile-edit');
    }

    public function cancellations()
    {
        return view('client.cancellations');
    }
}
