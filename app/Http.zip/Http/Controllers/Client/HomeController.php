<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Reservation;

class HomeController extends Controller
{
    public function index(Request $request)
    {
        $user  = $request->user();
        $tab   = $request->query('tab', 'my');
        $tz    = $user->timezone ?? config('app.timezone', 'UTC');
        $debug = (bool) $request->boolean('debug', false); // add ?debug=1

        $q = Reservation::with(['service.coach', 'package', 'slots', 'payment', 'clientDispute'])
            ->where('client_id', $user->id)
            ->where('payment_status', 'paid');

        switch ($tab) {

            case 'cancelled':
                $q->where(function ($w) {
                    $w->whereIn('status', ['cancelled','canceled'])
                      ->orWhere('settlement_status', 'cancelled');
                });
                break;

            case 'refunded':
                $q->where(function ($w) {
                    $w->whereIn('settlement_status', ['refunded','refunded_partial'])
                      ->orWhere('refund_total_minor', '>', 0);
                });
                break;

            case 'dispute':
                $q->where(function ($w) {
                    $w->whereNotNull('disputed_by_client_at')
                      ->orWhereNotNull('disputed_by_coach_at')
                      ->orWhere('settlement_status', 'in_dispute');
                });
                break;

            case 'completed':
                // ✅ IMPORTANT: keep ORs grouped (no leak)
                $q->where(function ($w) {
                    $w->where('status', 'completed')
                      ->orWhere('settlement_status', 'settled')
                      ->orWhereHas('slots', function ($s) {
                          $s->whereNotNull('end_utc');
                      });
                });
                break;

            case 'in_progress':
                // ✅ in_progress = has ANY slot NOT in final state
                $q->whereNotIn('status', ['cancelled','canceled'])
                  ->whereNotIn('settlement_status', ['refunded','refunded_partial','cancelled'])
                  ->whereHas('slots', function ($s) {
                      $s->whereRaw("LOWER(TRIM(session_status)) NOT IN (
                          'completed','no_show_coach','no_show_client','no_show_both','cancelled','canceled'
                      )");
                  });
                break;

            case 'my':
            default:
                // ✅ my = active (not cancelled/refunded/dispute)
                $q->whereNotIn('status', ['cancelled','canceled'])
                  ->whereNotIn('settlement_status', ['refunded','refunded_partial','cancelled'])
                  ->whereNull('disputed_by_client_at')
                  ->whereNull('disputed_by_coach_at');
                break;
        }

      
        return view('client.home', compact('tab', 'bookings', 'tz'));
    }
}
