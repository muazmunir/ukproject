<?php

namespace App\Http\Controllers\Client;

use App\Http\Controllers\Controller;
use App\Models\Reservation;
use App\Services\RefundChoiceService;
use Illuminate\Http\Request;

class RefundChoiceController extends Controller
{
    public function choose(Request $request, Reservation $reservation, RefundChoiceService $svc)
    {
        // ✅ security: client can only refund own reservation
        abort_unless((int)$reservation->client_id === (int)$request->user()->id, 403);

        $method = (string)$request->input('refund_method', 'wallet_credit');

        $result = $svc->process($reservation, $method, (int)$request->user()->id);

        // For fetch/ajax
        if ($request->wantsJson()) {
            return response()->json($result, $result['ok'] ? 200 : 422);
        }

        // For normal form post
        return back()->with($result['ok'] ? 'ok' : 'error', $result['message'] ?? 'Refund result updated');
    }
}
