<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Mail\VerifyOtpMail;

use App\Models\Users;
use App\Models\UserVerification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Validation\Rule;
use Illuminate\Support\Str;
use Carbon\Carbon;

class RegisterController extends Controller
{
    public function show() {
        return view('auth.register');
    }

   public function create(Request $request) {
    $data = $request->validate([
        'role' => ['required', Rule::in(['client','coach'])],

        'first_name' => ['required','string','max:100'],
        'last_name'  => ['required','string','max:100'],
        'username'   => ['nullable','string','max:100','unique:users,username'],
        'dob'        => ['nullable','date'],
        'email'      => ['required','email','max:255','unique:users,email'],
        'country'    => ['nullable','string','max:120'],
        'city'       => ['nullable','string','max:120'],
        'phone_code' => ['nullable','string','max:10'],
        'phone'      => ['nullable','string','max:30'],
        'timezone'   => ['nullable','string','max:120'],
        'password'   => ['required','confirmed','min:8'],
        'accept'     => ['accepted'],
    ]);

    $wantsCoach = ($data['role'] === 'coach');

    $user = Users::create([
        // Keep role as "client" (base role). Coach is a capability, not a role.
        'role'       => 'client',

        'is_coach' => $wantsCoach ? 1 : 0,
        'coach_kyc_submitted' => 0,
        'coach_verification_status' => $wantsCoach ? 'draft' : null,

        'first_name' => $data['first_name'],
        'last_name'  => $data['last_name'],
        'username'   => $data['username'] ?? null,
        'dob'        => $data['dob'] ?? null,
        'email'      => $data['email'],
        'country'    => $data['country'] ?? null,
        'city'       => $data['city'] ?? null,
        'phone_code' => $data['phone_code'] ?? null,
        'phone'      => $data['phone'] ?? null,
        'timezone'   => $data['timezone'] ?? null,
        'password'   => Hash::make($data['password']),
        'onboarding_completed' => true,
    ]);
        // Generate OTP
        $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);

      UserVerification::where('user_id', $user->id)
    ->where('purpose', 'register')
    ->delete();

UserVerification::create([
    'user_id' => $user->id,
    'code' => $code,
    'purpose' => 'register',
    'expires_at' => now()->addMinutes(10),
]);


        // Send email
        Mail::to($user->email)->send(new VerifyOtpMail($user, $code));

        // Store pending user id in session to show verify screen
      session([
        'verify_user_id' => $user->id,
        'verify_purpose' => 'register',
        // ✅ where to send after verify
        'post_verify_mode' => $wantsCoach ? 'coach' : 'client',
    ]);

    return redirect()->route('auth.verify.show');
}
}
