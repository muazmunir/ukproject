<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Mail\VerifyOtpMail;
use App\Models\Users;
use App\Models\UserVerification;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use App\Mail\WelcomeMail;
use App\Mail\ClientWelcomeMail;
use App\Mail\CoachUnderReviewMail;



class VerificationController extends Controller
{
    public function show() {
        abort_unless(session()->has('verify_user_id'), 404);

        $user = Users::findOrFail(session('verify_user_id'));
        $purpose = session('verify_purpose', 'register'); // register|login

        return view('auth.verify', compact('user', 'purpose'));
    }

    public function verify(Request $request) {
        $request->validate(['code' => ['required','digits:6']]);

        $userId  = session('verify_user_id');
        $purpose = session('verify_purpose', 'register');

        abort_unless($userId, 404);

        $user = Users::findOrFail($userId);

        $record = UserVerification::where('user_id', $user->id)
            ->where('purpose', $purpose)
            ->where('code', $request->code)
            ->whereNull('used_at')
            ->first();

        if (! $record) {
            return back()->withErrors(['code' => __('Invalid code')]);
        }

        if (now()->greaterThan($record->expires_at)) {
            return back()->withErrors(['code' => __('Code Expired. Request a New One.')]);
        }

        // mark otp as used
        $record->update(['used_at' => now()]);

        // ✅ Only verify email one time (register purpose)
    if ($purpose === 'register' && is_null($user->email_verified_at)) {
    $user->forceFill(['email_verified_at' => now()])->save();

    if ($user->role === 'client') {
        // ✅ Client welcome email
        Mail::to($user->email)->send(new ClientWelcomeMail($user));
    }

   if (($user->is_coach ?? false) || $user->role === 'coach') {
    // only send under review mail if not approved
    if (($user->coach_verification_status ?? 'pending') !== 'approved') {
        Mail::to($user->email)->send(new CoachUnderReviewMail($user));
    }
}

}



        // clear session
        session()->forget(['verify_user_id', 'verify_purpose']);

        // complete login
      Auth::login($user);

$mode = session('post_verify_mode', 'client');

if ($mode === 'coach' && ($user->is_coach ?? false)) {
    session(['active_role' => 'coach']);
    session()->forget(['verify_user_id','verify_purpose','post_verify_mode']);

    // go to KYC first
    if (empty($user->coach_kyc_submitted)) {
        return redirect()->route('coach.kyc.show')
            ->with('status', __('Email Verified. Continue KYC.'));
    }

    return redirect()->route('coach.home')
        ->with('status', __('Email Verified. Welcome!'));
}

// default client
session(['active_role' => 'client']);
session()->forget(['verify_user_id','verify_purpose','post_verify_mode']);

return redirect()->route('client.home')
    ->with('status', __('Email Verified. Welcome!'));

    }

    public function resend() {
        $userId  = session('verify_user_id');
        $purpose = session('verify_purpose', 'register');

        abort_unless($userId, 404);

        $user = Users::findOrFail($userId);

        $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);

        UserVerification::where('user_id', $user->id)
            ->where('purpose', $purpose)
            ->delete();

        UserVerification::create([
            'user_id' => $user->id,
            'code' => $code,
            'purpose' => $purpose,
            'expires_at' => now()->addMinutes(10),
        ]);

        Mail::to($user->email)->send(new VerifyOtpMail($user, $code));

        return back()->with('status', __('Check Your Email For a New Code'));
    }
}

