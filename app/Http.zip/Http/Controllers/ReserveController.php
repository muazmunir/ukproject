<?php
// app/Http/Controllers/ReserveController.php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\CarbonImmutable;

use App\Models\Service;
use App\Models\ServicePackage;
use App\Models\ServiceFee;
use App\Models\Reservation;
use App\Models\ReservationSlot;

use App\Services\WalletService;
use Illuminate\Support\Facades\Mail;
use App\Mail\BookingConfirmedClientMail;
use App\Mail\BookingConfirmedCoachMail;

class ReserveController extends Controller
{
    public function show(Request $r)
    {
        $data = $r->validate([
            'service_id'        => ['required','integer','exists:services,id'],
            'package_id'        => ['required','integer','exists:service_packages,id'],
            'client_tz'         => ['nullable','string'],
            'days'              => ['required','array','min:1'],
            'days.*.date'       => ['required','date_format:Y-m-d'],
            'days.*.start'      => ['required','date'],
            'days.*.end'        => ['required','date'],
        ]);

        $service = Service::with(['coach','packages'])->findOrFail($data['service_id']);
        $package = ServicePackage::findOrFail($data['package_id']);

        if ($package->service_id !== $service->id) {
            abort(409, 'This package no longer belongs to the selected service.');
        }

        $slots = collect($data['days'])->map(function ($d) {
            $start = CarbonImmutable::parse($d['start']);
            $end   = CarbonImmutable::parse($d['end']);

            $minutes = $end->diffInRealMinutes($start, true);
            $hours   = $minutes / 60;

            return [
                'date'  => $d['date'],
                'start' => $start,
                'end'   => $end,
                'hours' => $hours,
            ];
        });

        $totalHours = round($slots->sum('hours'), 2);

        $base = 0.0;
        if (!is_null($package->total_price) && $package->total_price > 0) {
            $base = (float)$package->total_price;
        } elseif (!is_null($package->hourly_rate) && $package->hourly_rate > 0) {
            $base = (float)$package->hourly_rate * $totalHours;
        }

        $fees = ServiceFee::query()
            ->where('is_active', true)
            ->where('party', 'client')
            ->get();

        $feeLines = [];
        $percentSum = 0.0;
        $fixedSum   = 0.0;

        foreach ($fees as $fee) {
            if ($fee->type === 'percent') {
                $val = round($base * ((float)$fee->amount / 100), 2);
                $percentSum += $val;
                $feeLines[] = ['label'=>$fee->label, 'value'=>$val];
            } else {
                $val = round((float)$fee->amount, 2);
                $fixedSum += $val;
                $feeLines[] = ['label'=>$fee->label, 'value'=>$val];
            }
        }

        $subtotal = round($base, 2);
        $clientPlatformFee = round($percentSum + $fixedSum, 2);
        $total = round($subtotal + $clientPlatformFee, 2);

        $pricingSnapshot = [
            'service_title'         => $service->title,
            'package_name'          => $package->name,
            'package_hourly_rate'   => $package->hourly_rate,
            'package_total_price'   => $package->total_price,
            'package_hours_per_day' => $package->hours_per_day,
            'package_total_days'    => $package->total_days,
            'package_total_hours'   => $package->total_hours,
            'subtotal'              => $subtotal,
            'fees'                  => $clientPlatformFee,
            'total'                 => $total,
            'currency'              => 'USD',
            'priced_at'             => now()->toIso8601String(),
        ];

        $environments = is_array($service->environments) ? $service->environments : [];

        return view('reserve.create', [
            'service'      => $service,
            'package'      => $package,
            'clientTz'     => $data['client_tz'] ?? 'UTC',
            'slots'        => $slots,
            'subtotal'     => $subtotal,
            'feeLines'     => $feeLines,
            'clientPlatformFee'=> $clientPlatformFee,
            'total'        => $total,
            'totalHours'   => $totalHours,
            'environments' => $environments,
            'rawDays'      => $data['days'],
            'pricingSnapshot' => $pricingSnapshot,
        ]);
    }

    public function store(Request $r)
    {
        $data = $r->validate([
            'service_id'        => ['required','integer','exists:services,id'],
            'package_id'        => ['required','integer','exists:service_packages,id'],
            'client_tz'         => ['nullable','string'],
            'environment'       => ['nullable','string','max:120'],
            'note'              => ['nullable','string','max:2000'],
            'days'              => ['required','array','min:1'],
            'days.*.date'       => ['required','date_format:Y-m-d'],
            'days.*.start'      => ['required','date'],
            'days.*.end'        => ['required','date'],

            'use_platform_credit'          => ['nullable','boolean'],
            'payable_minor'                => ['required','integer','min:0'],
            'platform_credit_apply_minor'  => ['required','integer','min:0'],
        ]);

        // This endpoint is ONLY for wallet-only checkout (payable = 0)
        if ((int)$data['payable_minor'] > 0) {
            return redirect()->back()->with('error', 'Please select PayPal or Card to pay the remaining amount.');
        }

        if (!$r->boolean('use_platform_credit')) {
            return redirect()->back()->with('error', 'Please enable platform credit to pay with wallet.');
        }

        $service = Service::with('coach')->findOrFail($data['service_id']);
        $package = ServicePackage::findOrFail($data['package_id']);

        if ($package->service_id !== $service->id) {
            return redirect()->back()->with('error', 'Selected package is not valid for this service.');
        }

        // ---- server recompute totals (anti tamper) ----
        // Hours
        $totalHours = 0.0;
        foreach ($data['days'] as $d) {
            $start = CarbonImmutable::parse($d['start']);
            $end   = CarbonImmutable::parse($d['end']);
            $totalHours += $end->diffInRealMinutes($start, true) / 60;
        }
        $totalHours = round($totalHours, 2);

        // Base
        $base = 0.0;
        if (!is_null($package->total_price) && $package->total_price > 0) {
            $base = (float)$package->total_price;
        } elseif (!is_null($package->hourly_rate) && $package->hourly_rate > 0) {
            $base = (float)$package->hourly_rate * $totalHours;
        }
        $base = round($base, 2);

        // Fees (same as show)
        $feesRows = ServiceFee::query()
            ->where('is_active', true)
            ->where('party', 'client')
            ->get();

        $feeTotal = 0.0;
        foreach ($feesRows as $fee) {
            if ($fee->type === 'percent') {
                $feeTotal += round($base * ((float)$fee->amount / 100), 2);
            } else {
                $feeTotal += round((float)$fee->amount, 2);
            }
        }
        $feeTotal = round($feeTotal, 2);

        $total = round($base + $feeTotal, 2);

        $subtotalMinor = (int) round($base * 100);
        $feesMinor     = (int) round($feeTotal * 100);
        $totalMinor    = (int) round($total * 100);

        // Clamp wallet usage to actual total + available balance
        $availMinor = (int) (auth()->user()->platform_credit_minor ?? 0);
        $walletUseMinor = min($totalMinor, $availMinor);

        if ($walletUseMinor <= 0) {
            return redirect()->back()->with('error', 'Insufficient platform credit.');
        }

        // wallet-only requires walletUseMinor == totalMinor
        if ($walletUseMinor !== $totalMinor) {
            return redirect()->back()->with('error', 'Your platform credit is not enough. Please use PayPal/Card for the remaining amount.');
        }

        $clientTz = $data['client_tz'] ?: config('app.timezone','UTC');

        $reservation = null;

        DB::transaction(function () use (
            $data, $service, $package, $clientTz,
            $subtotalMinor, $feesMinor, $totalMinor, $totalHours,
            $walletUseMinor,
            &$reservation
        ) {
            $reservation = Reservation::create([
                'service_id'   => $service->id,
                'package_id'   => $package->id,
                'client_id'    => auth()->id(),
                'coach_id'     => $service->coach_id ?? null,
                'client_tz'    => $clientTz,
                'environment'  => $data['environment'] ?? null,
                'note'         => $data['note'] ?? null,

                'wallet_platform_credit_used_minor' => $walletUseMinor,
                'payable_minor'   => 0,
                'funding_status'  => 'funded',

                // snapshots (important)
                'service_title_snapshot' => $service->title,
                'package_name_snapshot'  => $package->name,
                'package_hourly_rate'    => $package->hourly_rate,
                'package_total_price'    => $package->total_price,
                'package_hours_per_day'  => $package->hours_per_day,
                'package_total_days'     => $package->total_days,
                'package_total_hours'    => $package->total_hours,

                // pricing
                'currency'       => 'USD',
                'subtotal_minor' => $subtotalMinor,
                'fees_minor'     => $feesMinor,
                'total_minor'    => $totalMinor,
                'total_hours'    => $totalHours,
                'priced_at'      => now(),

                // state
                'status'         => 'booked',
                'payment_status' => 'paid',
                'booked_at'      => now(),
                'provider'       => 'wallet',
            ]);

            foreach ($data['days'] as $d) {
                ReservationSlot::create([
                    'reservation_id' => $reservation->id,
                    'slot_date'      => $d['date'],
                    'start_utc'      => CarbonImmutable::parse($d['start'])->utc(),
                    'end_utc'        => CarbonImmutable::parse($d['end'])->utc(),
                ]);
            }

            // Debit platform credit NOW (no hold)
            app(WalletService::class)->debit(
                auth()->id(),
                $walletUseMinor,
                'reservation_paid_wallet',
                $reservation->id,
                null,
                [],
                'USD',
                WalletService::BAL_PLATFORM,
                false // do not allow negative
            );
        });

        // send emails (same idea as PayPalController)
        $reservation->loadMissing(['slots','service','client','coach']);
        $this->sendBookingEmails($reservation);

        return redirect()->route('client.home', ['tab' => 'bookings'])
            ->with('success', 'Booking confirmed using your platform credit.');
    }

    private function sendBookingEmails(Reservation $reservation): void
    {
        $reservation->loadMissing(['slots','service','client','coach']);

        if ($reservation->status !== 'booked' || $reservation->payment_status !== 'paid') return;

        $clientTz = $reservation->client_tz ?: config('app.timezone','UTC');
        $coachTz  = $reservation->coach?->timezone ?: config('app.timezone','UTC');

        $formatSlots = function(string $tz) use ($reservation) {
            return $reservation->slots
                ->sortBy('start_utc')
                ->map(function($slot) use ($tz){
                    $start = CarbonImmutable::parse($slot->start_utc)->setTimezone($tz);
                    $end   = CarbonImmutable::parse($slot->end_utc)->setTimezone($tz);
                    return [
                        'date'  => $start->format('D, d M Y'),
                        'start' => $start->format('h:i A'),
                        'end'   => $end->format('h:i A'),
                    ];
                })->values()->all();
        };

        if (is_null($reservation->client_booking_emailed_at) && $reservation->client?->email) {
            $slotsClient = $formatSlots($clientTz);
            Mail::to($reservation->client->email)->send(new BookingConfirmedClientMail($reservation, $slotsClient, $clientTz));
            $reservation->forceFill(['client_booking_emailed_at' => now()])->save();
        }

        if (is_null($reservation->coach_booking_emailed_at) && $reservation->coach?->email) {
            $slotsCoach = $formatSlots($coachTz);
            Mail::to($reservation->coach->email)->send(new BookingConfirmedCoachMail($reservation, $slotsCoach, $coachTz));
            $reservation->forceFill(['coach_booking_emailed_at' => now()])->save();
        }
    }

    public function reprice(Request $r)
    {
        $r->validate([
            'package_id' => ['required','integer','exists:service_packages,id'],
            'days'       => ['required','array','min:1'],
            'days.*.start' => ['required','date'],
            'days.*.end'   => ['required','date'],
        ]);

        $package = ServicePackage::findOrFail($r->integer('package_id'));
        $hours = collect($r->input('days'))->sum(function($d){
            return max(0, (float) CarbonImmutable::parse($d['end'])->floatDiffInRealHours(CarbonImmutable::parse($d['start'])));
        });

        $base = 0.0;
        if (!is_null($package->total_price) && $package->total_price > 0) $base = (float)$package->total_price;
        elseif (!is_null($package->hourly_rate) && $package->hourly_rate > 0) $base = (float)$package->hourly_rate * $hours;

        $fees = ServiceFee::where('is_active',true)
            ->where('party', 'client')
            ->get();

        $percentSum=0; $fixedSum=0; $lines=[];
        foreach($fees as $f){
            $val = $f->type==='percent' ? round($base * ((float)$f->amount/100),2) : round((float)$f->amount,2);
            $lines[]=['label'=>$f->label,'value'=>$val];
            $f->type==='percent' ? $percentSum+=$val : $fixedSum+=$val;
        }

        $subtotal = round($base,2);
        $total = round($subtotal + $percentSum + $fixedSum,2);

        return response()->json(compact('subtotal','lines','total'));
    }
}
