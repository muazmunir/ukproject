<?php
// app/Http/Controllers/BookingController.php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Reservation;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Log;
use App\Models\ServiceFee;
use App\Services\EscrowService;
 use Carbon\Carbon;
use App\Models\ReservationSlot;
use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\DB;
use App\Services\WalletService;


class BookingController extends Controller
{
    private array $finalStatuses = [
  'completed',
  'no_show_coach',
  'no_show_client',
  'no_show_both',
];

    /**
     * CLIENT: list bookings
     */
 public function clientIndex(Request $r)
{
    $userId = (int) auth()->id();
    $tz = $r->query('tz') ?: (auth()->user()->timezone ?? config('app.timezone','UTC'));
    $tab = $r->query('tab', 'my');

   $q = Reservation::with(['service.coach','package','slots','payment','clientDispute'])
    ->where('client_id', $userId);



   switch ($tab) {

    case 'cancelled':
        $q->where(function ($w) {
            $w->whereIn('status', ['cancelled','canceled'])
              ->orWhere('settlement_status', 'cancelled');
        });
        break;

    case 'refunded':
        $q->where(function ($w) {
            $w->whereIn('settlement_status', ['refunded','refunded_partial'])
              ->orWhere('refund_total_minor', '>', 0);
        });
        break;

    case 'dispute':
        $q->where(function ($w) {
            $w->whereNotNull('disputed_by_client_at')
              ->orWhereNotNull('disputed_by_coach_at')
              ->orWhere('settlement_status', 'in_dispute');
        });
        break;

    case 'completed':
        // ✅ better “completed tab” = money truth
        $q->where(function ($w) {
            $w->where('status', 'completed')
              ->orWhere('settlement_status', 'paid');
        });
        break;

    case 'in_progress':
        // ✅ your current filter is too narrow (only 'in_progress' or 'live')
        // In-progress should mean: has any slot NOT finalized yet
        $q->whereNotIn('status', ['cancelled','canceled'])
          ->whereNotIn('settlement_status', ['refunded','refunded_partial','cancelled'])
          ->whereHas('slots', function ($s) {
              $s->whereRaw("LOWER(TRIM(session_status)) NOT IN (
                  'completed','no_show_coach','no_show_client','no_show_both','cancelled','canceled'
              )");
          });
        break;

    case 'my':
    default:
        $q->whereNotIn('status', ['cancelled','canceled'])
          ->whereNull('disputed_by_client_at')
          ->whereNull('disputed_by_coach_at')
          ->whereNotIn('settlement_status', ['refunded','refunded_partial','cancelled']);
        break;
}

    $reservations = $q->orderByDesc('id')
        ->paginate(8)
        ->withQueryString();

    // attach computed flags for CARD UI
   $reservations->getCollection()->transform(function ($res) use ($tz) {
    $flags = $this->postSessionFlags($res, $tz);

  $res->ui_can_complete = (bool)($flags['canCompleteClient'] ?? false);



    $res->ui_dispute_window_ends = $flags['disputeWindowEnds'];
    $res->ui_last_slot_end       = $flags['lastSlotEnd'];
    $res->ui_total_slots         = $flags['totalSlots'];

    // keep your display counts if you want
    $res->ui_completed_slots     = $flags['clientCompletedSlots']; // matches your logic
    $res->ui_all_finished        = $flags['allSessionsFinished'];

    // ✅ KEY FIX: independent disputes
   $res->ui_can_dispute = (bool)(($flags['canDisputeClientBase'] ?? false) && empty($res->clientDispute));

Log::info('CLIENT_INDEX_BEFORE_VIEW', [
  'count' => $bookings->count(),
  'first_id' => optional($bookings->first())->id,
  'first_ui_can_complete' => optional($bookings->first())->ui_can_complete ?? 'MISSING',
  'first_ui_can_dispute'  => optional($bookings->first())->ui_can_dispute ?? 'MISSING',
  'first_keys' => optional($bookings->first()) ? array_keys($bookings->first()->getAttributes()) : [],
]);

    return $res;
});


    $bookings = $reservations; // keep naming consistent with blade

return view('client.home', compact('bookings','tz','tab'));

}

    /**
     * CLIENT: show booking detail
     */
   public function clientShow(Reservation $reservation)
{
    abort_unless($reservation->client_id === auth()->id(), 403);

   $reservation->load(['service.coach','package','slots','payment','clientDispute']);

    app(\App\Services\EscrowService::class)->autoCompleteIfExpired($reservation);
$reservation->refresh();



    $tz = auth()->user()->timezone
        ?? $reservation->client_tz
        ?? config('app.timezone','UTC');

   $now = now('UTC');


    // latest end time across all slots (this is when the last session ends)
    $lastSlotEnd = $reservation->slots->max('end_utc'); // Carbon because of casts

    // all sessions finished?
    $allSessionsFinished = $lastSlotEnd
        ? $now->greaterThanOrEqualTo($lastSlotEnd)
        : false;

    // 48-hour dispute/completion window: lastSlotEnd + 48h
    $disputeWindowEnds = $lastSlotEnd
        ? $lastSlotEnd->copy()->addHours(48)
        : null;

    $withinDisputeWindow = $disputeWindowEnds
        ? $now->lessThanOrEqualTo($disputeWindowEnds)
        : false;

    // base conditions: paid, not cancelled/completed/disputed
    $isActionableStatus = in_array($reservation->status, ['booked', 'in_escrow', 'confirmed', 'paid']);

    $isPaid             = $reservation->payment_status === 'paid';

    $noDispute = !$reservation->disputed_by_client_at && !$reservation->disputed_by_coach_at;
    $notCompleted = !$reservation->completed_by_client_at && !$reservation->completed_by_coach_at;

    // final flags for UI
  $flags = $this->postSessionFlags($reservation, $tz);

$canComplete = $flags['canCompleteClient'] ?? false;

$canDisputeBase = $flags['canDisputeClientBase'] ?? false;
$canDispute     = $canDisputeBase && empty($reservation->clientDispute);


$lastSlotEnd       = $flags['lastSlotEnd'] ?? null;
$disputeWindowEnds = $flags['disputeWindowEnds'] ?? null;

  // “Raise dispute”

    return view('client.bookings.show', compact(
        'reservation',
        'tz',
        'canComplete',
        'canDispute',
        'lastSlotEnd',
        'disputeWindowEnds'
    ));
}


    /**
     * COACH: list bookings
     */
 public function coachIndex(Request $request)
{
    $coach     = $request->user();
    $activeTab = $request->query('tab', 'my');

    $coachFeePercent = ServiceFee::where('slug', 'coach_commission')
        ->where('is_active', 1)
        ->value('amount') ?? 0;

    $query = Reservation::query()
    ->with(['service.coach','package','client','slots','payment'])
    ->whereHas('service', function ($q) use ($coach) {
        $q->where('coach_id', $coach->id);
    })
    ->withExists([
        'disputes as has_coach_dispute' => function ($q) use ($coach) {
            $q->where('opened_by_role', 'coach')
              ->where('opened_by_user_id', $coach->id);
        },
        'disputes as has_client_dispute' => function ($q) {
            $q->where('opened_by_role', 'client');
        },
    ]);
    // ✅ computed columns for ordering
    $query->addSelect('reservations.*');

    // next slot that is NOT completed (for In Progress ordering)
    $query->selectSub(function ($sub) {
        $sub->from('reservation_slots')
            ->selectRaw('MIN(start_utc)')
            ->whereColumn('reservation_slots.reservation_id', 'reservations.id')
            ->whereRaw("LOWER(TRIM(session_status)) <> 'completed'");
    }, 'next_start_utc');

    // last slot end (for Completed ordering)
    $query->selectSub(function ($sub) {
        $sub->from('reservation_slots')
            ->selectRaw('MAX(end_utc)')
            ->whereColumn('reservation_slots.reservation_id', 'reservations.id');
    }, 'last_end_utc');
    // id of coach's dispute for this reservation
$query->selectSub(function ($sub) use ($coach) {
    $sub->from('disputes')
        ->select('id')
        ->whereColumn('disputes.reservation_id', 'reservations.id')
        ->where('opened_by_role', 'coach')
        ->where('opened_by_user_id', $coach->id)
        ->orderByDesc('id')
        ->limit(1);
}, 'coach_dispute_id');

// id of client's dispute for this reservation (optional but useful)
$query->selectSub(function ($sub) {
    $sub->from('disputes')
        ->select('id')
        ->whereColumn('disputes.reservation_id', 'reservations.id')
        ->where('opened_by_role', 'client')
        ->orderByDesc('id')
        ->limit(1);
}, 'client_dispute_id');


    // -----------------------------
    // TAB FILTERS (Coach)
    // -----------------------------
    switch ($activeTab) {

        case 'refunded':
            $query->whereIn('settlement_status', ['refunded','refunded_partial'])
                  ->orderByDesc('updated_at')
                  ->orderByDesc('id');
            break;

        case 'dispute':
            $query->where(function($x){
                    $x->whereNotNull('disputed_by_client_at')
                      ->orWhereNotNull('disputed_by_coach_at');
                })
                ->orderByDesc('updated_at')
                ->orderByDesc('id');
            break;

        case 'cancelled':
            // ✅ group this, do NOT leak the OR
            $query->where(function ($w) {
                    $w->whereIn('status', ['cancelled','canceled'])
                      ->orWhereNotNull('cancelled_at');
                })
                // cancelled tab should NOT include refunded bookings
                ->whereNotIn('settlement_status', ['refunded','refunded_partial'])
                ->orderByDesc('cancelled_at')
                ->orderByDesc('updated_at');
            break;

        case 'completed':
    $query->where('status', 'completed')
          ->orderByDesc('completed_at')
          ->orderByDesc('id');
    break;


        case 'in_progress':
            $query->where('payment_status', 'paid')
                ->whereNotIn('settlement_status', ['refunded','refunded_partial'])
                ->whereNull('disputed_by_client_at')
                ->whereNull('disputed_by_coach_at')
                ->where(function ($w) {
                    $w->whereNotIn('status', ['cancelled','canceled'])
                      ->whereNull('cancelled_at');
                })
                ->whereHas('slots')

                // ✅ reservation is in progress if at least one slot is NOT completed
                ->whereHas('slots', function($s){
                    $s->whereRaw("LOWER(TRIM(session_status)) <> 'completed'");
                })

                // ✅ refund-track exclusions (coach no-show / both no-show)
                ->whereDoesntHave('slots', function($s){
                    $s->whereIn('session_status', ['no_show_coach','no_show_both']);
                })

                // ✅ next upcoming session first
                ->orderByRaw('next_start_utc IS NULL')
                ->orderBy('next_start_utc', 'asc')
                ->orderByDesc('id');
            break;

        case 'my':
        default:
            // ✅ My Bookings = EVERYTHING for coach (history too)
            $query->orderByDesc('booked_at')
                  ->orderByDesc('created_at');
            break;
    }

    $bookings = $query->paginate(10)->withQueryString();

    $tz = $coach->timezone ?? config('app.timezone','UTC');

  $bookings->getCollection()->transform(function ($res) use ($tz, $coach) {
    $flags = $this->postSessionFlags($res, $tz);

    $res->ui_can_complete = (bool)($flags['canCompleteCoach'] ?? false);
    $res->ui_can_dispute  = (bool)($flags['canDisputeCoachBase'] ?? false) && !((bool)($res->has_coach_dispute ?? false));

    // ✅ DEBUG LOGS
    try {
        $slotStatuses = $res->slots
            ? $res->slots->map(fn($s) => [
                'slot_id' => $s->id,
                'start_utc' => (string) $s->start_utc,
                'end_utc' => (string) $s->end_utc,
                'finalized_at' => (string) $s->finalized_at,
                'session_status' => (string) $s->session_status,
              ])->values()->all()
            : [];

        Log::info('COACH_UI_FLAGS', [
            'coach_id' => $coach->id ?? null,
            'reservation_id' => $res->id,
            'reservation_status' => $res->status,
            'payment_status' => $res->payment_status,
            'settlement_status' => $res->settlement_status,

            'completed_by_coach_at' => $res->completed_by_coach_at,
            'completed_by_client_at' => $res->completed_by_client_at,
            'disputed_by_coach_at' => $res->disputed_by_coach_at,
            'disputed_by_client_at' => $res->disputed_by_client_at,

            'has_coach_dispute' => (bool)($res->has_coach_dispute ?? false),
            'coach_dispute_id' => $res->coach_dispute_id ?? null,

            // flags
            'ui_can_complete' => $res->ui_can_complete,
            'ui_can_dispute' => $res->ui_can_dispute,
            'flags' => $flags,

            // key timestamps
            'lastSlotEnd' => isset($flags['lastSlotEnd']) ? (string)$flags['lastSlotEnd'] : null,
            'disputeWindowEnds' => isset($flags['disputeWindowEnds']) ? (string)$flags['disputeWindowEnds'] : null,
            'withinDisputeWindow' => $flags['withinDisputeWindow'] ?? null,

            // slots
            'slots' => $slotStatuses,
        ]);
    } catch (\Throwable $e) {
        Log::error('COACH_UI_FLAGS_LOG_FAIL', [
            'reservation_id' => $res->id ?? null,
            'err' => $e->getMessage(),
        ]);
    }

    return $res;
});



    return view('coach.bookings.index', [
        'bookings'        => $bookings,
        'activeTab'       => $activeTab,
        'tz'              => $tz,
        'coachFeePercent' => $coachFeePercent,
    ]);
}

    /**
     * COACH: show booking detail.
     * Re-uses same detail blade as client for now.
     */
    public function coachShow(Reservation $reservation)
{
    $coach = auth()->user();

    abort_unless(
        optional($reservation->service)->coach_id === $coach->id,
        403
    );

    $reservation->load(['service.coach','package','slots','payment']);
    app(\App\Services\EscrowService::class)->autoCompleteIfExpired($reservation);
$reservation->refresh();


    $tz = $coach->timezone
        ?? $reservation->client_tz
        ?? config('app.timezone','UTC');

    // same commission % for detail view
    $coachFeePercent = ServiceFee::where('slug', 'coach_commission')
        ->where('is_active', 1)
        ->value('amount') ?? 0;

    return view('coach.bookings.show', compact('reservation','tz','coachFeePercent'));
}



    /**
     * CLIENT: mark booking as complete and release funds to coach wallet
     */
   public function clientComplete(Request $request, Reservation $reservation)
{
    abort_unless($reservation->client_id === auth()->id(), 403);

    $reservation->forceFill(['completed_by_client_at' => now()])->save();

    // ✅ recompute will either hold, or settle if both completed / 48h passed
    app(\App\Services\ReservationSettlementService::class)->recompute($reservation->id);

    return back()->with('ok', __('Marked complete. Settlement will occur when both complete or after 48 hours if no dispute.'));
}

public function coachComplete(Request $request, Reservation $reservation)
{
    $coach = $request->user();
    abort_unless(optional($reservation->service)->coach_id === $coach->id, 403);

    $reservation->forceFill(['completed_by_coach_at' => now()])->save();

    app(\App\Services\ReservationSettlementService::class)->recompute($reservation->id);

    return back()->with('ok', __('Marked complete. Settlement will occur when both complete or after 48 hours if no dispute.'));
}



    /**
     * Cancel (you can use from client or coach, Gate decides)
     */
    public function cancel(Reservation $reservation)
    {
        Gate::authorize('cancel-reservation', $reservation);

        if ($reservation->payment_status === 'paid') {
            return back()->with('error', __('Paid Reservations Require Support To Cancel.'));
        }

        $reservation->update(['status' => 'cancelled']);

        // redirect client to their list – adjust if you add coach cancel route
        return redirect()->route('bookings.index')->with('success', __('Reservation Cancelled.'));
    }


   

private function finalizeSlotIfEnded(ReservationSlot $slot): void
{
    if (! $slot->end_utc) return;

    $now = now('UTC');

    $end = $slot->end_utc instanceof \Carbon\CarbonInterface
        ? $slot->end_utc->copy()->timezone('UTC')
        : \Carbon\Carbon::parse($slot->end_utc, 'UTC');

    if ($now->lt($end)) return;

    $status = trim(strtolower($slot->session_status ?? ''));

    // final states -> nothing to do
    if (in_array($status, $this->finalStatuses, true)) return;

    // ✅ any "active" state that can remain after end should auto-complete
    $autoCompleteStates = ['in_progress', 'live', 'started', 'ongoing'];

    if (in_array($status, $autoCompleteStates, true)) {
        $slot->session_status = 'completed';
        $slot->finalized_at   = $slot->finalized_at ?? now(); // optional but recommended
        $slot->save();
        return;
    }

    // ✅ if it ended but status is empty/unknown, still finalize to completed
    // (prevents stuck bookings due to unexpected strings)
    if ($status === '' || $status === 'booked' || $status === 'confirmed') {
        $slot->session_status = 'completed';
        $slot->finalized_at   = $slot->finalized_at ?? now();
        $slot->save();
    }
}






public function postSessionFlags(Reservation $reservation, $tz = null): array
{
     $now = now('UTC');

    if (! $reservation->relationLoaded('slots')) {
        $reservation->load('slots');
    }

    $slots = $reservation->slots;

    foreach ($slots as $slot) {
        $this->finalizeSlotIfEnded($slot);
    }

    $reservation->load('slots');
    $slots = $reservation->slots;

    $totalSlots = $slots->count();

    $finalEndStates = ['completed','no_show_coach','no_show_client','no_show_both','cancelled','canceled'];

    $finalizedSlots = $slots->filter(fn($s) =>
        in_array(trim(strtolower($s->session_status ?? '')), $finalEndStates, true)
    )->count();

    // ✅ STRICT completed
    $completedSlots = $slots->filter(fn($s) =>
        trim(strtolower($s->session_status ?? '')) === 'completed'
    )->count();

    // ✅ Your rule: client no-show still counts as completed
    $clientCompletedSlots = $slots->filter(fn($s) =>
        in_array(trim(strtolower($s->session_status ?? '')), ['completed','no_show_client'], true)
    )->count();

    $allSessionsFinished        = $totalSlots > 0 && $finalizedSlots === $totalSlots;
    $allSessionsCompleted       = $totalSlots > 0 && $completedSlots === $totalSlots;
    $allSessionsClientCompleted = $totalSlots > 0 && $clientCompletedSlots === $totalSlots;

    // lastSlotEnd for 48h window
  $lastSlotEnd = $slots->max('end_utc');

if ($lastSlotEnd) {
    $lastSlotEnd = $lastSlotEnd instanceof \Carbon\CarbonInterface
        ? $lastSlotEnd->copy()->timezone('UTC')
        : \Carbon\Carbon::parse($lastSlotEnd, 'UTC');
}

$disputeWindowEnds   = $lastSlotEnd ? $lastSlotEnd->copy()->addHours(48) : null;
$withinDisputeWindow = $disputeWindowEnds ? $now->lte($disputeWindowEnds) : false;


    $isPaid       = $reservation->payment_status === 'paid';
    $notCancelled = !in_array($reservation->status, ['cancelled','canceled'], true);

    $settlement = strtolower(trim($reservation->settlement_status ?? ''));
    $notSettled = !in_array($settlement, ['paid','refunded','refunded_partial','cancelled'], true);

    // ✅ Complete button logic (keep your old finished rule if you want)
  // ✅ Complete base (shared rules)
$noDisputeAny = empty($reservation->disputed_by_client_at) && empty($reservation->disputed_by_coach_at);

$canCompleteBase = $notCancelled
    && $isPaid
    && $allSessionsFinished
    && $withinDisputeWindow
    && $noDisputeAny;

// ✅ role-based complete (THIS is the fix)
$canCompleteClient = $canCompleteBase && empty($reservation->completed_by_client_at);
$canCompleteCoach  = $canCompleteBase && empty($reservation->completed_by_coach_at);

    // ✅ Dispute BASE rule for BOTH sides (independent raising)
    // For CLIENT: completed or no_show_client counts.
    // ✅ Dispute BASE rule for BOTH sides (independent raising)
// Client: completed or no_show_client counts, but only if client has NOT marked complete
$canDisputeClientBase = $notCancelled
    && $isPaid
    && $notSettled
    && $allSessionsClientCompleted
    && $withinDisputeWindow
    && empty($reservation->completed_by_client_at); // ✅ hide dispute after client completes

// Coach: strict completed counts, but only if coach has NOT marked complete
$canDisputeCoachBase = $notCancelled
    && $isPaid
    && $notSettled
    && $allSessionsClientCompleted   // ✅ allow completed + no_show_client
    && $withinDisputeWindow
    && empty($reservation->completed_by_coach_at);
  // ✅ hide dispute after coach completes


    return [
        'totalSlots'              => $totalSlots,
        'finalizedSlots'          => $finalizedSlots,
'FLAG_canCompleteClient' => $flagsDbg['canCompleteClient'] ?? 'MISSING',
'FLAG_canDisputeClientBase' => $flagsDbg['canDisputeClientBase'] ?? 'MISSING',
// 'FLAG_keys' => array_keys($flagsDbg),

        'completedSlots'          => $completedSlots,
        'clientCompletedSlots'    => $clientCompletedSlots,

        'allSessionsFinished'     => $allSessionsFinished,
        'allSessionsCompleted'    => $allSessionsCompleted,
        'allSessionsClientCompleted' => $allSessionsClientCompleted,

        'lastSlotEnd'             => $lastSlotEnd,
        'disputeWindowEnds'       => $disputeWindowEnds,
        'withinDisputeWindow' => $withinDisputeWindow,


        'canCompleteClient' => $canCompleteClient,
'canCompleteCoach'  => $canCompleteCoach,
// 'FLAG_keys' => array_keys($flagsDbg),



        // ✅ IMPORTANT: separate base flags
        'canDisputeClientBase'    => $canDisputeClientBase,
        'canDisputeCoachBase'     => $canDisputeCoachBase,
    ];
}




public function cancelPaidBooking(Request $request, Reservation $reservation, WalletService $wallet)
{
    $user = $request->user();

    // who can cancel? client or coach of that reservation
    $isClient = ((int)$reservation->client_id === (int)$user->id);
   $coachId = (int) optional($reservation->service)->coach_id;

$isCoach = $coachId && $coachId === (int)$user->id;


    if (! $isClient && ! $isCoach) abort(403);

    // already cancelled/settled?
    if (in_array($reservation->status, ['cancelled','canceled'], true)) {
        return back()->with('error', 'This reservation is already cancelled.');
    }

    // must be paid (otherwise your old cancel() can handle)
    if ($reservation->payment_status !== 'paid') {
        return back()->with('error', 'Only paid reservations use this cancellation policy.');
    }

    $request->validate([
        'reason' => ['nullable','string','max:2000'],
    ]);

    return DB::transaction(function () use ($reservation, $wallet, $isClient, $isCoach, $request) {

        $reservation->loadMissing(['slots','payment','service']);

        // Determine first slot start (UTC)
        $firstStart = $reservation->first_slot_start_utc
            ? CarbonImmutable::parse($reservation->first_slot_start_utc)->utc()
            : ($reservation->slots->min('start_utc')
                ? CarbonImmutable::parse($reservation->slots->min('start_utc'))->utc()
                : null);

        if (! $firstStart) {
            return back()->with('error', 'Cannot cancel: first slot time is missing.');
        }

        $now = CarbonImmutable::now('UTC');

        // Cancellation allowed only BEFORE first slot starts
        if ($now->gte($firstStart)) {
            return back()->with('error', 'Cancellation is not allowed after the first slot has started.');
        }

        // safety: if any check-in happened, block cancellation
        $anyCheckin = $reservation->slots->contains(fn($s) => $s->client_checked_in_at || $s->coach_checked_in_at);
        if ($anyCheckin) {
            return back()->with('error', 'Cancellation is not allowed after any session check-in.');
        }

        $subtotal = (int)$reservation->subtotal_minor; // service price
        $fees     = (int)$reservation->fees_minor;     // platform fee charged to client
        $total    = (int)$reservation->total_minor;    // subtotal+fees

        $hoursUntil = $now->diffInRealHours($firstStart, false); // positive
        // windows:
        $band = $hoursUntil >= 48 ? '48_plus' : ($hoursUntil >= 24 ? '24_48' : '0_24');

        $actor = $isClient ? 'client' : 'coach';

        // outputs
        $refundToClient = 0;
        $clientPenalty = 0;
        $coachPenalty  = 0;
        $platformEarned= 0;

        if ($band === '48_plus') {
            // anyone cancels: full refund, no coach charge
            $refundToClient = $total;
            $platformEarned = 0;
        }

        if ($band === '24_48') {
            if ($actor === 'coach') {
                // coach cancels: client full refund, coach charged 10% of service
                $refundToClient = $total;
                $coachPenalty   = (int) round($subtotal * 0.10);
                $platformEarned = $coachPenalty;
            } else {
                // client cancels: client pays platform +10% service, rest refunded
                $clientPenalty  = $fees + (int) round($subtotal * 0.10);
                $refundToClient = max(0, $total - $clientPenalty);
                $platformEarned = $clientPenalty;
            }
        }

        if ($band === '0_24') {
            if ($actor === 'coach') {
                // coach cancels: client full refund, coach charged 20% of service
                $refundToClient = $total;
                $coachPenalty   = (int) round($subtotal * 0.20);
                $platformEarned = $coachPenalty;
            } else {
                // client cancels: client pays platform +20% service, rest refunded
                $clientPenalty  = $fees + (int) round($subtotal * 0.20);
                $refundToClient = max(0, $total - $clientPenalty);
                $platformEarned = $clientPenalty;
            }
        }

        // wallet movements
        $paymentId = $reservation->payment?->id;

        if ($refundToClient > 0) {
            $wallet->credit(
                (int)$reservation->client_id,
                $refundToClient,
                'cancel_refund',
                $reservation->id,
                $paymentId,
                ['band' => $band, 'actor' => $actor]
            );
        }

        if ($coachPenalty > 0 && $coachId) {
            $wallet->debit(
    $coachId,
    $coachPenalty,
    'cancel_penalty_coach',
    $reservation->id,
    $paymentId,
    ['band' => $band, 'actor' => $actor]
);

        }

        // NOTE: clientPenalty is not a wallet debit because the client already paid via provider.
        // We account it via reservation platform_earned_minor + reduced refund.

        // mark reservation cancelled + analytics snapshot
        $reservation->forceFill([
            'status'               => 'cancelled',
            'cancelled_at'         => now(),
            'cancelled_by'         => $actor,
            'cancel_reason'        => $request->input('reason'),

            'settlement_status'    => 'cancelled',
            'refund_total_minor'   => $refundToClient,
            'client_penalty_minor' => $clientPenalty,
            'coach_penalty_minor'  => $coachPenalty,
            'platform_earned_minor'=> $platformEarned,
            'coach_earned_minor'   => 0,

            'first_slot_start_utc' => $reservation->first_slot_start_utc ?? $firstStart,
        ])->save();

        // mark slots cancelled so they don't get processed
        foreach ($reservation->slots as $slot) {
            $slot->session_status = 'cancelled';
            $slot->finalized_at   = $slot->finalized_at ?? now();
            $slot->save();
        }

        return redirect()->back()->with('success', 'Booking cancelled according to policy. Refund/penalties applied to wallet.');
    });
}
}

