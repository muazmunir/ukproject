<?php

namespace App\Http\Controllers;

use App\Models\SupportConversation;
use App\Models\SupportMessage;
use App\Models\SupportConversationRating;
use App\Services\SupportAssignmentService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class SupportConversationController extends Controller
{
    /**
     * Resolve current active support scope role from session.
     * Must match your role switcher logic.
     */
    protected function activeScopeRole(Request $request): string
    {
        $user = $request->user();

        $scopeRole = session('active_role') ?: ($user->role ?? 'client');
        $scopeRole = in_array($scopeRole, ['client', 'coach'], true) ? $scopeRole : 'client';

        return $scopeRole;
    }

    /**
     * Try to assign an admin to a conversation if missing.
     * - only assigns if conversation is open
     * - writes a system message meta.event=admin_assign
     */
    protected function tryAssignAdminIfNeeded(SupportConversation $conversation, SupportAssignmentService $assigner): void
    {
        if ($conversation->status !== 'open') return;
        if (!empty($conversation->assigned_admin_id)) return;

        DB::transaction(function () use ($conversation, $assigner) {
            $locked = SupportConversation::where('id', $conversation->id)
                ->lockForUpdate()
                ->first();

            if (!$locked) return;
            if ($locked->assigned_admin_id) return;
            if ($locked->status !== 'open') return;

            $adminId = $assigner->pickAdminId();
            if (!$adminId) return;

            $locked->assigned_admin_id = $adminId;
            $locked->save();

            $locked->load('assignedAdmin');

            $adminName = trim(($locked->assignedAdmin->first_name ?? '') . ' ' . ($locked->assignedAdmin->last_name ?? ''));
            if ($adminName === '') $adminName = $locked->assignedAdmin->email ?? 'Support';

            SupportMessage::create([
                'support_conversation_id' => $locked->id,
                'sender_id'               => $adminId,
                'sender_type'             => 'system',
                'body'                    => '',
                'type'                    => 'system',
                'meta'                    => [
                    'event'      => 'admin_assign',
                    'admin_id'   => $adminId,
                    'admin_name' => $adminName,
                ],
            ]);
        });
    }

    /**
     * Get the "current thread" for this user + scope.
     * Prefers open conversation's thread_id; else latest conversation thread_id.
     */
    protected function getActiveThreadIdForScope(int $userId, string $scopeRole): ?string
    {
        $open = SupportConversation::where('user_id', $userId)
            ->where('scope_role', $scopeRole)
            ->where('status', 'open')
            ->orderByDesc('id')
            ->first();

        if ($open?->thread_id) return (string) $open->thread_id;

        $latest = SupportConversation::where('user_id', $userId)
            ->where('scope_role', $scopeRole)
            ->orderByDesc('id')
            ->first();

        return $latest?->thread_id ? (string) $latest->thread_id : null;
    }

    public function index(Request $request, SupportAssignmentService $assigner)
    {
        $user = $request->user();
        $scopeRole = $this->activeScopeRole($request);

        // ✅ Rating gate: if there is any resolved conversation in this scope with rating_required=1
        // user must rate it before sending NEW messages.
        $conversationNeedingRating = SupportConversation::where('user_id', $user->id)
            ->where('scope_role', $scopeRole)
            ->where('status', 'resolved')
            ->where('rating_required', 1)
            ->orderByDesc('id')
            ->first();

        // Determine thread_id to display
        $threadId = null;

        if ($conversationNeedingRating && $conversationNeedingRating->thread_id) {
            // force display this thread so user can rate
            $threadId = (string) $conversationNeedingRating->thread_id;
        } else {
            $threadId = $this->getActiveThreadIdForScope($user->id, $scopeRole);
        }

        // No thread yet => render empty support view
        if (!$threadId) {
            return view('support.index', [
                'conversation'   => null,
                'history'        => collect(),
                'events'         => collect(),
                'hasAdminReply'  => false,
                'canRateNow'     => false,
                'scopeRole'      => $scopeRole,
                'threadId'       => null,
            ]);
        }

        // ✅ Get all conversation rows under this thread (this is your "previous chat remains there")
        $history = SupportConversation::where('user_id', $user->id)
            ->where('scope_role', $scopeRole)
            ->where('thread_id', $threadId)
            ->orderBy('id', 'asc')
            ->get();

        // Current conversation row = latest open if exists, else latest in thread
        $conversation = $history->where('status', 'open')->sortByDesc('id')->first()
            ?: $history->sortByDesc('id')->first();

        // ✅ If there is an open conversation, try assign admin (so it can appear in agent queue properly)
        if ($conversation && $conversation->status === 'open') {
            $this->tryAssignAdminIfNeeded($conversation, $assigner);
            $conversation->refresh();
        }

        // Load relations for display
        $conversation?->load(['assignedAdmin', 'manager']);

        // ✅ Pull ALL messages across the whole thread
        $conversationIds = $history->pluck('id')->all();

        $allMessages = SupportMessage::query()
            ->with('sender')
            ->whereIn('support_conversation_id', $conversationIds)
            ->orderBy('id', 'asc')
            ->get();

        $allRatings = SupportConversationRating::query()
            ->with('ratedAdmin')
            ->whereIn('support_conversation_id', $conversationIds)
            ->orderBy('id', 'asc')
            ->get();

        $events = collect();

        foreach ($allMessages as $msg) {
            $type  = $msg->type ?? 'message';
            $event = (string) data_get($msg->meta, 'event');

            if ($type === 'system') {
                // normalize system events
                if (in_array($event, ['agent_taken', 'admin_assign'], true)) {
                    $events->push((object)[
                        'type' => 'admin_assign',
                        'at'   => $msg->created_at,
                        'model'=> (object)[
                            'name' => data_get($msg->meta, 'admin_name', data_get($msg->meta, 'agent_name', 'Support')),
                        ],
                    ]);
                    continue;
                }

                if ($event === 'manager_requested') {
                    $events->push((object)[
                        'type' => 'manager_requested',
                        'at'   => $msg->created_at,
                        'model'=> (object)[ 'name' => data_get($msg->meta, 'agent_name', 'Support') ],
                    ]);
                    continue;
                }

                if ($event === 'manager_assigned') {
                    $events->push((object)[
                        'type' => 'manager_assigned',
                        'at'   => $msg->created_at,
                        'model'=> (object)[
                            'name' => data_get($msg->meta, 'manager_name', 'Manager'),
                        ],
                    ]);
                    continue;
                }

                if ($event === 'manager_joined') {
                    $events->push((object)[
                        'type' => 'manager_joined',
                        'at'   => $msg->created_at,
                        'model'=> (object)[ 'name' => data_get($msg->meta, 'manager_name', 'Manager') ],
                    ]);
                    continue;
                }

                if ($event === 'manager_ended') {
                    $events->push((object)[
                        'type' => 'manager_ended',
                        'at'   => $msg->created_at,
                        'model'=> (object)[ 'name' => data_get($msg->meta, 'manager_name', 'Manager') ],
                    ]);
                    continue;
                }

                $events->push((object)[
                    'type' => 'system',
                    'at'   => $msg->created_at,
                    'model'=> (object)[ 'text' => __('System update') ],
                ]);
                continue;
            }

            $events->push((object)[
                'type'  => 'message',
                'at'    => $msg->created_at,
                'model' => $msg,
            ]);
        }

        foreach ($allRatings as $rating) {
            $events->push((object)[
                'type'  => 'rating',
                'at'    => $rating->created_at,
                'model' => $rating,
            ]);
        }

        $events = $events->sortBy('at')->values();

        // helpers for UI
        $hasAdminReply = $allMessages->contains(fn ($m) => in_array($m->sender_type, ['admin','manager'], true));

        $canRateNow = false;
        if ($conversationNeedingRating) {
            $alreadyRated = SupportConversationRating::where('support_conversation_id', $conversationNeedingRating->id)
                ->where('user_id', $user->id)
                ->exists();

            $canRateNow = !$alreadyRated;
        }

        return view('support.index', [
            'conversation'   => $conversation, // latest row (open preferred)
            'history'        => $history,      // all rows in thread
            'events'         => $events,       // merged timeline
            'hasAdminReply'  => $hasAdminReply,
            'canRateNow'     => $canRateNow,
            'scopeRole'      => $scopeRole,
            'threadId'       => $threadId,     // ✅ important for blade + polling
        ]);
    }

    public function storeMessage(Request $request, SupportAssignmentService $assigner)
    {
        $user = $request->user();
        $scopeRole = $this->activeScopeRole($request);

        $baseData = $request->validate([
            'conversation_id' => ['nullable', 'integer'],
            'thread_id'       => ['nullable', 'string'], // ✅ NEW (blade will send)
            'widget'          => ['nullable'],
            'body'            => ['required', 'string', 'max:5000'],
        ]);

        // Rating gate: block if there is a resolved conversation needing rating in this scope
        $needsRating = SupportConversation::where('user_id', $user->id)
            ->where('scope_role', $scopeRole)
            ->where('status', 'resolved')
            ->where('rating_required', 1)
            ->orderByDesc('id')
            ->first();

        if ($needsRating) {
            return redirect()->route('support.conversation.index')
                ->with('error', __('Please rate the resolved conversation before sending another message.'));
        }

        $conversation = null;
        $threadId = null;

        // If thread_id was sent, prefer it
        if (!empty($baseData['thread_id'])) {
            $threadId = (string) $baseData['thread_id'];
        }

        // If a conversation_id is sent, validate ownership/scope and use its thread_id
        if (!empty($baseData['conversation_id'])) {
            $existing = SupportConversation::where('id', $baseData['conversation_id'])
                ->where('user_id', $user->id)
                ->where('scope_role', $scopeRole)
                ->first();

            if ($existing) {
                $threadId = $threadId ?: (string) ($existing->thread_id ?: '');
                // only write into it if it's open
                if ($existing->status === 'open') {
                    $conversation = $existing;
                }
            }
        }

        // If no open conversation chosen, get latest in thread, else create or reuse open
        if (!$conversation) {
            if ($threadId) {
                $latestInThread = SupportConversation::where('user_id', $user->id)
                    ->where('scope_role', $scopeRole)
                    ->where('thread_id', $threadId)
                    ->orderByDesc('id')
                    ->first();

                if ($latestInThread && $latestInThread->status === 'open') {
                    $conversation = $latestInThread;
                } else {
                    // create a NEW conversation row for this thread (so it re-enters agent queue)
                    $conversation = SupportConversation::create([
                        'user_id' => $user->id,
                        'scope_role' => $scopeRole,
                        'thread_id' => $threadId ?: (string) Str::uuid(),
                        'user_type' => $user->role ?? null,
                        'status' => 'open',
                        'last_message_at' => null,
                        'assigned_admin_id' => null,

                        'manager_id' => null,
                        'manager_requested_at'=> null,
                        'manager_requested_by'=> null,
                        'manager_joined_at' => null,
                        'manager_ended_at' => null,

                        'closed_at' => null,
                        'closed_by' => null,
                        'closed_by_role' => null,
                        'rating_required' => 0,
                        'auto_closed' => 0,
                    ]);
                }
            } else {
                // no thread yet => create first conversation + new thread
                $conversation = SupportConversation::create([
                    'user_id' => $user->id,
                    'scope_role' => $scopeRole,
                    'thread_id' => (string) Str::uuid(),
                    'user_type' => $user->role ?? null,
                    'status' => 'open',
                    'last_message_at' => null,
                    'assigned_admin_id' => null,

                    'manager_id' => null,
                    'manager_requested_at'=> null,
                    'manager_requested_by'=> null,
                    'manager_joined_at' => null,
                    'manager_ended_at' => null,

                    'closed_at' => null,
                    'closed_by' => null,
                    'closed_by_role' => null,
                    'rating_required' => 0,
                    'auto_closed' => 0,
                ]);
            }
        }

        // Write message into current open conversation row
        SupportMessage::create([
            'support_conversation_id' => $conversation->id,
            'sender_id'               => $user->id,
            'sender_type'             => $scopeRole, // 'client' or 'coach'
            'body'                    => $baseData['body'],
            'type'                    => 'message',
            'meta'                    => null,
        ]);

        $conversation->update([
            'last_message_at' => now(),
        ]);

        // Assign after message exists
        $this->tryAssignAdminIfNeeded($conversation, $assigner);

        return redirect()->route('support.conversation.index')
            ->with('ok', __('Your message has been sent.'));
    }

    public function latest(Request $request)
    {
        $user = $request->user();
        $scopeRole = $this->activeScopeRole($request);

        $data = $request->validate([
            'thread_id'       => ['nullable', 'string'],   // ✅ NEW (preferred)
            'conversation_id' => ['nullable', 'integer'],  // ✅ backward compatible
            'after_id'        => ['nullable', 'integer'],
        ]);

        $threadId = $data['thread_id'] ?? null;

        // Backward compat: derive thread_id from conversation_id
        if (!$threadId && !empty($data['conversation_id'])) {
            $c = SupportConversation::where('id', $data['conversation_id'])
                ->where('user_id', $user->id)
                ->where('scope_role', $scopeRole)
                ->first();

            $threadId = $c?->thread_id ? (string) $c->thread_id : null;
        }

        if (!$threadId) {
            return response()->json([
                'ok'   => true,
                'html' => '',
                'last' => $data['after_id'] ?? null,
            ]);
        }

        // Get all conversations in this thread for this scope
        $convIds = SupportConversation::where('user_id', $user->id)
            ->where('scope_role', $scopeRole)
            ->where('thread_id', $threadId)
            ->pluck('id')
            ->all();

        if (empty($convIds)) {
            return response()->json([
                'ok'   => true,
                'html' => '',
                'last' => $data['after_id'] ?? null,
            ]);
        }

        $q = SupportMessage::query()
            ->with('sender')
            ->whereIn('support_conversation_id', $convIds)
            ->orderBy('id', 'asc');

        if (!empty($data['after_id'])) {
            $q->where('id', '>', (int)$data['after_id']);
        }

        $messages = $q->get();

        if ($messages->isEmpty()) {
            return response()->json([
                'ok'   => true,
                'html' => '',
                'last' => $data['after_id'] ?? null,
            ]);
        }

        $html = '';

        foreach ($messages as $msg) {
            $type  = $msg->type ?? 'message';
            $event = (string) data_get($msg->meta, 'event');

            if ($type === 'system') {
                if ($event === 'admin_assign') {
                    $name = (string) data_get($msg->meta, 'admin_name', 'Support');

                    $html .= '
                      <div class="zv-chat-system-row">
                        <div class="zv-chat-system-pill">
                          <i class="bi bi-person-workspace me-1"></i>
                          '.e(__('This conversation is now handled by')).'
                          <strong>'.e($name).'</strong>
                        </div>
                      </div>
                    ';
                    continue;
                }

                if ($event === 'manager_requested') {
                    $html .= '
                      <div class="zv-chat-system-row">
                        <div class="zv-chat-system-pill">
                          <i class="bi bi-exclamation-circle me-1"></i>
                          '.e(__('A manager has been requested for this conversation.')).'
                        </div>
                      </div>
                    ';
                    continue;
                }

                if ($event === 'manager_assigned') {
                    $name = (string) data_get($msg->meta, 'manager_name', 'Manager');

                    $html .= '
                      <div class="zv-chat-system-row">
                        <div class="zv-chat-system-pill">
                          <i class="bi bi-person-badge me-1"></i>
                          '.e(__('A manager has been assigned to this conversation.')).'
                          <strong>'.e($name).'</strong>
                        </div>
                      </div>
                    ';
                    continue;
                }

                if ($event === 'manager_joined') {
                    $name = (string) data_get($msg->meta, 'manager_name', 'Manager');

                    $html .= '
                      <div class="zv-chat-system-row">
                        <div class="zv-chat-system-pill">
                          <i class="bi bi-person-check me-1"></i>
                          '.e(__('Manager joined')).':
                          <strong>'.e($name).'</strong>
                        </div>
                      </div>
                    ';
                    continue;
                }

                if ($event === 'manager_ended') {
                    $name = (string) data_get($msg->meta, 'manager_name', 'Manager');

                    $html .= '
                      <div class="zv-chat-system-row">
                        <div class="zv-chat-system-pill">
                          <i class="bi bi-person-x me-1"></i>
                          '.e(__('Manager session ended by')).'
                          <strong>'.e($name).'</strong>
                        </div>
                      </div>
                    ';
                    continue;
                }

                $html .= '
                  <div class="zv-chat-system-row">
                    <div class="zv-chat-system-pill">
                      <i class="bi bi-info-circle me-1"></i>
                      '.e(__('System Update')).'
                    </div>
                  </div>
                ';
                continue;
            }

            $html .= view('support._message', ['msg' => $msg])->render();
        }

        return response()->json([
            'ok'   => true,
            'html' => $html,
            'last' => $messages->last()->id,
        ]);
    }

    public function rate(Request $request, SupportConversation $conversation)
    {
        $user = $request->user();
        $scopeRole = $this->activeScopeRole($request);

        if ((int)$conversation->user_id !== (int)$user->id) abort(403);
        if (($conversation->scope_role ?? null) !== $scopeRole) abort(403);

        if ($conversation->status !== 'resolved' || !$conversation->rating_required) {
            return back()->with('error', __('This Conversation Does Not Require Rating.'));
        }

        $data = $request->validate([
            'stars'    => ['required', 'integer', 'min:1', 'max:5'],
            'feedback' => ['nullable', 'string', 'max:5000'],
        ]);

        $agentId = $conversation->closed_by;
        if (!$agentId) {
            return back()->with('error', __('Unable To Rate: No Support Agent Was Assigned.'));
        }

        $alreadyRated = SupportConversationRating::where('support_conversation_id', $conversation->id)
            ->where('user_id', $user->id)
            ->exists();

        if ($alreadyRated) {
            return back()->with('ok', __('You Already Rated This Conversation.'));
        }

        SupportConversationRating::create([
            'support_conversation_id' => $conversation->id,
            'user_id'                 => $user->id,
            'admin_id'                => $agentId,
            'stars'                   => $data['stars'],
            'feedback'                => $data['feedback'] ?? null,
        ]);

        $conversation->update([
            'rating_required' => 0,
        ]);

        return back()->with('ok', __('Thanks For Your Rating!'));
    }
}
