<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RoleSwitchController extends Controller
{
    /**
     * POST /role/switch
     * body: role=client|coach
     */
    public function switch(Request $request)
    {
        $user = $request->user();
        if (! $user) {
            return redirect()->route('login');
        }

        $role = strtolower(trim((string) $request->input('role', 'client')));

        // ✅ Staff accounts cannot use marketplace role switching
        if (in_array(strtolower((string)($user->role ?? '')), ['admin','manager','super_admin'], true)) {
            // keep them in admin panel
            session(['panel' => 'admin']);
            session()->forget('active_role');

            return redirect()->route('admin.dashboard');
        }

        // ✅ Only allow marketplace roles
        if (! in_array($role, ['client', 'coach'], true)) {
            return back()->with('error', 'Invalid role.');
        }

        // ---- CLIENT MODE ----
        if ($role === 'client') {
            session(['active_role' => 'client']);
            session()->forget('panel'); // optional: leaving admin context
            $request->session()->migrate(true);

            return redirect()->route('client.home')
                ->with('success', 'Switched to Client mode.');
        }

        // ---- COACH MODE ----
        if ($role === 'coach') {

            // 1) If user never started coach onboarding -> do not enter coach mode
            if (!($user->is_coach ?? false)) {
                session(['active_role' => 'client']);
                $request->session()->migrate(true);
                return redirect()->route('coach.apply');
            }

            $status    = (string) ($user->coach_verification_status ?? 'draft');
            $submitted = (bool) ($user->coach_kyc_submitted ?? false);

            // 2) Only approved coaches can enter coach mode
            if ($status === 'approved') {
                session(['active_role' => 'coach']);
                $request->session()->migrate(true);

                return redirect()->route('coach.home')
                    ->with('success', 'Switched to Coach mode.');
            }

            // 3) Not approved yet -> keep client mode, but send to onboarding
            session(['active_role' => 'client']);
            $request->session()->migrate(true);

            if ($submitted && $status === 'pending') {
                return redirect()->route('coach.review')
                    ->with('success', 'Your coach profile is under review.');
            }

            return redirect()->route('coach.kyc.show')
                ->with('success', 'Continue coach verification.');
        }

        return redirect()->route('client.home');
    }
}
