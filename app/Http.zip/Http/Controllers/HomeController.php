<?php

// app/Http/Controllers/HomeController.php
namespace App\Http\Controllers;
use App\Models\ServiceCategory;
use App\Models\Service;
use App\Models\ServiceFavorite;

class HomeController extends Controller
{
  public function index()
    {
        // Latest active services from all coaches for the home feed
        $services = Service::active()
            ->where('is_approved', 1)
            ->with([
                // Coach: only real columns from users table
                'coach:id,first_name,last_name,avatar_path,city,country',

                // Favorites relation on Service model
                // (will be used by $service->is_favorited accessor / contains check)
                'favorites',

                // Packages
                'packages:id,service_id,total_price,hourly_rate',
            ])
            ->latest('services.created_at')
            ->take(12)
            ->get();

       $categories = ServiceCategory::query()
    ->where('is_active', 1)
    ->where('show_in_scrollbar', 1)
    ->orderBy('sort_order')
    ->orderBy('name')
    ->get();


        // keep the var name simple and consistent with the partial
        return view('home.index', compact('services', 'categories'));
    }

}

