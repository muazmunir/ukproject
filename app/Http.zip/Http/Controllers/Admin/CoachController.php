<?php
// app/Http/Controllers/Admin/CoachController.php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Users;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use App\Mail\CoachApprovedMail;
use App\Mail\CoachRejectedMail;
use App\Services\AdminSecurity\AdminRiskService;


class CoachController extends Controller
{
   

public function index(Request $r)
{
    $q      = trim((string) $r->input('q'));
    $status = $r->input('status', 'all'); // all|active|pending|rejected|deleted
    $per    = (int) $r->input('per', 10);
    if (!in_array($per, [10,20,50,100], true)) $per = 10;

    // base = normal (non-deleted) coaches
   $base = Users::query()->where('is_coach', 1);


    // 👉 main query (depends on status)
    if ($status === 'deleted') {
        $query = Users::onlyTrashed()->where('role', 'coach');
    } else {
        $query = clone $base;
    }

    $coaches = $query
        ->when($q, function ($x) use ($q) {
            $x->where(function ($y) use ($q) {
                $y->where('first_name','like',"%$q%")
                  ->orWhere('last_name','like',"%$q%")
                  ->orWhere('email','like',"%$q%")
                  ->orWhere('phone','like',"%$q%");
            });
        })
       ->when($status !== 'all' && $status !== 'deleted', function ($x) use ($status) {
    return match ($status) {
        'active'   => $x->where('coach_verification_status', 'approved'),
        'pending'  => $x->where('coach_verification_status', 'pending'),
        'rejected' => $x->where('coach_verification_status', 'rejected'),
        default    => $x,
    };
})

        ->orderByDesc('is_approved')
        ->orderBy('first_name')
        ->paginate($per)
        ->appends(['q'=>$q,'status'=>$status,'per'=>$per]);

    // counts for segmented badges
  $counts = [
    'all'      => (clone $base)->count(),
    'active'   => (clone $base)->where('coach_verification_status', 'approved')->count(),
    'pending'  => (clone $base)->where('coach_verification_status', 'pending')->count(),
    'rejected' => (clone $base)->where('coach_verification_status', 'rejected')->count(),
    'deleted'  => Users::onlyTrashed()->where('is_coach', 1)->count(),
];


    $deactCount = 0;

    return view('admin.coaches.index', compact('coaches','q','status','counts','deactCount','per'));
}


   public function approve(Users $user)
{
    // allow approving anyone who applied as coach
    abort_unless(($user->is_coach ?? false) == true || ($user->coach_kyc_submitted ?? false) == true, 404);

    $wasApproved = ((string) $user->coach_verification_status === 'approved');

    $user->forceFill([
        'is_coach'                  => 1,
        'role'                      => 'coach',   // ✅ set role on approval
        'is_approved'               => 1,         // optional legacy
        'approved_at'               => now(),
        'coach_verification_status' => 'approved',
    ])->save();

    if (! $wasApproved) {
        Mail::to($user->email)->send(new CoachApprovedMail($user));
    }

    return back()->with('ok', 'Coach approved.');
}


  public function reject(Users $user)
{
    abort_unless(($user->is_coach ?? false) == true || ($user->coach_kyc_submitted ?? false) == true, 404);

    $wasRejected = ((string) $user->coach_verification_status === 'rejected');

    $user->forceFill([
        'is_approved'               => -1,        // optional legacy
        'approved_at'               => null,
        'coach_verification_status' => 'rejected',
        // keep role as-is or force back to client:
        'role'                      => 'client',  // ✅ optional
        // you can keep is_coach = 1 so they can resubmit, OR set it 0 to remove coach ability:
        // 'is_coach' => 0,
    ])->save();

    if (! $wasRejected) {
        Mail::to($user->email)->send(new CoachRejectedMail($user));
    }

    return back()->with('ok', 'Coach Rejected.');
}



  public function destroy(Users $user, AdminRiskService $risk)
{
    abort_unless($user->role === 'coach', 404);

    DB::transaction(function () use ($user, $risk) {
        $user->delete(); // soft delete

        // ✅ log + threshold check (3 in 3 min / 10 in 24h)
        $adminId = (int) auth()->id();
        $risk->recordUserDeletion($adminId, (int) $user->id, 'coach');
    });

    return back()->with('ok', 'Coach Removed.');
}



// make sure SoftDeletes is enabled on Users model

public function restore($id, AdminRiskService $risk)
{
    $user = Users::onlyTrashed()->findOrFail($id);

    // ✅ Safety: only coaches can be restored here
    abort_unless($user->role === 'coach', 404);

    DB::transaction(function () use ($user, $risk) {
        // restore coach
        $user->restore();

        // ✅ LOG RESTORE ACTION
        $risk->recordUserRestore(auth()->id(), $user);
    });

    return back()->with('ok', 'Coach Restored Successfully.');
}
public function show($id)
{
    $user = Users::withTrashed()->findOrFail($id);

    // Make sure this user has coach ability (applied or approved)
    abort_unless(($user->is_coach ?? false) == true, 404, 'Coach profile not found.');

    return view('admin.coaches.show', compact('user'));
}



}
