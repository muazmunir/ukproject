<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Dispute;
use App\Models\DisputeMessage;
use App\Models\Reservation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Services\WalletService;
use App\Services\ReservationSettlementService;

class AdminDisputeController extends Controller
{
    /**
     * GET /admin/disputes
     * ?status=open|in_review|resolved|rejected
     * ?q=...
     */
  public function index(Request $request)
{
    $status = $request->query('status'); // open|in_review|resolved|rejected
    $q      = trim((string) $request->query('q', ''));

    $rows = Dispute::query()
        ->with(['reservation.service', 'reservation.client', 'reservation.service.coach'])
        ->when($status, fn($qq) => $qq->where('status', $status))
        ->when($q !== '', function ($qq) use ($q) {
            $qq->where(function ($w) use ($q) {
                if (ctype_digit($q)) {
                    $w->orWhere('id', (int)$q)
                      ->orWhere('reservation_id', (int)$q)
                      ->orWhere('opened_by_user_id', (int)$q)
                      ->orWhere('taken_by_admin_id', (int)$q);
                }

                $w->orWhere('title_label', 'like', "%{$q}%")
                  ->orWhere('status', 'like', "%{$q}%")
                  ->orWhere('opened_by_role', 'like', "%{$q}%")
                  ->orWhereHas('reservation.service', fn($s) => $s->where('title','like',"%{$q}%"))
                  ->orWhereHas('reservation.client', fn($c) => $c->where('name','like',"%{$q}%"))
                  ->orWhereHas('reservation.service.coach', fn($c) => $c->where('name','like',"%{$q}%"));
            });
        })
        ->orderByRaw("FIELD(status,'open','in_review','rejected','resolved')")
        ->orderByDesc('last_message_at')
        ->paginate(15)
        ->withQueryString();

    return view('admin.disputes.index', compact('rows'));
}


public function takeReservation(Request $request, int $reservationId)
{
    $admin = $request->user();
    abort_unless($admin && ($admin->role ?? null) === 'admin', 403);
    if ($this->isReservationFinalized($reservationId)) {
    return back()->with('error', 'This dispute is finalized. You cannot take it.');
}


   return DB::transaction(function () use ($admin, $reservationId) {

    $dispute = Dispute::where('reservation_id', $reservationId)
        ->lockForUpdate()
        ->first();

    if (!$dispute) return back()->with('error', 'Dispute not found.');

    if (!empty($dispute->taken_by_admin_id)) {
        return back()->with('error', 'This dispute is already taken by another admin.');
    }

    $dispute->forceFill([
        'taken_by_admin_id' => (int)$admin->id,
        'taken_at'          => now(),
        'status'            => $dispute->status === 'open' ? 'in_review' : $dispute->status,
        'updated_at'        => now(),
    ])->save();

    return back()->with('ok', 'Dispute taken. You can now handle it.');
});
}

    /**
     * GET /admin/disputes/{dispute}
     * Show 2-column chat: client thread vs coach thread
     * (thread column does NOT exist; split by sender_role)
     */
 public function show(Dispute $dispute)
{
    $dispute->load([
        'reservation.service',
        'reservation.client',
        'reservation.service.coach',
        'messages.sender',
        'messages.attachments',
    ]);

   $clientMessages = $dispute->messages
    ->filter(fn($m) => ($m->channel === 'client') || ($m->target_role === 'client'))
    ->values();

$coachMessages = $dispute->messages
    ->filter(fn($m) => ($m->channel === 'coach') || ($m->target_role === 'coach'))
    ->values();


    $adminId = (int) auth()->id();
    $isTakenByMe = (int)($dispute->taken_by_admin_id ?? 0) === $adminId;
    $isTaken = !empty($dispute->taken_by_admin_id);

    $takenByName = null;
    if ($isTaken) {
        $takenByName = \App\Models\Users::find((int)$dispute->taken_by_admin_id)?->name;
    }

    $finalized = $this->isReservationFinalized((int)$dispute->reservation_id);

    return view('admin.disputes.show', compact(
        'dispute',
        'clientMessages',
        'coachMessages',
        'isTakenByMe',
        'isTaken',
        'takenByName',
        'finalized'
    ));
}



    /**
     * POST /admin/disputes/{dispute}/take
     * Claim dispute so other admins can't action it.
     */
  public function take(Request $request, Dispute $dispute)
{
    $admin = $request->user();
    abort_unless($admin && ($admin->role ?? null) === 'admin', 403);

    if ($this->isReservationFinalized((int)$dispute->reservation_id)) {
        return back()->with('error', 'This dispute is finalized. You cannot take it.');
    }

    $updated = Dispute::whereKey($dispute->id)
        ->whereNull('taken_by_admin_id')
        ->update([
            'taken_by_admin_id' => (int)$admin->id,
            'taken_at'          => now(),
            'status'            => DB::raw("CASE WHEN status='open' THEN 'in_review' ELSE status END"),
            'updated_at'        => now(),
        ]);

    if ($updated === 0) {
        $dispute->refresh();
        return back()->with('error', 'This dispute is already taken by another admin.');
    }

    return back()->with('ok', 'Dispute taken. You can now handle it.');
}


    /**
     * POST /admin/disputes/{dispute}/status
     */
    public function updateStatus(Request $request, Dispute $dispute)
    {
        $admin = $request->user();
        abort_unless($admin && ($admin->role ?? null) === 'admin', 403);

        $data = $request->validate([
            'status' => ['required', 'in:open,in_review,resolved,rejected'],
        ]);


        // If dispute is taken by someone else, block
        if (!empty($dispute->taken_by_admin_id) && (int)$dispute->taken_by_admin_id !== (int)$admin->id) {
            return back()->with('error', 'This dispute is assigned to another admin.');
        }
        if ($this->isReservationFinalized((int)$dispute->reservation_id)) {
    return back()->with('error', 'This dispute is finalized. You cannot change status.');
}


        $dispute->forceFill(['status' => $data['status']])->save();

        return back()->with('ok', 'Dispute status updated.');
    }

    /**
     * POST /admin/disputes/{dispute}/message
     * Body: message
     * Optional: target=client|coach to show in UI; stored in meta if you add it later.
     */
  public function message(Request $request, Dispute $dispute)
{
    $admin = $request->user();
    abort_unless($admin && ($admin->role ?? null) === 'admin', 403);

    // ✅ must take first
    if (empty($dispute->taken_by_admin_id)) {
        return back()->with('error', 'Please take this dispute first.');
    }

    // ✅ if taken by someone else, block
    if ((int)$dispute->taken_by_admin_id !== (int)$admin->id) {
        return back()->with('error', 'This dispute is assigned to another admin.');
    }

    if ($this->isReservationFinalized((int)$dispute->reservation_id)) {
        return back()->with('error', 'This dispute is finalized. You cannot send messages.');
    }

    $data = $request->validate([
        'message'     => ['required', 'string', 'max:4000'],
        'target_role' => ['required', 'in:client,coach'],
    ]);

    DB::transaction(function () use ($dispute, $admin, $data) {
        DisputeMessage::create([
            'dispute_id'     => (int)$dispute->id,
            'sender_user_id' => (int)$admin->id,
            'sender_role'    => 'admin',
            'target_role'    => $data['target_role'],
            'channel'        => $data['target_role'],
            'message'        => $data['message'],
        ]);

        if (($dispute->status ?? '') === 'open') {
            $dispute->forceFill(['status' => 'in_review'])->save();
        }

        $dispute->forceFill(['last_message_at' => now()])->save();
    });

    return back()->with('ok', 'Message sent.');
}


    /**
     * POST /admin/disputes/{dispute}/finalize
     * Admin selects action from dropdown and finalizes money.
     */
    public function finalize(
        Request $request,
        Dispute $dispute,
        WalletService $wallet,
        ReservationSettlementService $settlement
    ) {
        $admin = $request->user();
        abort_unless($admin && ($admin->role ?? null) === 'admin', 403);

        $data = $request->validate([
            'action' => ['required', 'in:reject_dispute,refund_full_amount,refund_service_only,pay_coach'],
            'note'   => ['nullable', 'string', 'max:5000'],
        ]);

        return DB::transaction(function () use ($data, $admin, $dispute, $wallet, $settlement) {

            // Reload + lock dispute row
           $dispute = Dispute::lockForUpdate()->findOrFail($dispute->id);

if (empty($dispute->taken_by_admin_id)) {
    return back()->with('error', 'Please take this dispute first.');
}
if ((int)$dispute->taken_by_admin_id !== (int)$admin->id) {
    return back()->with('error', 'This dispute is assigned to another admin.');
}
if (!empty($dispute->resolved_at)) {
    return back()->with('error', 'This dispute is already finalized.');
}


           // Must be taken by me (reservation-level hard lock)



            /** Load reservation locked (so money updates are consistent) */
            $res = Reservation::lockForUpdate()
                ->with(['payment','service','slots'])
                ->findOrFail((int)$dispute->reservation_id);

            // base amounts
            $subtotal = (int) $res->subtotal_minor;
            $fees     = (int) $res->fees_minor;
            $total    = (int) $res->total_minor;

            $paymentId = $res->payment?->id;
            $currency  = $res->currency ?? 'USD';
            $coachId   = (int)($res->coach_id ?? ($res->service?->coach_id ?? 0));

            // mark reservation as in_dispute while being handled
           

            // Execute chosen action
            switch ($data['action']) {

                case 'reject_dispute':
                    // Money: no change
                    // Status: rejected
                $dispute->forceFill([
    'status'               => 'rejected',
    'resolution_action'    => $data['action'],
    'resolution_note'      => $data['note'] ?? null,
    'resolved_by_admin_id' => (int)$admin->id,
    'resolved_at'          => now(),
    'updated_at'           => now(),
])->save();




                    // Optionally keep settlement pending/settled logic:
                    // If it was pending, let settlement recompute later when 48h passed.
                    // If you want immediate proceed after reject, just recompute:
                    $settlement->recompute((int)$res->id);

                    return back()->with('ok', 'Dispute rejected.');

                case 'refund_full_amount':
                  $already = \App\Models\WalletTransaction::where('reservation_id', $res->id)
    ->where('reason', 'admin_refund_full')
    ->where('type', 'credit')
    ->exists();

if (!$already && $total > 0) {
    $wallet->credit(
        (int)$res->client_id,
        $total,
        'admin_refund_full',
        (int)$res->id,
        $paymentId,
        ['dispute_id' => $dispute->id],
        $currency
    );
}

                    // Refund client: total (service + platform fee)
                   
                    // Update reservation analytics
                    $res->forceFill([
                        'settlement_status'     => 'refunded',
                        'refund_total_minor'    => $total,
                        'platform_earned_minor' => 0,      // full refund
                        'coach_earned_minor'    => 0,
                    ])->save();

                  $dispute->forceFill([
    'status'               => 'resolved',
    'resolution_action'    => $data['action'],
    'resolution_note'      => $data['note'] ?? null,
    'resolved_by_admin_id' => (int)$admin->id,
    'resolved_at'          => now(),
    'updated_at'           => now(),
])->save();



                    return back()->with('ok', 'Full amount refunded to client.');

                case 'refund_service_only':
                    $already = \App\Models\WalletTransaction::where('reservation_id', $res->id)
    ->where('reason', 'admin_refund_service_only')
    ->where('type', 'credit')
    ->exists();

if (!$already && $subtotal > 0) {
    $wallet->credit(
        (int)$res->client_id,
        $subtotal,
        'admin_refund_service_only',
        (int)$res->id,
        $paymentId,
        ['dispute_id' => $dispute->id],
        $currency
    );
}

                    // Refund client: subtotal only (platform fee kept)
                   
                    // reservation analytics: platform earns fees (kept), coach earns 0
                    $res->forceFill([
                        'settlement_status'     => 'refunded_partial',
                        'refund_total_minor'    => $subtotal,
                        'platform_earned_minor' => $fees,   // keep platform fee
                        'coach_earned_minor'    => 0,
                    ])->save();

                    Dispute::where('reservation_id', (int)$res->id)->update([
    'status'               => 'resolved',
    'resolution_action'    => $data['action'],
    'resolution_note'      => $data['note'] ?? null,
    'resolved_by_admin_id' => (int)$admin->id,
    'resolved_at'          => now(),
    'updated_at'           => now(),
]);


                    return back()->with('ok', 'Service amount refunded. Platform fee kept.');

              case 'pay_coach':
    $settlement->adminPayCoachNow($res);

    $res->refresh(); // reload latest values if adminPayCoachNow updated amounts
    $res->forceFill([
        'settlement_status'     => 'paid',
        'refund_total_minor'    => 0,
        // optional if you have such columns:
        // 'settled_at'         => now(),
    ])->save();

    Dispute::where('reservation_id', (int)$res->id)->update([
        'status'               => 'resolved',
        'resolution_action'    => $data['action'],
        'resolution_note'      => $data['note'] ?? null,
        'resolved_by_admin_id' => (int)$admin->id,
        'resolved_at'          => now(),
        'updated_at'           => now(),
    ]);

    return back()->with('ok', 'Coach has been paid (admin decision).');

            }

            return back()->with('error', 'Unknown action.');
        });
    }

    private function isReservationFinalized(int $reservationId): bool
{
    return Dispute::where('reservation_id', $reservationId)
        ->whereNotNull('resolved_at')
        ->exists();
}

}
