<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use App\Models\CoachWithdrawal;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Pagination\LengthAwarePaginator;

class AdminTransactionController extends Controller
{
    public function index(Request $request)
    {
        $flow = strtolower(trim((string) $request->query('flow', 'in')));
        if (!in_array($flow, ['in','out'], true)) $flow = 'in';

        $role = strtolower(trim((string) $request->query('role', 'all')));
        if (!in_array($role, ['coach','client','all'], true)) $role = 'all';

        $range = strtolower(trim((string) $request->query('range', 'month')));
        if (!in_array($range, ['day','week','month','year','lifetime','custom'], true)) $range = 'month';

        $q        = trim((string) $request->query('q', ''));
        $provider = strtolower(trim((string) $request->query('provider', ''))); // stripe|paypal
        $currency = strtoupper(trim((string) $request->query('currency', '')));
        $status   = strtolower(trim((string) $request->query('status', '')));

        [$from, $to] = $this->resolveDateWindow($range, $request->query('from'), $request->query('to'));

        if ($flow === 'in') {
            return $this->moneyIn($request, $from, $to, $q, $provider, $currency, $status, $role, $range);
        }

        return $this->moneyOut($request, $from, $to, $q, $provider, $currency, $status, $role, $range);
    }

    /**
     * MONEY IN = successful/captured payments (external inflow)
     * Uses payments.amount_total (your column).
     */
    private function moneyIn(
        Request $request,
        ?Carbon $from,
        ?Carbon $to,
        string $q,
        string $provider,
        string $currency,
        string $status,
        string $role,
        string $range
    ) {
        $payments = Payment::query();

        // If you have reservation relation, keep it. If not, remove these with() lines.
        $payments->with([
            'reservation:id,client_id,service_id,currency',
            'reservation.client:id,first_name,email',
            'reservation.service:id,title,coach_id',
            'reservation.service.coach:id,first_name,email',
        ]);

        // successful statuses (adjust if your system uses only "paid")
        $payments->whereIn(DB::raw('LOWER(status)'), ['paid','succeeded','completed','captured']);

        if ($from) $payments->where('created_at', '>=', $from);
        if ($to)   $payments->where('created_at', '<=', $to);

        if ($provider !== '') $payments->whereRaw('LOWER(provider) = ?', [$provider]);
        if ($currency !== '') $payments->whereRaw('UPPER(currency) = ?', [$currency]);

        if ($status !== '') $payments->whereRaw('LOWER(status) = ?', [$status]);

        // Search
        if ($q !== '') {
            $payments->where(function ($w) use ($q) {
                if (ctype_digit($q)) $w->orWhere('id', (int)$q);

                $w->orWhere('provider_payment_id', 'like', "%{$q}%")
                  ->orWhere('provider_charge_id', 'like', "%{$q}%")
                  ->orWhere('provider_capture_id', 'like', "%{$q}%");

                // Optional if relation exists
                $w->orWhereHas('reservation.client', function ($c) use ($q) {
                    $c->where('first_name', 'like', "%{$q}%")
                      ->orWhere('email', 'like', "%{$q}%");
                });

                $w->orWhereHas('reservation.service.coach', function ($c) use ($q) {
                    $c->where('first_name', 'like', "%{$q}%")
                      ->orWhere('email', 'like', "%{$q}%");
                });

                $w->orWhereHas('reservation.service', function ($s) use ($q) {
                    $s->where('title', 'like', "%{$q}%");
                });
            });
        }

        $rows = (clone $payments)
            ->orderByDesc('created_at')
            ->paginate(20)
            ->withQueryString();

        // ✅ KPI must NOT carry ORDER BY
        $kpi = (clone $payments)
            ->reorder()
            ->selectRaw('COALESCE(SUM(amount_total),0) as in_minor, COALESCE(COUNT(*),0) as in_count')
            ->first();

        // ✅ Provider breakdown (also reorder)
        $byProvider = (clone $payments)
            ->reorder()
            ->selectRaw('LOWER(COALESCE(provider,"")) as provider, COALESCE(SUM(amount_total),0) as minor, COUNT(*) as cnt')
            ->groupByRaw('LOWER(COALESCE(provider,""))')
            ->orderByDesc('minor')
            ->get();

        return view('admin.transactions.index', [
            'flow' => 'in',
            'role' => $role,
            'range' => $range,
            'from' => optional($from)->toDateString(),
            'to' => optional($to)->toDateString(),
            'q' => $q,
            'provider' => $provider,
            'currency' => $currency,
            'status' => $status,
            'rows' => $rows,
            'kpi' => $kpi,
            'byProvider' => $byProvider,
        ]);
    }

    /**
     * MONEY OUT = client refunds to original + coach payouts released
     * client out = payments.refunded_minor + refund_status succeeded
     * coach out  = coach_withdrawals.amount_minor + status released
     */
    private function moneyOut(
        Request $request,
        ?Carbon $from,
        ?Carbon $to,
        string $q,
        string $provider,
        string $currency,
        string $status,
        string $role,
        string $range
    ) {
        $includeRefunds = in_array($role, ['all','client'], true);
        $includePayouts = in_array($role, ['all','coach'], true);

        // ------------------------
        // Refunds base (CLIENT OUT)
        // ------------------------
        $refundsBase = Payment::query()
            ->whereRaw('LOWER(COALESCE(refund_status,"")) = "succeeded"')
            ->where('refunded_minor', '>', 0);

        // use refunded_at if exists else updated_at
        if ($from) {
            $refundsBase->where(function ($w) use ($from) {
                $w->where('refunded_at', '>=', $from)
                  ->orWhere(function ($ww) use ($from) {
                      $ww->whereNull('refunded_at')->where('updated_at', '>=', $from);
                  });
            });
        }
        if ($to) {
            $refundsBase->where(function ($w) use ($to) {
                $w->where('refunded_at', '<=', $to)
                  ->orWhere(function ($ww) use ($to) {
                      $ww->whereNull('refunded_at')->where('updated_at', '<=', $to);
                  });
            });
        }

        if ($provider !== '') $refundsBase->whereRaw('LOWER(provider) = ?', [$provider]);
        if ($currency !== '') $refundsBase->whereRaw('UPPER(currency) = ?', [$currency]);
        if ($status !== '')   $refundsBase->whereRaw('LOWER(refund_status) = ?', [$status]);

        if ($q !== '') {
            $refundsBase->where(function ($w) use ($q) {
                if (ctype_digit($q)) $w->orWhere('id', (int)$q);
                $w->orWhere('provider_refund_id', 'like', "%{$q}%")
                  ->orWhere('provider_payment_id', 'like', "%{$q}%")
                  ->orWhere('provider_charge_id', 'like', "%{$q}%")
                  ->orWhere('provider_capture_id', 'like', "%{$q}%");
            });
        }

        // ------------------------
        // Payouts base (COACH OUT)
        // ------------------------
        $payoutsBase = CoachWithdrawal::query()
            ->whereRaw('LOWER(status) = "released"')
            ->where('amount_minor', '>', 0);

        if ($from) {
            $payoutsBase->where(function ($w) use ($from) {
                $w->where('released_at', '>=', $from)
                  ->orWhere(function ($ww) use ($from) {
                      $ww->whereNull('released_at')->where('release_at', '>=', $from);
                  });
            });
        }
        if ($to) {
            $payoutsBase->where(function ($w) use ($to) {
                $w->where('released_at', '<=', $to)
                  ->orWhere(function ($ww) use ($to) {
                      $ww->whereNull('released_at')->where('release_at', '<=', $to);
                  });
            });
        }

        if ($provider !== '') $payoutsBase->whereRaw('LOWER(method) = ?', [$provider]); // method=paypal/stripe
        if ($currency !== '') $payoutsBase->whereRaw('UPPER(currency) = ?', [$currency]);
        if ($status !== '')   $payoutsBase->whereRaw('LOWER(status) = ?', [$status]);

        if ($q !== '') {
            $payoutsBase->where(function ($w) use ($q) {
                if (ctype_digit($q)) $w->orWhere('id', (int)$q);
                $w->orWhere('provider_ref', 'like', "%{$q}%")
                  ->orWhere('method', 'like', "%{$q}%");
            });
        }

        // ✅ KPI builders (separate from row selects) => NO MySQL 1140
        $refundKpiRow = $includeRefunds
            ? (clone $refundsBase)->reorder()->selectRaw('COALESCE(SUM(refunded_minor),0) as minor, COALESCE(COUNT(*),0) as cnt')->first()
            : (object)['minor' => 0, 'cnt' => 0];

        $payoutKpiRow = $includePayouts
            ? (clone $payoutsBase)->reorder()->selectRaw('COALESCE(SUM(amount_minor),0) as minor, COALESCE(COUNT(*),0) as cnt')->first()
            : (object)['minor' => 0, 'cnt' => 0];

        $refundMinor = (int)($refundKpiRow->minor ?? 0);
        $payoutMinor = (int)($payoutKpiRow->minor ?? 0);
        $outMinor    = $refundMinor + $payoutMinor;
        $outCount    = (int)($refundKpiRow->cnt ?? 0) + (int)($payoutKpiRow->cnt ?? 0);

        // ✅ Provider breakdown
        $byProvider = $this->providerBreakdownOutBothFiltered($refundsBase, $payoutsBase, $includeRefunds, $includePayouts);

        // ✅ Build UNION rows always (simpler blade, consistent)
        $sub = null;

        if ($includeRefunds) {
            $refundRowsSelect = (clone $refundsBase)->reorder()->selectRaw('
                "refund" as row_type,
                id as row_id,
                COALESCE(refunded_at, updated_at) as occurred_at,
                LOWER(COALESCE(provider,"")) as provider,
                UPPER(COALESCE(currency,"USD")) as currency,
                refunded_minor as amount_minor,
                provider_refund_id as provider_ref,
                LOWER(COALESCE(refund_status,"succeeded")) as status,
                NULL as user_id,
                "client" as user_role
            ');

            $sub = $refundRowsSelect;
        }

        if ($includePayouts) {
            $payoutRowsSelect = (clone $payoutsBase)->reorder()->selectRaw('
                "payout" as row_type,
                id as row_id,
                COALESCE(released_at, updated_at) as occurred_at,
                LOWER(COALESCE(method,"")) as provider,
                UPPER(COALESCE(currency,"USD")) as currency,
                amount_minor as amount_minor,
                provider_ref as provider_ref,
                LOWER(COALESCE(status,"released")) as status,
                coach_id as user_id,
                "coach" as user_role
            ');

            $sub = $sub ? $sub->unionAll($payoutRowsSelect) : $payoutRowsSelect;
        }

        // If somehow none included (shouldn't happen), fallback empty
        if (!$sub) {
            $rows = new LengthAwarePaginator(collect([]), 0, 20, 1, ['path' => url()->current(), 'query' => $request->query()]);
            return view('admin.transactions.index', [
                'flow' => 'out',
                'role' => $role,
                'range' => $range,
                'from' => optional($from)->toDateString(),
                'to' => optional($to)->toDateString(),
                'q' => $q,
                'provider' => $provider,
                'currency' => $currency,
                'status' => $status,
                'rows' => $rows,
                'kpi' => (object)[
                    'out_minor' => 0,
                    'refund_minor' => 0,
                    'payout_minor' => 0,
                    'out_count' => 0,
                ],
                'byProvider' => collect([]),
            ]);
        }

        // Paginate subquery
        $rows = $this->paginateSubquery($request, $sub, 20, 'occurred_at');

        return view('admin.transactions.index', [
            'flow' => 'out',
            'role' => $role,
            'range' => $range,
            'from' => optional($from)->toDateString(),
            'to' => optional($to)->toDateString(),
            'q' => $q,
            'provider' => $provider,
            'currency' => $currency,
            'status' => $status,
            'rows' => $rows,
            'kpi' => (object)[
                'out_minor' => $outMinor,
                'refund_minor' => $refundMinor,
                'payout_minor' => $payoutMinor,
                'out_count' => $outCount,
            ],
            'byProvider' => $byProvider,
        ]);
    }

    private function resolveDateWindow(string $range, $fromInput, $toInput): array
    {
        $tz  = config('app.timezone', 'UTC');
        $now = Carbon::now($tz);

        if ($range === 'lifetime') return [null, null];

        if ($range === 'custom') {
            $from = $fromInput ? Carbon::parse($fromInput, $tz)->startOfDay() : null;
            $to   = $toInput   ? Carbon::parse($toInput, $tz)->endOfDay() : null;
            return [$from, $to];
        }

        return match ($range) {
            'day'   => [$now->copy()->startOfDay(),   $now->copy()->endOfDay()],
            'week'  => [$now->copy()->startOfWeek(),  $now->copy()->endOfWeek()],
            'month' => [$now->copy()->startOfMonth(), $now->copy()->endOfMonth()],
            'year'  => [$now->copy()->startOfYear(),  $now->copy()->endOfYear()],
            default => [$now->copy()->startOfMonth(), $now->copy()->endOfMonth()],
        };
    }

    /**
     * Paginate a SELECT (including UNION) by wrapping it as subquery.
     */
    private function paginateSubquery(Request $request, $selectQuery, int $perPage = 20, string $orderColumn = 'occurred_at')
    {
        $page = max(1, (int) $request->query('page', 1));

        $base = DB::query()
            ->fromSub($selectQuery, 't')
            ->orderByDesc($orderColumn);

        $total = (clone $base)->count();
        $items = (clone $base)->forPage($page, $perPage)->get();

        return new LengthAwarePaginator(
            $items,
            $total,
            $perPage,
            $page,
            ['path' => url()->current(), 'query' => $request->query()]
        );
    }

    /**
     * Provider breakdown for OUT respecting role filters.
     * Returns objects:
     * provider, refund_minor, refund_cnt, payout_minor, payout_cnt, total_minor, total_cnt
     */
    private function providerBreakdownOutBothFiltered($refundsBase, $payoutsBase, bool $includeRefunds, bool $includePayouts)
    {
        $refunds = collect([]);
        $payouts = collect([]);

        if ($includeRefunds) {
            $refunds = (clone $refundsBase)
                ->reorder()
                ->selectRaw('LOWER(COALESCE(provider,"")) as provider, COALESCE(SUM(refunded_minor),0) as minor, COUNT(*) as cnt')
                ->groupByRaw('LOWER(COALESCE(provider,""))')
                ->get()
                ->keyBy('provider');
        }

        if ($includePayouts) {
            $payouts = (clone $payoutsBase)
                ->reorder()
                ->selectRaw('LOWER(COALESCE(method,"")) as provider, COALESCE(SUM(amount_minor),0) as minor, COUNT(*) as cnt')
                ->groupByRaw('LOWER(COALESCE(method,""))')
                ->get()
                ->keyBy('provider');
        }

        $providers = collect(array_unique(array_merge($refunds->keys()->all(), $payouts->keys()->all())))
            ->filter(fn($p) => (string)$p !== '')
            ->values();

        return $providers->map(function ($p) use ($refunds, $payouts) {
            $r = $refunds->get($p);
            $w = $payouts->get($p);

            return (object)[
                'provider'     => $p,
                'refund_minor' => (int)($r->minor ?? 0),
                'refund_cnt'   => (int)($r->cnt ?? 0),
                'payout_minor' => (int)($w->minor ?? 0),
                'payout_cnt'   => (int)($w->cnt ?? 0),
                'total_minor'  => (int)($r->minor ?? 0) + (int)($w->minor ?? 0),
                'total_cnt'    => (int)($r->cnt ?? 0) + (int)($w->cnt ?? 0),
            ];
        })->sortByDesc('total_minor')->values();
    }
}
