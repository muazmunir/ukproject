<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Users;
use App\Services\SupportAgentStatusAnalyticsService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class SupportAgentStatusAnalyticsManagerController extends Controller
{
    private function role(Request $request): string
    {
        return strtolower(trim((string) ($request->user()->role ?? '')));
    }

    private function abortUnlessManagerOrSuperadmin(Request $request): void
    {
        abort_unless(in_array($this->role($request), ['manager','superadmin'], true), 403);
    }

    /**
     * Team admins = admins who are members of ANY active team owned by this manager.
     * Membership is active if:
     *   - end_at is NULL OR end_at > now (UTC stored)
     *   - start_at <= now (optional but good)
     */
    private function teamAdminsQuery(int $managerId)
    {
        $now = now('UTC')->format('Y-m-d H:i:s');

        return Users::query()
            ->join('staff_team_members as stm', 'stm.agent_id', '=', 'users.id')
            ->join('staff_teams as st', 'st.id', '=', 'stm.team_id')
            ->whereNull('st.deleted_at')
            ->where('st.is_active', 1)
            ->where('st.manager_id', $managerId)
            ->where('users.role', 'admin')
            // membership window
            ->where('stm.start_at', '<=', $now)
            ->where(function ($q) use ($now) {
                $q->whereNull('stm.end_at')
                  ->orWhere('stm.end_at', '>', $now);
            })
            ->select('users.id','users.first_name','users.last_name','users.email','users.timezone','users.role')
            ->distinct()
            ->orderBy('users.first_name')
            ->orderBy('users.last_name');
    }

    private function allAdminsQuery()
    {
        return Users::query()
            ->where('role', 'admin')
            ->select('id','first_name','last_name','email','timezone','role')
            ->orderBy('first_name')
            ->orderBy('last_name');
    }

    private function isAdminInManagersTeam(int $managerId, int $adminId): bool
    {
        $now = now('UTC')->format('Y-m-d H:i:s');

        return DB::table('staff_team_members as stm')
            ->join('staff_teams as st', 'st.id', '=', 'stm.team_id')
            ->where('st.manager_id', $managerId)
            ->whereNull('st.deleted_at')
            ->where('st.is_active', 1)
            ->where('stm.agent_id', $adminId)
            ->where('stm.start_at', '<=', $now)
            ->where(function ($q) use ($now) {
                $q->whereNull('stm.end_at')
                  ->orWhere('stm.end_at', '>', $now);
            })
            ->exists();
    }

    private function canViewTarget(Request $request, Users $target, string $scope): bool
    {
        $role = $this->role($request);
        if ($role === 'superadmin') return true;

        // manager can only view admins
        if (strtolower((string)$target->role) !== 'admin') return false;

        if ($scope === 'all') {
            // ✅ allow managers to view all admins
            // If you want ONLY team, change to: return false;
            return true;
        }

        // team scope
        return $this->isAdminInManagersTeam((int)$request->user()->id, (int)$target->id);
    }

  public function index(Request $request)
{
    $this->abortUnlessManagerOrSuperadmin($request);

    $viewer = $request->user();

    $scope = strtolower((string) $request->input('scope', 'team'));
    if (!in_array($scope, ['team','all'], true)) $scope = 'team';

    $teamAdmins = $this->teamAdminsQuery((int)$viewer->id)->get();
    $allAdmins  = $this->allAdminsQuery()->get();

    // ✅ the list shown in UI depends on scope
    $people = ($scope === 'all') ? $allAdmins : $teamAdmins;

    abort_unless($people->count() > 0, 404);

    // ✅ target must come from the visible list (avoid selecting non-team while scope=team)
    $requestedTargetId = (int) $request->input('user_id', 0);

    $targetId = $requestedTargetId && $people->firstWhere('id', $requestedTargetId)
        ? $requestedTargetId
        : (int) $people->first()->id;

    $target = Users::query()
        ->select('id','first_name','last_name','email','timezone','role','shift_enabled','shift_start','shift_end','shift_days')
        ->findOrFail($targetId);

    // ✅ enforce access
    abort_unless($this->canViewTarget($request, $target, $scope), 403);

    return view('admin.support.status_analytics.manager', [
        'scope'      => $scope,
        'people'     => $people,     // ✅ NEW: only one list for UI
        'target'     => $target,
        'teamAdmins' => $teamAdmins, // keep if you want (optional)
        'allAdmins'  => $allAdmins,  // keep if you want (optional)
    ]);
}


    public function data(Request $request, SupportAgentStatusAnalyticsService $svc)
    {
        $this->abortUnlessManagerOrSuperadmin($request);

        $viewer = $request->user();

        // Range
        $range = strtolower((string) $request->input('range', 'weekly'));
        if (!in_array($range, ['daily','weekly','monthly','yearly','lifetime','custom'], true)) {
            return response()->json(['ok' => false, 'message' => 'Invalid range'], 422);
        }

        $scope = strtolower((string) $request->input('scope', 'team'));
        if (!in_array($scope, ['team','all'], true)) $scope = 'team';

        // Target
        $targetId = (int) $request->input('user_id', 0);
        if (!$targetId) {
            return response()->json(['ok' => false, 'message' => 'Missing user_id'], 422);
        }

        $target = Users::query()
    ->select(
        'id','first_name','last_name','email',
        'timezone','shift_enabled','shift_start','shift_end','shift_days','role'
    )
    ->findOrFail($targetId);


        abort_unless($this->canViewTarget($request, $target, $scope), 403);

        // ✅ Force “admin timezone”
        $displayTz = $target->timezone ?: 'UTC';
        try { new \DateTimeZone($displayTz); }
        catch (\Throwable $e) { $displayTz = 'UTC'; }

        // Calendar navigation inputs
        $anchor = $request->input('anchor'); // YYYY-MM-DD
        $from   = $request->input('from');   // YYYY-MM-DD
        $to     = $request->input('to');     // YYYY-MM-DD

        if ($range !== 'lifetime' && $anchor) {
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$anchor)) {
                return response()->json(['ok' => false, 'message' => 'Invalid anchor date'], 422);
            }
        }
        if ($range === 'custom') {
            if ($from && !preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$from)) {
                return response()->json(['ok' => false, 'message' => 'Invalid from date'], 422);
            }
            if ($to && !preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$to)) {
                return response()->json(['ok' => false, 'message' => 'Invalid to date'], 422);
            }
        }

        $payload = $svc->buildForUser(
            (int) $target->id,
            $range,
            $displayTz,
            $anchor ? (string)$anchor : null,
            $from ? (string)$from : null,
            $to ? (string)$to : null
        );

        // Shift label (same logic as your admin controller)
        $dayMap = [1=>'Mon',2=>'Tue',3=>'Wed',4=>'Thu',5=>'Fri',6=>'Sat',7=>'Sun'];

        $shiftEnabled = (bool) ($target->shift_enabled ?? false);
        $shiftStart   = $target->shift_start;
        $shiftEnd     = $target->shift_end;

        $days = $target->shift_days ?: [];
        if (is_string($days)) {
            $decoded = json_decode($days, true);
            $days = is_array($decoded) ? $decoded : [];
        }
        if (!is_array($days)) $days = [];

        $days = array_values(array_unique(array_map('intval', $days)));
        sort($days);

        if ($shiftEnabled) {
            $ss = $shiftStart ? substr((string)$shiftStart, 0, 5) : '—';
            $se = $shiftEnd   ? substr((string)$shiftEnd,   0, 5) : '—';
            $d  = $days
                ? implode(', ', array_map(fn($x) => $dayMap[$x] ?? (string)$x, $days))
                : '—';

            $shiftLabel = "{$d} • {$ss}–{$se}";
        } else {
            $shiftLabel = 'Shift Disabled';
        }

        $targetName = trim(($target->first_name.' '.$target->last_name));
if ($targetName === '') $targetName = $target->email;


        return response()->json([
            'ok'         => true,
            'scope'      => $scope,
            'range'      => $range,
            'user_id'    => (int)$target->id,
            'target_name' => $targetName,
            'display_tz' => $displayTz,
            'anchor'     => $anchor,
            'custom'     => ['from' => $from, 'to' => $to],
            'shift'      => [
                'enabled' => $shiftEnabled,
                'start'   => $shiftStart ? substr((string)$shiftStart, 0, 5) : null,
                'end'     => $shiftEnd   ? substr((string)$shiftEnd,   0, 5) : null,
                'days'    => $days,
                'label'   => $shiftLabel,
            ],
        ] + $payload);
    }
}
