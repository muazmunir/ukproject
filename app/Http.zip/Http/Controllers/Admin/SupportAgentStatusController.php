<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\SupportQueueService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use App\Support\Shift;
use Illuminate\Validation\Rule;

class SupportAgentStatusController extends Controller
{
    // ✅ ONLY statuses user can set from dropdown
    private const ALLOWED = ['available','break','meeting','tech_issues','admin'];

    public function update(Request $request, SupportQueueService $queue)
    {
        $user = $request->user();

        $role = strtolower(trim((string) $user->role));
        if (!in_array($role, ['admin','manager','superadmin'], true)) {
            return response()->json(['ok' => false, 'message' => 'Not allowed'], 403);
        }

        $request->validate([
            'status' => ['required', 'string', Rule::in(self::ALLOWED)],
            'reason' => ['nullable', 'string', 'max:255'],
        ]);

        $requested = strtolower((string) $request->input('status'));
        $reason    = $request->input('reason');

        // ============================================================
        // ✅ LEAVE LOCK + POST-RETURN HANDLING (UTC)
        // users:
        // absence_kind, absence_status, absence_start_at, absence_end_at (UTC)
        // absence_return_required (bool), absence_return_since (UTC)
        // ============================================================
        $nowUtc   = now()->utc();
        $startUtc = $user->absence_start_at ? Carbon::parse($user->absence_start_at)->utc() : null;
        $endUtc   = $user->absence_end_at   ? Carbon::parse($user->absence_end_at)->utc()   : null;

        $hasLeave = (bool) ($user->absence_kind && $user->absence_status && $startUtc && $endUtc);

        // 1) Active window => lock everything
$kind = strtolower((string) $user->absence_kind);
$type = strtolower((string) $user->absence_status);

// Active window?
$active = $hasLeave && $nowUtc->between($startUtc, $endUtc);

// LOCK rules:
// - holiday + authorized => lock
// - absence + authorized => lock
// - absence + unauthorized (rejected absence window) => NOT locked
$shouldLock = $active && (
    ($kind === 'holiday' && $type === 'authorized') ||
    ($kind === 'absence' && $type === 'authorized')
);

if ($shouldLock) {
    return response()->json([
        'ok' => false,
        'locked' => true,
        'phase' => 'active',
        'absence_kind' => $user->absence_kind,
        'absence_status'=> $user->absence_status,
        'absence_end_at'=> $endUtc->toDateTimeString(),
        'message' => 'Your status is locked due to active leave until ' .
            $endUtc->timezone($user->timezone ?: 'UTC')->format('d M Y, H:i'),
    ], 423);
}

        // 2) Post window => if return is required, only allow Available
        if ((bool)($user->absence_return_required ?? false)) {

            if ($requested !== 'available') {
                return response()->json([
                    'ok'     => false,
                    'locked' => true,
                    'phase'  => 'post',
                    'status' => 'unauthorized_absence',
                    'message'=> 'Return required. You can only set Available to return from Unauthorized Absence.',
                ], 423);
            }

            // If user clicks Available: write history log for post-unauthorized period
           DB::transaction(function () use ($user, $nowUtc) {

    // Always close any open status log (especially the open unauthorized_absence)
    $open = DB::table('agent_status_logs')
        ->where('user_id', $user->id)
        ->whereNull('ended_at')
        ->orderByDesc('started_at')
        ->first();

    if ($open) {
        $openStart = Carbon::parse($open->started_at)->utc();
        $end = $nowUtc->copy();
        if ($end->lessThanOrEqualTo($openStart)) $end = $openStart->copy()->addSecond();

        DB::table('agent_status_logs')->where('id', $open->id)->update([
            'ended_at'   => $end->toDateTimeString(),
            'updated_at' => now(),
        ]);
    }

    // Clear leave fields (return completed)
    DB::table('users')->where('id', $user->id)->update([
        'absence_kind'            => null,
        'absence_status'          => null,
        'absence_start_at'        => null,
        'absence_end_at'          => null,
        'absence_return_required' => false,
        'absence_return_since'    => null,
        'absence_set_at'          => $nowUtc->toDateTimeString(),
        'updated_at'              => now(),
    ]);
});

            // continue below; we will set status=available normally and log it
        }

        // ============================================================
        // ✅ NORMAL STATUS UPDATE FLOW
        // ============================================================

        $now = now(); // app tz ok; DB will store UTC if your app timezone is UTC (you said logs are UTC)

        // log only if within shift
        $shouldLog = Shift::isWithinShiftNow($user, $now);

        // previous status (for queue logic)
        $prevStatus = null;
        if ($shouldLog) {
            $prevStatus = (string) DB::table('agent_status_logs')
                ->where('user_id', $user->id)
                ->whereNull('ended_at')
                ->orderByDesc('started_at')
                ->value('status');
        } else {
            $prevStatus = (string) ($user->support_status ?? '');
        }

        // anti-spam only if logging
        if ($shouldLog) {
            $lastLog = DB::table('agent_status_logs')
                ->where('user_id', $user->id)
                ->orderByDesc('started_at')
                ->first();

            if ($lastLog) {
                $lastStarted = Carbon::parse($lastLog->started_at);
                if ($lastStarted->diffInSeconds($now) < 2) {

                    if ($lastLog->ended_at === null && $lastLog->status === $requested) {
                        DB::table('agent_status_logs')->where('id', $lastLog->id)->update([
                            'reason' => $reason,
                            'updated_at' => $now,
                        ]);

                        return response()->json([
                            'ok' => true,
                            'status' => $requested,
                            'ignored' => true,
                            'logged' => true,
                        ]);
                    }

                    return response()->json([
                        'ok' => true,
                        'status' => $prevStatus ?: $requested,
                        'ignored' => true,
                        'logged' => true,
                        'message' => 'Duplicate/rapid status update ignored',
                    ]);
                }
            }
        }

        DB::transaction(function () use ($user, $requested, $reason, $now, $shouldLog) {

            // always update user's current status
            $user->forceFill([
                'support_status' => $requested,
                'support_status_since' => $now,
            ])->save();

            // outside shift => do not write status logs
            if (!$shouldLog) return;

            $open = DB::table('agent_status_logs')
                ->where('user_id', $user->id)
                ->whereNull('ended_at')
                ->orderByDesc('started_at')
                ->first();

            // same status already open => just update reason
            if ($open && $open->status === $requested) {
                DB::table('agent_status_logs')->where('id', $open->id)->update([
                    'reason' => $reason,
                    'updated_at' => $now,
                ]);

                $user->forceFill([
                    'support_status' => $requested,
                    'support_status_since' => $open->started_at,
                ])->save();

                return;
            }

            // close previous open
            if ($open) {
                $end = $now->copy();
                $start = Carbon::parse($open->started_at);
                if ($end->lessThanOrEqualTo($start)) $end = $start->copy()->addSecond();

                DB::table('agent_status_logs')->where('id', $open->id)->update([
                    'ended_at' => $end,
                    'updated_at' => $now,
                ]);
            }

            // insert new open
            DB::table('agent_status_logs')->insert([
                'user_id' => $user->id,
                'status' => $requested,
                'reason' => $reason,
                'started_at' => $now,
                'created_at' => $now,
                'updated_at' => $now,
            ]);

            // audit
            DB::table('admin_action_logs')->insert([
                'admin_user_id' => $user->id,
                'action' => 'support_status_update',
                'target_type' => 'user',
                'target_id' => $user->id,
                'meta' => json_encode(['status' => $requested, 'reason' => $reason]),
                'ip' => request()->ip(),
                'user_agent' => substr((string) request()->userAgent(), 0, 255),
                'created_at' => $now,
                'updated_at' => $now,
            ]);
        });

        // Queue logic (unchanged)
        $requeued = 0;
        $dispatched_admins = 0;
        $dispatched_managers = 0;

        $roleForQueue = $role === 'superadmin' ? 'admin' : $role;

        if ($requested === 'tech_issues' && $prevStatus !== 'tech_issues') {
            if ($roleForQueue === 'manager') {
                $requeued = $queue->requeueStaffOpenConversations($user->id, 'manager');
                $dispatched_managers = $queue->dispatchManagers();
            } else {
                $requeued = $queue->requeueStaffOpenConversations($user->id, 'admin');
                $dispatched_admins = $queue->dispatchAdmins();
            }
        }

        if ($prevStatus !== 'available' && $requested === 'available') {
            if ($roleForQueue === 'manager') {
                $dispatched_managers = $queue->dispatchManagers();
            } else {
                $dispatched_admins = $queue->dispatchAdmins();
            }
        }

        return response()->json([
            'ok' => true,
            'status' => $requested,
            'logged' => (bool) $shouldLog,
            'requeued' => $requeued,
            'dispatched_admins' => $dispatched_admins,
            'dispatched_managers' => $dispatched_managers,
        ]);
    }
}
