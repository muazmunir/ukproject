<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SupportConversation;
use App\Models\SupportMessage;
use App\Models\SupportConversationRead;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Services\SupportQueueService;


class SupportConversationAdminController extends Controller
{
  /* =========================================================
   * INBOX
   * ======================================================= */
  public function index(Request $request)
  {
    $staff = $this->staffOrFail();

    // ✅ auto-assign before inbox load
 app(SupportQueueService::class)->dispatchAdmins();


    $q      = $request->q;
    $status = $request->status ?? 'open';
    $role   = $request->role ?? 'all';
    $per    = (int)($request->per ?? 10);

    $dateFrom = $request->date_from;
    $dateTo   = $request->date_to;

    $assigned = $request->assigned ?? ($this->isAgent($staff) ? 'mine' : 'all');
    $unread   = $request->unread ?? 'all';

    $convs = SupportConversation::query()
      ->with(['user', 'assignedAdmin'])
      ->select('support_conversations.*')
      // first client/coach real message (conversation "start" for SLA)
->selectSub(function ($sub) {
  $sub->from('support_messages as sm_start')
    ->selectRaw('MIN(sm_start.created_at)')
    ->whereColumn('sm_start.support_conversation_id', 'support_conversations.id')
    ->whereIn('sm_start.sender_type', ['client','coach'])
    ->where('sm_start.type', 'message');
}, 'first_customer_message_at')

// first manager activity moment (we use manager_joined_at if set; fallback to system event time if you want)
->selectRaw("
  CASE
    WHEN support_conversations.manager_joined_at IS NOT NULL THEN support_conversations.manager_joined_at
    ELSE NULL
  END AS manager_started_at
")

// Minutes since first customer message until close (if closed), else until now()
->selectRaw("
  CASE
    WHEN (
      SELECT MIN(sm_start.created_at)
      FROM support_messages sm_start
      WHERE sm_start.support_conversation_id = support_conversations.id
        AND sm_start.sender_type IN ('client','coach')
        AND sm_start.type = 'message'
    ) IS NULL THEN NULL

    WHEN support_conversations.closed_at IS NOT NULL THEN
      TIMESTAMPDIFF(
        MINUTE,
        (
          SELECT MIN(sm_start2.created_at)
          FROM support_messages sm_start2
          WHERE sm_start2.support_conversation_id = support_conversations.id
            AND sm_start2.sender_type IN ('client','coach')
            AND sm_start2.type = 'message'
        ),
        support_conversations.closed_at
      )
    ELSE
      TIMESTAMPDIFF(
        MINUTE,
        (
          SELECT MIN(sm_start3.created_at)
          FROM support_messages sm_start3
          WHERE sm_start3.support_conversation_id = support_conversations.id
            AND sm_start3.sender_type IN ('client','coach')
            AND sm_start3.type = 'message'
        ),
        NOW()
      )
  END AS admin_age_minutes
")



// Manager timer: from manager_joined_at until manager_ended_at (if ended) else until now()
->selectRaw("
  CASE
    WHEN support_conversations.manager_joined_at IS NULL THEN NULL
    WHEN support_conversations.manager_ended_at IS NOT NULL THEN
      TIMESTAMPDIFF(MINUTE, support_conversations.manager_joined_at, support_conversations.manager_ended_at)
    ELSE
      TIMESTAMPDIFF(MINUTE, support_conversations.manager_joined_at, NOW())
  END AS manager_age_minutes
")


      ->selectSub(function ($sub) use ($staff) {
        $sub->from('support_messages as sm')
          ->selectRaw('COUNT(*)')
          ->whereColumn('sm.support_conversation_id', 'support_conversations.id')
          ->whereIn('sm.sender_type', ['client','coach'])
->where('sm.type', 'message')

          ->whereRaw(
            'sm.id > COALESCE((
              SELECT scr.last_read_message_id
              FROM support_conversation_reads scr
              WHERE scr.support_conversation_id = support_conversations.id
                AND scr.admin_id = ?
              LIMIT 1
            ), 0)',
            [$staff->id]
          );
      }, 'unread_count')

      ->when($q, function ($qb) use ($q) {
        $qb->where(function ($sub) use ($q) {
          $sub->whereHas('user', fn ($u) =>
              $u->where('first_name','like',"%$q%")
                ->orWhere('last_name','like',"%$q%")
                ->orWhere('email','like',"%$q%")
            )
            ->orWhere('support_conversations.id',$q)
            ->orWhereHas('messages', fn ($m) => $m->where('body','like',"%$q%"))
            ->orWhereHas('ratings', fn ($r) => $r->where('feedback','like',"%$q%"));
        });
      })

      ->when($role !== 'all', fn ($qb) => $qb->where('scope_role',$role))
      ->when($status !== 'all', fn ($qb) => $qb->where('status',$status))
      ->when($dateFrom, fn ($qb) => $qb->whereDate('created_at','>=',$dateFrom))
      ->when($dateTo, fn ($qb) => $qb->whereDate('created_at','<=',$dateTo));

    if ($this->isAgent($staff) && !$this->isManager($staff)) {
      if ($assigned === 'mine') {
        $convs->where('assigned_admin_id',$staff->id);
      } elseif ($assigned === 'unassigned') {
        $convs->whereNull('assigned_admin_id');
      } else {
        $convs->where(fn ($w) =>
          $w->whereNull('assigned_admin_id')
            ->orWhere('assigned_admin_id',$staff->id)
        );
      }
    } else {
      if ($assigned === 'mine') $convs->where('assigned_admin_id',$staff->id);
      if ($assigned === 'unassigned') $convs->whereNull('assigned_admin_id');
    }

    if ($unread === 'unread') {
      $convs->havingRaw('unread_count > 0');
    }

    $convs = $convs
      ->orderByDesc('last_message_at')
      ->paginate($per)
      ->appends($request->query());

    return view('admin.support.index', compact(
      'convs','q','role','status','per','dateFrom','dateTo','assigned','unread'
    ));
  }

  /* =========================================================
   * SHOW
   * ======================================================= */
 public function show(SupportConversation $conversation)
{
    $staff = $this->staffOrFail();
    $this->abortIfNoAccess($staff, $conversation);

    // ✅ load minimal relations for current row
    $conversation->load(['user','assignedAdmin','ratings.ratedAdmin','manager']);

    // ✅ mark read for THIS conversation row (keep as-is)
    $this->markReadForStaff($staff, $conversation);

    // ✅ THREAD MODE: load all conversation rows in same thread (same user + scope)
    $threadId = $conversation->thread_id;

    $threadConvs = collect();
    if ($threadId) {
        $threadConvs = SupportConversation::where('thread_id', $threadId)
            ->where('user_id', $conversation->user_id)
            ->where('scope_role', $conversation->scope_role)
            ->orderBy('id', 'asc')
            ->get();
    } else {
        // fallback: just this row
        $threadConvs = collect([$conversation]);
    }

    $threadConvIds = $threadConvs->pluck('id')->all();

    // ✅ pull ALL messages across the thread
    $threadMessages = SupportMessage::query()
        ->with('sender')
        ->whereIn('support_conversation_id', $threadConvIds)
        ->orderBy('id', 'asc')
        ->get();

    // ✅ pull ALL ratings across the thread
    $threadRatings = $conversation->ratings; // ratings usually tied to a row
    if ($threadConvs->count() > 1) {
        $threadRatings = \App\Models\SupportConversationRating::query()
            ->with('ratedAdmin')
            ->whereIn('support_conversation_id', $threadConvIds)
            ->orderBy('id', 'asc')
            ->get();
    }

    // ✅ build events timeline, but keep conversation_id so blade can show session separators if needed
    $events = collect();

    foreach ($threadMessages as $msg) {
        if ($msg->type === 'system') {
            $events->push((object)[
                'type'  => data_get($msg->meta, 'event', 'system'),
                'at'    => $msg->created_at,
                'model' => (object) array_merge(
                    (array) data_get($msg->meta, []),
                    ['support_conversation_id' => $msg->support_conversation_id]
                ),
            ]);
        } else {
            $events->push((object)[
                'type'  => 'message',
                'at'    => $msg->created_at,
                'model' => $msg, // has support_conversation_id already
            ]);
        }
    }

    foreach ($threadRatings as $r) {
        $events->push((object)[
            'type'  => 'rating',
            'at'    => $r->created_at,
            'model' => $r,
        ]);
    }

    $events = $events->sortBy('at')->values();

    $otherConversation = SupportConversation::where('user_id', $conversation->user_id)
        ->where('scope_role', $conversation->scope_role === 'coach' ? 'client' : 'coach')
        ->first();

    return view('admin.support.show', [
        'conversation'      => $conversation,      // ✅ current row for actions
        'events'            => $events,            // ✅ full thread timeline
        'threadConvs'       => $threadConvs,       // ✅ optional (if blade wants)
        'threadId'          => $threadId,          // ✅ for polling
        'adminTz'           => auth()->user()->timezone ?? config('app.timezone'),
        'otherConversation' => $otherConversation,
    ]);
}


  /* =========================================================
   * MARK READ
   * ======================================================= */
  public function markRead(Request $request, SupportConversation $conversation)
  {
    $staff = $this->staffOrFail();
    $this->abortIfNoAccess($staff,$conversation);

    $lastId = (int)($request->last_id ?? $conversation->messages()->max('id') ?? 0);
    if ($lastId <= 0) return response()->json(['ok'=>true]);

    SupportConversationRead::updateOrCreate(
      ['support_conversation_id'=>$conversation->id,'admin_id'=>$staff->id],
      ['last_read_message_id'=>$lastId,'last_read_at'=>now()]
    );

    return response()->json(['ok'=>true]);
  }

  /* =========================================================
   * LATEST (POLL)
   * ======================================================= */
  public function latest(Request $request)
{
    $staff = $this->staffOrFail();

    app(SupportQueueService::class)->dispatchAdmins();

    $request->validate([
        'conversation_id' => ['required','integer'],
        'after_id'        => ['nullable','integer'],
    ]);

    $conversation = SupportConversation::findOrFail($request->conversation_id);
    $this->abortIfNoAccess($staff, $conversation);

    // ✅ thread mode: gather all conversation ids for same thread+user+scope
    $threadId = $conversation->thread_id;

    $convIds = [$conversation->id];
    if ($threadId) {
        $convIds = SupportConversation::where('thread_id', $threadId)
            ->where('user_id', $conversation->user_id)
            ->where('scope_role', $conversation->scope_role)
            ->pluck('id')
            ->all();
    }

    $q = SupportMessage::query()
        ->with('sender')
        ->whereIn('support_conversation_id', $convIds)
        ->orderBy('id', 'asc');

    if ($request->after_id) {
        $q->where('id', '>', (int)$request->after_id);
    }

    $msgs = $q->get();

    if ($msgs->isEmpty()) {
        return response()->json(['ok' => true, 'html' => '', 'last' => $request->after_id]);
    }

    $html = '';
    foreach ($msgs as $m) {
        $html .= $m->type === 'system'
            ? view('support._system', ['msg' => $m])->render()
            : view('support._message', ['msg' => $m, 'viewerIsAdmin' => true])->render();
    }

    return response()->json(['ok' => true, 'html' => $html, 'last' => $msgs->last()->id]);
}



  /* =========================================================
 * REQUEST MANAGER (ESCALATION)
 * ======================================================= */
public function requestManager(Request $request, SupportConversation $conversation)
{
    $staff = $this->staffOrFail();

    if ($conversation->status !== 'open') {
        return back()->withErrors([
            'manager' => 'Conversation is not open.',
        ]);
    }

    // only assigned agent OR superadmin can request manager
    $isAgent = $this->isAgent($staff);

    abort_unless(
        ($isAgent && (int)$conversation->assigned_admin_id === (int)$staff->id)
        || $staff->role === 'superadmin',
        403
    );

    // already requested?
    if ($conversation->manager_requested_at) {
        return back()->withErrors([
            'manager' => 'Manager has already been requested.',
        ]);
    }

    // mark escalation
    $conversation->update([
        'manager_requested_at' => now(),
         'manager_requested_by' => $staff->id,
        'status'               => 'waiting_manager',
    ]);
    app(\App\Services\SupportQueueService::class)->dispatchManagers();


    // system log
   SupportMessage::create([
    'support_conversation_id' => $conversation->id,
    'sender_id'   => $staff->id,     // ✅ required by DB
    'sender_type' => 'system',
    'type'        => 'system',
    'body'        => '',             // ✅ required by DB
    'meta'        => [
        'event'      => 'manager_requested',
        'agent_id'   => $staff->id,
        'agent_name' => trim(($staff->first_name ?? '').' '.($staff->last_name ?? '')),
    ],
]);


    return back()->with('ok', 'Manager has been requested. The user will be updated shortly.');
}

  /* =========================================================
   * AUTO ASSIGN ENGINE
   * ======================================================= */
  private function autoAssignUnassignedConversations(): void
  {
    DB::transaction(function () {

      $convs = SupportConversation::whereNull('assigned_admin_id')
        ->where('status','open')
        ->whereNull('manager_requested_at')
        ->orderBy('last_message_at')
        ->limit(20)
        ->lockForUpdate()
        ->get();

      if ($convs->isEmpty()) return;

      $admins = DB::table('users')
        ->where('role','admin')
        ->where('support_status','available')
        ->lockForUpdate()
        ->get(['id','first_name','last_name','email']);

      if ($admins->isEmpty()) return;

     $counts = SupportConversation::where('status', 'open')
  ->whereNotNull('assigned_admin_id')
  ->whereNull('manager_joined_at') // don't count if manager took over
  ->select('assigned_admin_id', DB::raw('COUNT(*) cnt'))
  ->groupBy('assigned_admin_id')
  ->pluck('cnt', 'assigned_admin_id')
  ->toArray();


      $load=[];
      foreach ($admins as $a) $load[$a->id]=(int)($counts[$a->id]??0);

      foreach ($convs as $c) {
       $pick = collect($load)->filter(fn($v)=>$v < 3)->sort()->keys()->first();

        if (!$pick) break;

        if (
          SupportConversation::where('id',$c->id)
            ->whereNull('assigned_admin_id')
         ->update(['assigned_admin_id'=>$pick])

        ) {
          $load[$pick]++;

        $a = $admins->firstWhere('id', $pick);
$adminName = trim(($a->first_name ?? '').' '.($a->last_name ?? '')) ?: $a->email;

SupportMessage::create([
  'support_conversation_id' => $c->id,
  'sender_id'   => $pick,
  'sender_type' => 'system',
  'type'        => 'system',
  'body'        => '',
  'meta'        => [
    'event'      => 'admin_assign',
    'admin_id'   => $pick,
    'admin_name' => $adminName,
  ],
]);


        }
      }
    });
  }

  /* =========================================================
   * HELPERS
   * ======================================================= */
  private function staffOrFail()
  {
    $u=auth()->user();
    abort_unless($u && in_array($u->role,['admin','manager','superadmin'],true),403);
    return $u;
  }
  private function isAgent($u): bool { return in_array($u->role,['admin','superadmin'],true); }
  private function isManager($u): bool { return in_array($u->role,['manager','superadmin'],true); }

 private function abortIfNoAccess($staff, SupportConversation $c): void
{
    // ✅ All staff can view all chats
    abort_unless(in_array($staff->role, ['admin','manager','superadmin'], true), 403);
}



public function storeMessage(Request $request, SupportConversation $conversation)
{
    $staff = $this->staffOrFail();

    abort_unless($conversation->status === 'open', 403);

    $superOverride = ($staff->role === 'superadmin');

    $isAssignedAdmin = $conversation->assigned_admin_id
    && (int)$conversation->assigned_admin_id === (int)$staff->id;

$managerActive = $conversation->manager_joined_at && !$conversation->manager_ended_at;

$isActiveManager =
    $conversation->manager_id
    && (int)$conversation->manager_id === (int)$staff->id
    && $conversation->manager_joined_at
    && !$conversation->manager_ended_at;

$superOverride = ($staff->role === 'superadmin');

abort_unless($conversation->status === 'open', 403);

// ✅ If manager is active, admin cannot reply (unless superadmin)
if ($staff->role === 'admin' && $managerActive && !$superOverride) {
    abort(403);
}

// ✅ allow reply by active manager OR assigned admin (when no manager active) OR superadmin
abort_unless(
    $superOverride || $isActiveManager || (!$managerActive && $isAssignedAdmin),
    403
);


    $data = $request->validate([
        'body' => ['required','string','max:5000'],
    ]);

    // IMPORTANT: use sender_type correctly
    $senderType = $staff->role === 'manager' ? 'manager' : 'admin';

    $msg = SupportMessage::create([
        'support_conversation_id' => $conversation->id,
        'sender_id'   => $staff->id,
        'sender_type' => $senderType,
        'type'        => 'message',
        'body'        => $data['body'],
    ]);

    $conversation->update(['last_message_at' => now()]);

    if ($request->expectsJson()) {
        return response()->json([
            'ok'   => true,
            'html' => view('support._message', [
                'msg' => $msg->load('sender'),
                'viewerIsAdmin' => true,
            ])->render(),
        ]);
    }

    return back()->with('ok', 'Sent');
}



  /* =========================================================
 * MANAGER JOIN
 * ======================================================= */
public function managerJoin(Request $request, SupportConversation $conversation)
{
    $staff = $this->staffOrFail();

    // only managers / superadmin
    abort_unless($this->isManager($staff), 403);

    // must be requested & open
    abort_unless(
        $conversation->manager_requested_at &&
        !$conversation->manager_joined_at &&
        $conversation->status === 'waiting_manager',
        403
    );

    DB::transaction(function () use ($conversation, $staff) {

        $conversation->update([
            'manager_id'        => $staff->id,
            'manager_joined_at' => now(),
            'status'            => 'open',
        ]);

        SupportMessage::create([
            'support_conversation_id' => $conversation->id,
            'sender_id'   => $staff->id,
            'sender_type' => 'system',
            'type'        => 'system',
            'body'        => '',
            'meta'        => [
                'event'        => 'manager_joined',
                'manager_id'   => $staff->id,
                'manager_name' => trim(($staff->first_name ?? '').' '.($staff->last_name ?? '')),
            ],
        ]);
    });

    return back()->with('ok', 'You have joined this conversation as manager.');
}




/* =========================================================
 * MANAGER END
 * ======================================================= */
public function managerEnd(Request $request, SupportConversation $conversation)
{
    $staff = $this->staffOrFail();

    abort_unless($this->isManager($staff), 403);

    abort_unless(
        (int)$conversation->manager_id === (int)$staff->id &&
        $conversation->manager_joined_at &&
        !$conversation->manager_ended_at,
        403
    );

    DB::transaction(function () use ($conversation, $staff) {

        $conversation->update([
           
            'manager_ended_at' => now(),

    'closed_at'        => now(),
    'closed_by'        => $staff->id,
    'closed_by_role'   => 'manager',

    'status'           => 'closed',
    'rating_required'  => 0,
        ]);

        SupportMessage::create([
            'support_conversation_id' => $conversation->id,
            'sender_id'   => $staff->id,
            'sender_type' => 'system',
            'type'        => 'system',
            'body'        => '',
            'meta'        => [
                'event'        => 'manager_ended',
                'manager_id'   => $staff->id,
                'manager_name' => trim(($staff->first_name ?? '').' '.($staff->last_name ?? '')),
            ],
        ]);
    });

    return back()->with('ok', 'Manager session ended.');
}


private function markReadForStaff($staff, SupportConversation $conversation): void
{
    $lastId = (int) ($conversation->messages()->max('id') ?? 0);
    if ($lastId <= 0) return;

    SupportConversationRead::updateOrCreate(
        ['support_conversation_id' => $conversation->id, 'admin_id' => $staff->id],
        ['last_read_message_id' => $lastId, 'last_read_at' => now()]
    );
}


public function adminEnd(Request $request, SupportConversation $conversation)
{
    $staff = $this->staffOrFail();

    $superOverride = ($staff->role === 'superadmin');
    $isAssignedAdmin = (int)$conversation->assigned_admin_id === (int)$staff->id;

    abort_unless($superOverride || $isAssignedAdmin, 403);

    // ✅ if manager joined, admin cannot end it
    abort_if($conversation->manager_joined_at, 403);

    abort_unless($conversation->status === 'open', 403);

    DB::transaction(function () use ($conversation, $staff) {
        $conversation->update([
            'closed_at'       => now(),
            'closed_by'       => $staff->id,
            'closed_by_role'  => 'admin',
            'status'          => 'closed',
            'rating_required' => 0,
        ]);

        SupportMessage::create([
            'support_conversation_id' => $conversation->id,
            'sender_id'   => $staff->id,
            'sender_type' => 'system',
            'type'        => 'system',
            'body'        => '',
            'meta'        => [
                'event'      => 'admin_ended',
                'admin_id'   => $staff->id,
                'admin_name' => trim(($staff->first_name ?? '').' '.($staff->last_name ?? '')),
            ],
        ]);
    });

    return back()->with('ok', 'Conversation ended. User must rate before starting a new chat.');
}



/* =========================================================
 * ADMIN RESOLVE (rating required)
 * - Assigned admin (or superadmin) can resolve ONLY if no manager active
 * ======================================================= */
public function adminResolve(Request $request, SupportConversation $conversation)
{
    $staff = $this->staffOrFail();

    $superOverride  = ($staff->role === 'superadmin');
    $isAssignedAdmin = (int)$conversation->assigned_admin_id === (int)$staff->id;

    // must be open to resolve
    abort_unless($conversation->status === 'open', 403);

    // if manager is active, admin cannot resolve (unless superadmin)
    $managerActive = $conversation->manager_joined_at && !$conversation->manager_ended_at;
    abort_if($managerActive && !$superOverride, 403);

    // only assigned admin or superadmin
    abort_unless($superOverride || $isAssignedAdmin, 403);

    DB::transaction(function () use ($conversation, $staff) {

        $conversation->update([
            'closed_at'       => now(),
            'closed_by'       => $staff->id,
            'closed_by_role'  => 'admin',

            // ✅ key: resolved + rating required
            'status'          => 'resolved',
            'rating_required' => 1,
        ]);

        SupportMessage::create([
            'support_conversation_id' => $conversation->id,
            'sender_id'   => $staff->id,
            'sender_type' => 'system',
            'type'        => 'system',
            'body'        => '',
            'meta'        => [
                'event'      => 'admin_resolved',
                'admin_id'   => $staff->id,
                'admin_name' => trim(($staff->first_name ?? '').' '.($staff->last_name ?? '')) ?: ($staff->email ?? 'Admin'),
            ],
        ]);
    });

    return back()->with('ok', 'Conversation resolved. User must rate before messaging again.');
}


/* =========================================================
 * MANAGER RESOLVE (rating required)
 * - Joined manager (or superadmin) resolves + ends manager session
 * ======================================================= */
public function managerResolve(Request $request, SupportConversation $conversation)
{
    $staff = $this->staffOrFail();

    abort_unless($this->isManager($staff), 403);

    $superOverride = ($staff->role === 'superadmin');

    $managerActive = $conversation->manager_id
        && $conversation->manager_joined_at
        && !$conversation->manager_ended_at;

    $isJoinedManager = $managerActive && (int)$conversation->manager_id === (int)$staff->id;

    // must be open to resolve
    abort_unless($conversation->status === 'open', 403);

    // only joined manager OR superadmin
    abort_unless($superOverride || $isJoinedManager, 403);

    DB::transaction(function () use ($conversation, $staff) {

        $conversation->update([
            // end manager session
            'manager_ended_at' => now(),

            'closed_at'        => now(),
            'closed_by'        => $staff->id,
            'closed_by_role'   => 'manager',

            // ✅ key: resolved + rating required
            'status'           => 'resolved',
            'rating_required'  => 1,
        ]);

        SupportMessage::create([
            'support_conversation_id' => $conversation->id,
            'sender_id'   => $staff->id,
            'sender_type' => 'system',
            'type'        => 'system',
            'body'        => '',
            'meta'        => [
                'event'        => 'manager_resolved',
                'manager_id'   => $staff->id,
                'manager_name' => trim(($staff->first_name ?? '').' '.($staff->last_name ?? '')) ?: ($staff->email ?? 'Manager'),
            ],
        ]);
    });

    return back()->with('ok', 'Conversation resolved. User must rate before messaging again.');
}



}
