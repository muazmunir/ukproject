<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Reservation;
use Illuminate\Http\Request;

class AdminBookingController extends Controller
{
    public function index(Request $request)
    {
        $tab = (string) $request->query('tab', 'all'); // all|completed|cancelled|refunded|partial
        $q   = trim((string) $request->query('q', ''));

        $query = Reservation::query()
            ->with([
                'service.coach',
                'client',
                'package',
            ])
            ->when($q !== '', function ($qq) use ($q) {
                $qq->where(function ($w) use ($q) {
                    if (ctype_digit($q)) {
                        $w->orWhere('id', (int)$q)
                          ->orWhere('client_id', (int)$q)
                          ->orWhere('coach_id', (int)$q);
                    }

                    $w->orWhereHas('client', fn ($c) => $c->where('name', 'like', "%{$q}%"))
                      ->orWhereHas('service.coach', fn ($c) => $c->where('name', 'like', "%{$q}%"))
                      ->orWhereHas('service', fn ($s) => $s->where('title', 'like', "%{$q}%"));
                });
            });

        // Tabs (adjust mappings to your exact statuses)
        switch ($tab) {
            case 'completed':
                $query->whereIn('status', ['completed']);
                break;

            case 'cancelled':
                $query->whereIn('status', ['cancelled', 'canceled']);
                break;

            case 'refunded':
                $query->whereIn('settlement_status', ['refunded']);
                break;

            case 'partial':
                $query->whereIn('settlement_status', ['refunded_partial']);
                break;

            case 'all':
            default:
                // no extra filter
                break;
        }

        $rows = $query
            ->orderByDesc('id')
            ->paginate(15)
            ->withQueryString();

        $counts = [
            'all'       => Reservation::count(),
            'completed' => Reservation::whereIn('status', ['completed'])->count(),
            'cancelled' => Reservation::whereIn('status', ['cancelled', 'canceled'])->count(),
            'refunded'  => Reservation::whereIn('settlement_status', ['refunded'])->count(),
            'partial'   => Reservation::whereIn('settlement_status', ['refunded_partial'])->count(),
        ];

        return view('admin.bookings.index', compact('rows', 'tab', 'q', 'counts'));
    }

public function show(Request $request, Reservation $reservation)
{
    $reservation->load([
        'service.coach',
        'client',
        'package',
        'slots',
        'payment',
    ]);

    $currency = $reservation->currency ?? 'USD';

    // Base amounts (truth from DB)
    $subtotal       = (int)($reservation->subtotal_minor ?? 0);        // service price
    $fees           = (int)($reservation->fees_minor ?? 0);            // service fee charged to client
    $total          = (int)($reservation->total_minor ?? 0);           // subtotal + fees
    $refundTotal    = (int)($reservation->refund_total_minor ?? 0);
    $platformEarned = (int)($reservation->platform_earned_minor ?? 0); // already includes commission/penalty based on rules

    $coachEarned   = (int)($reservation->coach_earned_minor ?? 0);     // payout (>=0)
    $coachPenalty  = (int)($reservation->coach_penalty_minor ?? 0);    // charged (>=0)
    $clientPenalty = (int)($reservation->client_penalty_minor ?? 0);

    $paymentStatus = (string)($reservation->payment_status ?? 'unpaid');

    $clientPaid    = ($paymentStatus === 'paid') ? $total : 0;
    $clientNetPaid = max(0, $clientPaid - $refundTotal);

    // Coach net (can be negative)
    $coachNet = $coachEarned - $coachPenalty;

    // Coach tax/commission ONLY when no penalty exists
    $coachCommission = ($coachPenalty === 0)
        ? max(0, $subtotal - $coachEarned)
        : 0;

    $finance = [
        'currency'           => $currency,

        'settlement_status'  => (string)($reservation->settlement_status ?? 'pending'),
        'payment_status'     => $paymentStatus,
        'status'             => (string)($reservation->status ?? ''),

        // base
        'subtotal_minor'     => $subtotal,
        'fees_minor'         => $fees,
        'total_minor'        => $total,
        'refund_total_minor' => $refundTotal,

        // client
        'service_price_minor'    => $subtotal,
        'client_paid_minor'      => $clientPaid,
        'client_penalty_minor'   => $clientPenalty,
        'client_net_paid_minor'  => $clientNetPaid,
        'net_after_refund_minor' => $clientNetPaid, // keep your old blade key

        // coach
        'coach_earned_minor'     => $coachEarned,
        'coach_penalty_minor'    => $coachPenalty,
        'coach_net_minor'        => $coachNet,
        'coach_commission_minor' => $coachCommission, // ✅ NOW IT EXISTS
        'charged_to_coach_minor' => $coachPenalty,

        // platform (truth)
        'platform_earned_minor'  => $platformEarned,
        'zaivias_earned_minor'   => $platformEarned,
    ];

    return view('admin.bookings.show', compact('reservation', 'finance'));
}
}
