<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Carbon\CarbonImmutable;

use PayPalCheckoutSdk\Core\PayPalHttpClient;
use PayPalCheckoutSdk\Core\SandboxEnvironment;
use PayPalCheckoutSdk\Core\ProductionEnvironment;
use PayPalCheckoutSdk\Orders\OrdersCreateRequest;
use PayPalCheckoutSdk\Orders\OrdersCaptureRequest;

use App\Models\Service;
use App\Models\ServicePackage;
use App\Models\Reservation;
use App\Models\ReservationSlot;
use App\Models\Payment;
use App\Models\ServiceFee;
use Illuminate\Support\Facades\Mail;
use App\Mail\BookingConfirmedClientMail;
use App\Mail\BookingConfirmedCoachMail;
use App\Services\WalletService;
use App\Models\WalletTransaction;




class PayPalController extends Controller
{
    private PayPalHttpClient $client;

    public function __construct()
    {
        $clientId = config('services.paypal.client_id');
        $secret   = config('services.paypal.client_secret');
        $mode     = config('services.paypal.mode', 'sandbox');

        $env = $mode === 'live'
            ? new ProductionEnvironment($clientId, $secret)
            : new SandboxEnvironment($clientId, $secret);

        $this->client = new PayPalHttpClient($env);
    }

    /**
     * POST /paypal/create
     * Called from Confirm & Pay when payment_method = paypal
     */
    public function create(Request $request)
    {
        $data = $request->validate([
            'service_id'   => ['required','integer','exists:services,id'],
            'package_id'   => ['required','integer','exists:service_packages,id'],
            'client_tz'    => ['nullable','string'],
            'environment'  => ['nullable','string','max:120'],
            'note'         => ['nullable','string','max:2000'],
            'days'         => ['required','array','min:1'],
            'days.*.date'  => ['required','date_format:Y-m-d'],
            'days.*.start' => ['required','date'],
            'days.*.end'   => ['required','date'],
            'use_platform_credit' => ['nullable','boolean'],

        ]);

        $service  = Service::with('coach')->findOrFail($data['service_id']);
        $package  = ServicePackage::findOrFail($data['package_id']);
        $clientTz = $data['client_tz'] ?: config('app.timezone', 'UTC');

        // ---- same pricing as Stripe ----
      // ---- TOTAL HOURS (snapshot-safe) ----

// Case 1: package defines total hours (most packages)
if (!is_null($package->total_hours) && $package->total_hours > 0) {
    $totalHours = (float) $package->total_hours;
}

// Case 2: hourly service → compute from slots
else {
    $totalHours = 0.0;

    foreach ($data['days'] as $d) {
        $start = CarbonImmutable::parse($d['start']);
        $end   = CarbonImmutable::parse($d['end']);

        $minutes = $end->diffInRealMinutes($start, true);
        $totalHours += $minutes / 60;
    }

    $totalHours = round($totalHours, 2);
}


        $base = 0.0;
        if (!is_null($package->total_price) && $package->total_price > 0) {
            $base = (float) $package->total_price;
        } elseif (!is_null($package->hourly_rate) && $package->hourly_rate > 0) {
            $base = (float) $package->hourly_rate * $totalHours;
        }

        // ----- client commission (from service_fees) -----
        $clientFeeRow = ServiceFee::where('is_active', true)
            ->where(function ($q) {
                $q->where('party', 'client')
                  ->orWhere('slug', 'client_commission');
            })
            ->first();

        $fees = 0.0;
        if ($clientFeeRow) {
            $fees = $clientFeeRow->type === 'percent'
                ? round($base * ((float) $clientFeeRow->amount / 100), 2)
                : round((float) $clientFeeRow->amount, 2);
        }

        $subtotal      = round($base, 2);              // 60.00
        $total         = round($subtotal + $fees, 2);   // 63.00
        $subtotalMinor = (int) round($subtotal * 100);  // 6000
        $feesMinor     = (int) round($fees * 100);      // 300
        $totalMinor    = (int) round($total * 100);     // 6300

        $usePlatform = (bool) $request->boolean('use_platform_credit');
$availPlatform = (int) (auth()->user()->platform_credit_minor ?? 0);

$walletUseMinor = $usePlatform ? min($availPlatform, $totalMinor) : 0;
$payableMinor   = max(0, $totalMinor - $walletUseMinor);

$fundingStatus = $walletUseMinor <= 0
    ? 'unfunded'
    : ($payableMinor > 0 ? 'partially_funded' : 'funded');


        try {
            // 1) Create reservation + slots
            $reservation = null;
           $walletHoldTxId = null;

DB::transaction(function () use (
    $data, $service, $package, $clientTz,
    $subtotalMinor, $feesMinor, $totalMinor, $totalHours,
    $walletUseMinor, $payableMinor, $fundingStatus,
    &$reservation, &$walletHoldTxId
) {
    $reservation = Reservation::create([
        'service_id'        => $service->id,
        'package_id'        => $package->id,
        'client_id'         => auth()->id(),
        'coach_id'          => $service->coach_id ?? null,
        'client_tz'         => $clientTz,
        'environment'       => $data['environment'] ?? null,
        'note'              => $data['note'] ?? null,

        // ✅ SPLIT FUNDING
        'wallet_platform_credit_used_minor' => $walletUseMinor,
        'payable_minor'                     => $payableMinor,
        'funding_status'                    => $fundingStatus,

        // ✅ SNAPSHOTS
        'service_title_snapshot' => $service->title,
        'package_name_snapshot'  => $package->name,
        'package_hourly_rate'    => $package->hourly_rate,
        'package_total_price'    => $package->total_price,
        'package_hours_per_day'  => $package->hours_per_day,
        'package_total_days'     => $package->total_days,
        'package_total_hours'    => $package->total_hours,

        // ✅ PRICING
        'currency'          => 'USD',
        'subtotal_minor'    => $subtotalMinor,
        'fees_minor'        => $feesMinor,
        'total_minor'       => $totalMinor,
        'total_hours'       => $totalHours,
        'priced_at'         => now(),

        // ✅ STATE (important)
        'status' => ($payableMinor > 0 ? 'pending' : 'booked'),
        'payment_status' => ($payableMinor > 0 ? 'requires_payment' : 'paid'),
        'booked_at' => ($payableMinor > 0 ? null : now()),

        // provider set later if payable=0
        'provider' => ($payableMinor > 0 ? 'paypal' : 'wallet'),
    ]);

    // ✅ HOLD platform credit (only if used)
    if ($walletUseMinor > 0) {
        $walletHoldTxId = app(WalletService::class)->holdPlatformCredit(
            auth()->id(),
            $walletUseMinor,
            'reservation_hold',
            $reservation->id
        );
    }

    // slots
    foreach ($data['days'] as $d) {
        ReservationSlot::create([
            'reservation_id' => $reservation->id,
            'slot_date'      => $d['date'],
            'start_utc'      => CarbonImmutable::parse($d['start'])->utc(),
            'end_utc'        => CarbonImmutable::parse($d['end'])->utc(),
        ]);
    }
});

// ✅ If wallet covered everything, finalize now (NO PayPal)
if ($payableMinor <= 0) {
    if ($walletHoldTxId) {
        app(WalletService::class)->postHold($walletHoldTxId);
    }
    // ✅ create internal payment record for logging (wallet-only)
Payment::create([
    'reservation_id'        => $reservation->id,
    'provider'              => 'wallet',
    'provider_payment_id'   => 'wallet_'.$reservation->id,
    'method'                => 'wallet',
    'status'                => 'COMPLETED',
    'currency'              => 'USD',
    'amount_total'          => 0, // external charge = 0
    'service_subtotal_minor'=> $subtotalMinor,
    'client_fee_minor'      => $feesMinor,
    'platform_fee'          => $feesMinor,
    'provider_charge_id'    => null,
    'receipt_url'           => null,
    'meta'                  => ['wallet_used_minor' => $walletUseMinor],
    'succeeded_at'          => now(),
]);


    // Reservation already booked/paid in your transaction
    $this->sendBookingEmails($reservation);

    return redirect()->route('client.home', ['tab' => 'bookings'])
        ->with('success', 'Booking confirmed using your platform credit.');
}

            // 2) Create PayPal order
            $req = new OrdersCreateRequest();
            $req->prefer('return=representation');
            $req->body = [
                'intent'         => 'CAPTURE',
                'purchase_units' => [[
                    'reference_id' => (string) $reservation->id,
                    'custom_id'    => (string) $reservation->id,
                    'description'  => 'Zaivias booking for ' . $service->title,
                    'amount'       => [
                        'currency_code' => 'USD',
                      'value' => number_format($payableMinor / 100, 2, '.', ''),

                    ],
                ]],
                'application_context' => [
                    'brand_name'          => config('app.name', 'Zaivias'),
                    'landing_page'        => 'NO_PREFERENCE',
                    'user_action'         => 'PAY_NOW',
                    'shipping_preference' => 'NO_SHIPPING',
                    'return_url'          => route('paypal.success'),
                    'cancel_url'          => route('paypal.cancel'),
                ],
            ];

            $res     = $this->client->execute($req);
            $order   = $res->result;
            $orderId = $order->id ?? null;

            if (!$orderId) {
                throw new \RuntimeException('Could not create PayPal order.');
            }

            // 2b) store payment meta in payments table
         DB::transaction(function () use ($reservation, $orderId, $payableMinor, $subtotalMinor, $feesMinor, $order) 
 {
                $reservation->update([
                    'payment_intent_id' => $orderId,
                    'provider'          => 'paypal',
                ]);

                Payment::updateOrCreate(
                    [
                        'provider'            => 'paypal',
                        'provider_payment_id' => $orderId,
                    ],
                    [
                        'reservation_id'        => $reservation->id,
                        'method'                => 'paypal',
                        'status'                => $order->status ?? 'CREATED',
                        'currency'              => 'USD',
                       'amount_total' => $payableMinor,

                        'service_subtotal_minor'=> $subtotalMinor,
                        'client_fee_minor'      => $feesMinor,
                        // coach fee / earnings will be filled when escrow is released
                        'coach_fee_minor'       => 0,
                        'coach_earnings'        => 0,
                        // for now platform_fee = client_fee only
                        'platform_fee'          => $feesMinor,
                        'provider_charge_id'    => $orderId,
                        'receipt_url'           => null,
                        'meta'                  => null,
                    ]
                );
            });

            // 3) Redirect to approval link
            $approvalUrl = null;
            if (!empty($order->links)) {
                foreach ($order->links as $link) {
                    if ($link->rel === 'approve') {
                        $approvalUrl = $link->href;
                        break;
                    }
                }
            }

            if (!$approvalUrl) {
                throw new \RuntimeException('Could not get PayPal approval URL.');
            }

            return redirect()->away($approvalUrl);

        } catch (\Throwable $e) {
            Log::error('PayPalController@create failed', [
                'msg'   => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return back()->with('error', 'PayPal error: ' . $e->getMessage());
        }
    }

    /**
     * GET /paypal/success?token=<orderId>
     */
    public function success(Request $request)
    {
        $orderId = $request->query('token');
        if (!$orderId) {
            return redirect()->route('client.bookings.index')
                ->with('error', 'Missing PayPal order id.');
        }

        try {
            $captureReq = new OrdersCaptureRequest($orderId);
            $captureReq->prefer('return=representation');
            $res    = $this->client->execute($captureReq);
            $result = $res->result;

            $status = $result->status ?? 'UNKNOWN';
          $pu = $result->purchase_units[0] ?? null;

$capture   = $pu && !empty($pu->payments->captures[0]) ? $pu->payments->captures[0] : null;
$captureId = $capture->id ?? null;



            $reservationId = null;
            if ($pu) {
                if (!empty($pu->custom_id)) {
                    $reservationId = (int) $pu->custom_id;
                } elseif (!empty($pu->reference_id)) {
                    $reservationId = (int) $pu->reference_id;
                }
            }

          $amountValue  = null;
$currencyCode = 'USD';
if (!empty($capture?->amount)) {
    $amt          = $capture->amount;
    $amountValue  = isset($amt->value) ? (float) $amt->value : null;
    $currencyCode = $amt->currency_code ?? 'USD';
}


          DB::transaction(function () use ($orderId, $status, $reservationId, $amountValue, $currencyCode, $captureId) {

                $pay = Payment::where('provider', 'paypal')
                    ->where('provider_payment_id', $orderId)
                    ->lockForUpdate()
                    ->first();

                if (!$pay) {
                    $pay = new Payment([
                        'provider'            => 'paypal',
                        'provider_payment_id' => $orderId,
                    ]);
                }

                $reservation = $reservationId
                    ? Reservation::lockForUpdate()->find($reservationId)
                    : ($pay->reservation_id ? Reservation::lockForUpdate()->find($pay->reservation_id) : null);

              if ($reservation) {
    $isPaid = ($status === 'COMPLETED');

    $reservation->update([
        'status'           => $isPaid ? 'booked' : 'pending',  // ✅ THIS is the missing part
        'payment_status'   => $isPaid ? 'paid' : 'failed',
        'provider'         => 'paypal',
        'payment_intent_id'=> $orderId,
        'booked_at'        => $isPaid ? ($reservation->booked_at ?? now()) : $reservation->booked_at,
    ]);

    // ✅ finalize or release platform credit hold
$holdTx = WalletTransaction::where('reservation_id', $reservation->id)
    ->where('balance_type', WalletService::BAL_PLATFORM)
    ->where('type', 'debit')
    ->where('status', 'hold')
    ->lockForUpdate()
    ->first();

if ($isPaid) {
    if ($holdTx) app(WalletService::class)->postHold((int)$holdTx->id);
    $reservation->update(['funding_status' => 'funded']);
} else {
    if ($holdTx) app(WalletService::class)->reverseHold((int)$holdTx->id);
    $reservation->update(['funding_status' => 'unfunded']);
}

}


                $pay->reservation_id = $reservation ? $reservation->id : $pay->reservation_id;
                // ✅ fallback: if reservation still not loaded but payment has it
if (!$reservation && $pay->reservation_id) {
    $reservation = Reservation::lockForUpdate()->find($pay->reservation_id);
}

                $pay->method         = 'paypal';
                $pay->status         = $status;
                $pay->currency       = strtoupper($currencyCode ?? 'USD');

                if ($amountValue !== null) {
                    $pay->amount_total = (int) round($amountValue * 100);
                }

                if ($reservation) {
                    // keep payments table in sync with reservation breakdown
                    $pay->service_subtotal_minor = $reservation->subtotal_minor;
                    $pay->client_fee_minor       = $reservation->fees_minor;
                    // at this stage we still have no coach fee / earnings
                    $pay->platform_fee           = $reservation->fees_minor;
                }

                $pay->provider_charge_id = $orderId;
                $pay->provider_capture_id = $captureId; // ✅ needed for partial refunds later

                $pay->receipt_url        = null;
                $pay->succeeded_at       = $status === 'COMPLETED' ? now() : $pay->succeeded_at;
                $pay->meta               = null;

                $pay->save();
            });
            // ✅ Send booking emails (after booking is confirmed)
if ($status === 'COMPLETED' && $reservationId) {
    $reservation = Reservation::with(['slots','service','client','coach'])->find($reservationId);
    if ($reservation) {
        $this->sendBookingEmails($reservation);
    }
}


            $msg = $status === 'COMPLETED'
                ? 'PayPal payment completed successfully.'
                : 'We could not confirm the PayPal payment. Status: '.$status;

            return redirect()
                ->route('client.home', ['tab' => 'bookings'])
                ->with($status === 'COMPLETED' ? 'success' : 'error', $msg);

        } catch (\Throwable $e) {
            Log::error('PayPal capture error', [
                'msg'      => $e->getMessage(),
                'order_id' => $orderId,
            ]);

            return redirect()->route('client.bookings.index')
                ->with('error', 'We could not confirm the PayPal payment.');
        }
    }

    /**
     * GET /paypal/cancel
     */
    public function cancel(Request $request)
    {
        $token = $request->query('token'); // order id
        if ($token) {
            DB::transaction(function () use ($token) {
                $pay = Payment::where('provider', 'paypal')
                    ->where('provider_payment_id', $token)
                    ->lockForUpdate()
                    ->first();

                if ($pay) {
                    $pay->update(['status' => 'CANCELLED']);
                    if ($pay->reservation_id) {
                        Reservation::where('id', $pay->reservation_id)
    ->update([
        'payment_status' => 'failed',
        'funding_status' => 'unfunded',
    ]);

                    }
                    if ($pay->reservation_id) {
    $holdTx = WalletTransaction::where('reservation_id', $pay->reservation_id)
        ->where('balance_type', WalletService::BAL_PLATFORM)
        ->where('type', 'debit')
        ->where('status', 'hold')
        ->lockForUpdate()
        ->first();

    if ($holdTx) {
        app(WalletService::class)->reverseHold((int)$holdTx->id);
    }
}

                }
            });
        }

        return redirect()->route('client.bookings.index')
            ->with('error', 'You cancelled the PayPal payment.');
    }


    private function sendBookingEmails(Reservation $reservation): void
{
    $reservation->loadMissing(['slots','service','client','coach']);

    // only if booked+paid
    if ($reservation->status !== 'booked' || $reservation->payment_status !== 'paid') return;

    // ---- client timezone ----
    $clientTz = $reservation->client_tz ?: config('app.timezone','UTC');

    // ---- coach timezone ----
    $coachTz  = $reservation->coach?->timezone ?: config('app.timezone','UTC');

    $formatSlots = function(string $tz) use ($reservation) {
        return $reservation->slots
            ->sortBy('start_utc')
            ->map(function($slot) use ($tz){
                $start = CarbonImmutable::parse($slot->start_utc)->setTimezone($tz);
                $end   = CarbonImmutable::parse($slot->end_utc)->setTimezone($tz);

                return [
                    'date'  => $start->format('D, d M Y'),
                    'start' => $start->format('h:i A'),
                    'end'   => $end->format('h:i A'),
                ];
            })->values()->all();
    };

    // ✅ send client email once
    if (is_null($reservation->client_booking_emailed_at) && $reservation->client?->email) {
        $slotsClient = $formatSlots($clientTz);
        Mail::to($reservation->client->email)
            ->send(new BookingConfirmedClientMail($reservation, $slotsClient, $clientTz));

        $reservation->forceFill(['client_booking_emailed_at' => now()])->save();
    }

    // ✅ send coach email once
    if (is_null($reservation->coach_booking_emailed_at) && $reservation->coach?->email) {
        $slotsCoach = $formatSlots($coachTz);
        Mail::to($reservation->coach->email)
            ->send(new BookingConfirmedCoachMail($reservation, $slotsCoach, $coachTz));

        $reservation->forceFill(['coach_booking_emailed_at' => now()])->save();
    }
}

}
