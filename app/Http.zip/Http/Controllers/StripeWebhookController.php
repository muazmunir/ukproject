<?php

namespace App\Http\Controllers;

use App\Models\CoachPayoutMethod;
use Illuminate\Http\Request;
use Stripe\Webhook;

class StripeWebhookController extends Controller
{
    public function handle(Request $request)
    {
        $secret = config('services.stripe.webhook_secret');
        $payload = $request->getContent();
        $sig = $request->header('Stripe-Signature');

        try {
            $event = Webhook::constructEvent($payload, $sig, $secret);
        } catch (\Throwable $e) {
            return response('Invalid', 400);
        }

        if (($event->type ?? '') === 'account.updated') {
            $acct = $event->data->object ?? null;
            $acctId = $acct->id ?? null;

            if ($acctId) {
                // A simple rule:
                // active if charges/transfers allowed (Express payouts typically need transfers capability)
                $active = (bool)($acct->payouts_enabled ?? false);

                CoachPayoutMethod::where('type','stripe')
                    ->where('details->stripe_account_id', $acctId)
                    ->update(['status' => $active ? 'active' : 'pending']);
            }
        }

        return response('OK', 200);
    }
}
