<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Service;
use App\Models\Users;

class FavoritesController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();

        // Favorite services
       $favoriteServices = Service::whereHas('favorites', function ($q) use ($user) {
        $q->where('user_id', $user->id);
    })
    ->with([
        'coach:id,first_name,last_name,avatar_path,city,country',
        'favorites', // optional but fine
        'packages:id,service_id,total_price,hourly_rate', // ✅ REQUIRED for price_value
    ])
    ->paginate(9, ['*'], 'services_page');


        // Favorite coaches via relation on Users model
        $favoriteCoaches = $user->favoriteCoaches()
            ->paginate(9, ['*'], 'coaches_page');
foreach ($favoriteServices as $svc) {
    $svc->append(['price_value','price_unit','level_label','rating_value']);
}

        return view('favorites.index', compact('favoriteServices', 'favoriteCoaches'));
    }
}
