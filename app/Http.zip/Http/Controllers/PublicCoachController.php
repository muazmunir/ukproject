<?php

namespace App\Http\Controllers;

use App\Models\Users;
use App\Models\Service;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PublicCoachController extends Controller
{
    /**
     * Show public profile + services for a coach
     */
 public function show(Users $coach, Request $request)
{
    // make sure it really is a coach
    if ($coach->role !== 'coach' || ! $coach->is_approved) {
        abort(404);
    }

    // Load services for this coach
   $services = Service::query()
    ->active()                 // already ensures service is active
    ->where('coach_id', $coach->id)
    ->where('is_approved', 1)  // ✅ only approved services
    ->with([
        'category:id,name',
        'packages',
        'favorites',           // if you want heart toggle same like catalog
        'coach:id,first_name,last_name,avatar_path,city,country'
    ])
    ->withMin('packages', 'total_price')
    ->withMin('packages', 'hourly_rate')
    ->orderByDesc('created_at')
    ->paginate(9);             // you can change to ->take(9)->get() if you don’t want pagination

    // 🔹 read the setting from site_settings
    $showSocialProfiles = (bool) DB::table('site_settings')
        ->where('key', 'trainer_show_social_profiles')
        ->value('value');   // '0' or '1' → cast to bool

    return view('coaches.show', [
        'coach'              => $coach,
        'services'           => $services,
        'showSocialProfiles' => $showSocialProfiles,
    ]);
}

}
