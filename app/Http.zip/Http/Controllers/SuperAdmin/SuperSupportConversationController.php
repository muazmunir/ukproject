<?php

namespace App\Http\Controllers\Superadmin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

use App\Models\SupportConversation;
use App\Models\SupportMessage;
use App\Models\SupportConversationRating;
use App\Models\User;

class SuperSupportConversationController extends Controller
{
    /**
     * SuperAdmin inbox with filters + stats + agent leaderboard
     */
    public function index(Request $request)
    {
        // -------------------------------------------------
        // RANGE FILTER (manager escalation window)
        // -------------------------------------------------
        $range = (string) $request->query('range', 'monthly');
        $fromDate = $request->query('from');
        $toDate   = $request->query('to');

        $rangeStart = null;
        $rangeEnd   = now();

        switch ($range) {
            case 'daily':
                $rangeStart = now()->startOfDay();
                break;
            case 'weekly':
                $rangeStart = now()->startOfWeek();
                break;
            case 'monthly':
                $rangeStart = now()->startOfMonth();
                break;
            case 'yearly':
                $rangeStart = now()->startOfYear();
                break;
            case 'custom':
                $rangeStart = $fromDate ? Carbon::parse($fromDate)->startOfDay() : null;
                $rangeEnd   = $toDate   ? Carbon::parse($toDate)->endOfDay()     : now();
                break;
            case 'lifetime':
            default:
                $rangeStart = null;
        }

        // -------------------------------------------------
        // BASIC FILTERS
        // -------------------------------------------------
        $q      = (string) $request->query('q', '');
        $status = (string) $request->query('status', 'open');
        $role   = (string) $request->query('role', 'all');
        $per    = (int) $request->query('per', 10);
        $per    = in_array($per, [10,20,50,100], true) ? $per : 10;

        // -------------------------------------------------
        // CONVERSATIONS LIST
        // -------------------------------------------------
        $convsQuery = SupportConversation::query()
            ->with([
                'user:id,first_name,last_name,email',
                'assignedAdmin:id,first_name,last_name,email'
            ])
            ->when($status !== 'all', fn($q) => $q->where('status', $status))
            ->when($role !== 'all', function ($q) use ($role) {
                $q->where(function ($w) use ($role) {
                    $w->where('scope_role', $role)
                      ->orWhere('user_type', $role);
                });
            })
            ->when($q !== '', function ($q2) use ($q) {
                $q2->whereHas('user', function ($u) use ($q) {
                    $u->where('first_name', 'like', "%{$q}%")
                      ->orWhere('last_name', 'like', "%{$q}%")
                      ->orWhere('email', 'like', "%{$q}%");
                })->orWhere('id', $q);
            })
            ->orderByDesc(DB::raw('COALESCE(last_message_at, created_at)'));

        $convs = $convsQuery->paginate($per)->appends($request->query());

        // -------------------------------------------------
        // TOP STATS (NO DATE FILTER)
        // -------------------------------------------------
        $base = SupportConversation::query();

        $stats = [
            'open'            => (clone $base)->where('status', 'open')->count(),
            'closed'          => (clone $base)->where('status', 'closed')->count(),
            'unassigned_open' => (clone $base)->where('status', 'open')->whereNull('assigned_admin_id')->count(),
            'assigned_open'   => (clone $base)->where('status', 'open')->whereNotNull('assigned_admin_id')->count(),
            'manager_waiting' => (clone $base)->where('status', 'open')
                                              ->whereNotNull('manager_requested_at')
                                              ->whereNull('manager_joined_at')
                                              ->count(),
            'manager_active'  => (clone $base)->where('status', 'open')
                                              ->whereNotNull('manager_joined_at')
                                              ->whereNull('manager_ended_at')
                                              ->count(),
        ];

        // -------------------------------------------------
        // AGENT RATINGS (BASE)
        // -------------------------------------------------
        $agentRatings = SupportConversationRating::query()
            ->select([
                'admin_id',
                DB::raw('COUNT(*) as ratings_count'),
                DB::raw('AVG(stars) as avg_stars'),
                DB::raw('SUM(CASE WHEN stars = 5 THEN 1 ELSE 0 END) as five_star_count'),
            ])
            ->whereNotNull('admin_id')
            ->groupBy('admin_id');

        // -------------------------------------------------
        // MANAGER REQUEST COUNTS (FILTERED BY RANGE)
        // -------------------------------------------------
        $managerRequests = SupportConversation::query()
            ->select([
                'assigned_admin_id',
                DB::raw('COUNT(*) as manager_requests'),
            ])
            ->whereNotNull('assigned_admin_id')
            ->whereNotNull('manager_requested_at')
            ->when($rangeStart, fn($q) =>
                $q->whereBetween('manager_requested_at', [$rangeStart, $rangeEnd])
            )
            ->groupBy('assigned_admin_id');

        // -------------------------------------------------
        // FINAL LEADERBOARD
        // -------------------------------------------------
        $agentLeaderboard = DB::query()
            ->fromSub($agentRatings, 'r')
            ->join('users as u', 'u.id', '=', 'r.admin_id')
            ->leftJoinSub($managerRequests, 'm', function ($j) {
                $j->on('m.assigned_admin_id', '=', 'u.id');
            })
            ->whereIn(DB::raw('LOWER(COALESCE(u.role,""))'), ['admin','manager','super_admin'])
            ->select([
                'u.id',
                'u.first_name',
                'u.last_name',
                'u.email',
                'u.role',
                'r.ratings_count',
                'r.avg_stars',
                'r.five_star_count',
                DB::raw('CASE WHEN r.ratings_count > 0 THEN (r.five_star_count / r.ratings_count) * 100 ELSE 0 END as five_star_pct'),
                DB::raw('COALESCE(m.manager_requests, 0) as manager_requests'),
            ])
            ->orderByDesc('r.avg_stars')
            ->orderByDesc('r.ratings_count')
            ->limit(20)
            ->get();

        return view('superadmin.support.index', compact(
            'convs',
            'q','status','role','per',
            'stats',
            'agentLeaderboard',
            'range','fromDate','toDate'
        ));
    }

    /**
     * Show conversation (superadmin)
     */
    public function show(Request $request, SupportConversation $conversation)
    {
        $conversation->load([
            'user:id,first_name,last_name,email',
            'assignedAdmin:id,first_name,last_name,email,role',
            'manager:id,first_name,last_name,email,role',
        ]);

        $threadRole = in_array($conversation->scope_role ?? $conversation->user_type, ['client','coach'], true)
            ? ($conversation->scope_role ?? $conversation->user_type)
            : 'client';

        $otherConversation = SupportConversation::query()
            ->where('user_id', $conversation->user_id)
            ->where(function ($q) use ($threadRole) {
                $q->where('scope_role', $threadRole === 'coach' ? 'client' : 'coach')
                  ->orWhere('user_type', $threadRole === 'coach' ? 'client' : 'coach');
            })
            ->first();

        $events = collect();

        $messages = SupportMessage::query()
            ->where('conversation_id', $conversation->id)
            ->with('sender:id,first_name,last_name,email,role')
            ->orderBy('id')
            ->get();

        foreach ($messages as $m) {
            $events->push((object)[
                'type'  => 'message',
                'at'    => $m->created_at,
                'model' => $m,
            ]);
        }

        if ($conversation->assigned_admin_id && $conversation->assigned_at) {
            $events->push((object)[
                'type'  => 'admin_assign',
                'at'    => $conversation->assigned_at,
                'model' => $conversation->assignedAdmin,
            ]);
        }

        if ($conversation->manager_requested_at) {
            $events->push((object)[
                'type'  => 'manager_requested',
                'at'    => $conversation->manager_requested_at,
                'model' => $conversation->assignedAdmin,
            ]);
        }

        if ($conversation->manager_joined_at && $conversation->manager) {
            $events->push((object)[
                'type'  => 'manager_joined',
                'at'    => $conversation->manager_joined_at,
                'model' => $conversation->manager,
            ]);
        }

        if ($conversation->manager_ended_at && $conversation->manager) {
            $events->push((object)[
                'type'  => 'manager_ended',
                'at'    => $conversation->manager_ended_at,
                'model' => $conversation->manager,
            ]);
        }

        $ratings = SupportConversationRating::query()
            ->where('conversation_id', $conversation->id)
            ->with('admin:id,first_name,last_name,email')
            ->get();

        foreach ($ratings as $r) {
            $events->push((object)[
                'type'  => 'rating',
                'at'    => $r->created_at,
                'model' => $r,
            ]);
        }

        $events = $events->sortBy('at')->values();

        $adminTz = auth()->user()->timezone ?? config('app.timezone');

        return view('superadmin.support.show', compact(
            'conversation','events','adminTz','otherConversation'
        ));
    }
}
