<?php

namespace App\Http\Controllers\Superadmin;

use App\Http\Controllers\Controller;
use App\Models\StaffTeam;
use App\Models\StaffTeamMember;
use App\Models\StaffDmThread;
use App\Models\Users;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;


class StaffTeamController extends Controller
{
  private function managers()
  {
    return Users::query()->whereRaw('LOWER(role) = ?', ['manager'])->orderBy('username');
  }


  private function agentActiveTeamMap(): array
{
    $rows = StaffTeamMember::query()
        ->whereNull('end_at')
        ->with(['team.manager'])
        ->get();

    $map = [];

    foreach ($rows as $m) {
        if (!$m->team) continue;

        $map[$m->agent_id] = [
            'team_id'     => $m->team_id,
            'team_name'   => $m->team->name,
            'manager'     => $m->team->manager->username ?? $m->team->manager->name ?? 'Manager',
        ];
    }

    return $map;
}


  private function agents()
  {
    // your admin role represents agents
    return Users::query()->whereRaw('LOWER(role) IN ("admin","super_admin")')->orderBy('username');
  }

 public function index(Request $r)
{
    $q = StaffTeam::query()
        ->with(['manager','activeMembers.agent'])
        ->latest();

    // search by team name
    if ($s = trim((string)$r->get('q'))) {
        $q->where('name', 'like', "%{$s}%");
    }

    // filter by manager
    if ($mid = (int)$r->get('manager_id')) {
        $q->where('manager_id', $mid);
    }

    // status filter
    if (($status = $r->get('status')) !== null && $status !== '') {
        if ($status === 'active')   $q->where('is_active', true);
        if ($status === 'inactive') $q->where('is_active', false);
    }

    // optional: show deleted teams
    if ($r->boolean('trashed')) {
        $q->withTrashed();
    }

    $teams = $q->paginate(20)->appends($r->query());

    $managers = $this->managers()->get(); // reuse your method

    return view('superadmin.teams.index', compact('teams','managers'));
}


private function managerActiveTeamMap(): array
{
    $teams = StaffTeam::query()
        ->select('id','name','manager_id')
        ->where('is_active', true)
        ->whereNull('deleted_at') // if using SoftDeletes on StaffTeam
        ->get();

    $map = [];
    foreach ($teams as $t) {
        $map[$t->manager_id] = [
            'team_id'   => $t->id,
            'team_name' => $t->name,
        ];
    }

    return $map;
}



public function create()
{
    $managers = $this->managers()->get();
    $agents   = $this->agents()->get();

    $agentTeamMap   = $this->agentActiveTeamMap();
    $managerTeamMap = $this->managerActiveTeamMap(); // ✅ new

    return view('superadmin.teams.create', compact(
        'managers','agents','agentTeamMap','managerTeamMap'
    ));
}



  public function store(Request $r)
  {
   $r->validate([
  'name' => ['required','string','max:120'],
  'manager_id' => [
      'required',
      'exists:users,id',
      Rule::unique('staff_teams', 'manager_id')
          ->where(fn($q) => $q->where('is_active', true)->whereNull('deleted_at')),
  ],
  'agent_ids' => ['array'],
  'agent_ids.*' => ['integer','exists:users,id'],
]);


    DB::transaction(function () use ($r) {
      $team = StaffTeam::create([
        'name' => $r->name,
        'manager_id' => $r->manager_id,
        'is_active' => true,
      ]);

      $agentIds = array_values(array_unique($r->input('agent_ids', [])));

      foreach ($agentIds as $aid) {
        // end any previous active assignments for this agent
        StaffTeamMember::where('agent_id', $aid)->whereNull('end_at')->update(['end_at' => now()]);

        // assign into this team
        StaffTeamMember::create([
          'team_id' => $team->id,
          'agent_id' => $aid,
          'start_at' => now(),
        ]);

        // deactivate old threads for this agent (old manager)
        StaffDmThread::where('agent_id', $aid)->where('is_active', true)->update(['is_active' => false]);

        // ensure thread for (new manager, agent)
        StaffDmThread::firstOrCreate(
          ['manager_id' => $team->manager_id, 'agent_id' => $aid],
          ['is_active' => true]
        )->update(['is_active' => true]);
      }
    });

    return redirect()->route('superadmin.teams.index')->with('success','Team created.');
  }

  public function edit(StaffTeam $team)
{
    $team->load(['manager','activeMembers.agent']);

    $managers = $this->managers()->get();
    $agents   = $this->agents()->get();
    $selected = $team->activeMembers->pluck('agent_id')->all();

    $agentTeamMap   = $this->agentActiveTeamMap();
    $managerTeamMap = $this->managerActiveTeamMap(); // ✅ new

    return view('superadmin.teams.edit', compact(
        'team','managers','agents','selected','agentTeamMap','managerTeamMap'
    ));
}

  public function update(Request $r, StaffTeam $team)
  {
   $r->validate([
  'name' => ['required','string','max:120'],
  'manager_id' => [
      'required',
      'exists:users,id',
      Rule::unique('staff_teams', 'manager_id')
          ->ignore($team->id)
          ->where(fn($q) => $q->where('is_active', true)->whereNull('deleted_at')),
  ],
  'agent_ids' => ['array'],
  'agent_ids.*' => ['integer','exists:users,id'],
]);


    DB::transaction(function () use ($r, $team) {
      $oldManagerId = (int) $team->manager_id;

      $team->update([
        'name' => $r->name,
        'manager_id' => $r->manager_id,
      ]);

      $newAgentIds = array_values(array_unique($r->input('agent_ids', [])));
      $currentAgentIds = $team->activeMembers()->pluck('agent_id')->all();

      // remove agents (end assignments)
      $toRemove = array_diff($currentAgentIds, $newAgentIds);
      if ($toRemove) {
        StaffTeamMember::where('team_id', $team->id)
          ->whereIn('agent_id', $toRemove)
          ->whereNull('end_at')
          ->update(['end_at' => now()]);

        // if removed, deactivate their active thread with this manager
        StaffDmThread::where('manager_id', $oldManagerId)
          ->whereIn('agent_id', $toRemove)
          ->update(['is_active' => false]);
      }

      // add agents (new assignments)
      $toAdd = array_diff($newAgentIds, $currentAgentIds);
      foreach ($toAdd as $aid) {
        StaffTeamMember::where('agent_id', $aid)->whereNull('end_at')->update(['end_at' => now()]);

        StaffTeamMember::create([
          'team_id' => $team->id,
          'agent_id' => $aid,
          'start_at' => now(),
        ]);

        StaffDmThread::where('agent_id', $aid)->where('is_active', true)->update(['is_active' => false]);

        StaffDmThread::firstOrCreate(
          ['manager_id' => $team->manager_id, 'agent_id' => $aid],
          ['is_active' => true]
        )->update(['is_active' => true]);
      }

      // manager changed: deactivate threads with old manager for current members, activate with new manager
      if ($oldManagerId !== (int)$team->manager_id) {
        $still = $team->activeMembers()->pluck('agent_id')->all();

        StaffDmThread::where('manager_id', $oldManagerId)
          ->whereIn('agent_id', $still)
          ->update(['is_active' => false]);

        foreach ($still as $aid) {
          StaffDmThread::firstOrCreate(
            ['manager_id' => $team->manager_id, 'agent_id' => $aid],
            ['is_active' => true]
          )->update(['is_active' => true]);
        }
      }
    });

    return redirect()->route('superadmin.teams.index')->with('success','Team updated.');
  }


  public function destroy(StaffTeam $team)
{
    DB::transaction(function () use ($team) {

        // agents currently in this team
        $agentIds = $team->activeMembers()->pluck('agent_id')->all();

        // end active assignments
        if (!empty($agentIds)) {
            StaffTeamMember::where('team_id', $team->id)
                ->whereNull('end_at')
                ->update(['end_at' => now()]);

            // deactivate threads between this manager and these agents
            StaffDmThread::where('manager_id', $team->manager_id)
                ->whereIn('agent_id', $agentIds)
                ->update(['is_active' => false]);
        }

        // mark inactive and soft delete
        $team->update(['is_active' => false]);
        $team->delete();
    });

    return redirect()
        ->route('superadmin.teams.index')
        ->with('success', 'Team deleted (soft). Agents unassigned and threads deactivated.');
}

public function restore($id)
{
    $team = StaffTeam::withTrashed()->findOrFail($id);

    $team->restore();
    $team->update(['is_active' => true]);

    return redirect()
        ->route('superadmin.teams.index')
        ->with('success', 'Team restored.');
}

}
