<?php

namespace App\Http\Controllers\Superadmin;

use App\Http\Controllers\Controller;
use App\Models\Users;
use App\Services\SupportAgentStatusAnalyticsService;
use Illuminate\Http\Request;

class SupportAgentStatusAnalyticsSuperadminController extends Controller
{
    private function role(Request $request): string
    {
        return strtolower(trim((string) ($request->user()->role ?? '')));
    }

    private function abortUnlessSuperadmin(Request $request): void
    {
        abort_unless($this->role($request) === 'superadmin', 403);
    }

    /**
     * Superadmin can view BOTH admins and managers.
     */
    private function peopleQuery()
    {
        return Users::query()
            ->whereIn('role', ['admin', 'manager'])
            ->select('id','first_name','last_name','email','timezone','role','shift_enabled','shift_start','shift_end','shift_days')
            ->orderByRaw("FIELD(role, 'manager','admin')") // managers first (optional)
            ->orderBy('first_name')
            ->orderBy('last_name');
    }

    public function index(Request $request)
    {
        $this->abortUnlessSuperadmin($request);

        $people = $this->peopleQuery()->get();
        abort_unless($people->count() > 0, 404);

        $requestedTargetId = (int) $request->input('user_id', 0);
        $targetId = $requestedTargetId ?: (int) $people->first()->id;

       $target = Users::query()
    ->select(
        'id','first_name','last_name','email',
        'timezone','shift_enabled','shift_start','shift_end','shift_days','role'
    )
    ->findOrFail($targetId);


        return view('superadmin.support.status_analytics.index', [
            'people' => $people,
            'target' => $target,
        ]);
    }

    public function data(Request $request, SupportAgentStatusAnalyticsService $svc)
    {
        $this->abortUnlessSuperadmin($request);

        $range = strtolower((string) $request->input('range', 'weekly'));
        if (!in_array($range, ['daily','weekly','monthly','yearly','lifetime','custom'], true)) {
            return response()->json(['ok' => false, 'message' => 'Invalid range'], 422);
        }

        $targetId = (int) $request->input('user_id', 0);
        if (!$targetId) {
            return response()->json(['ok' => false, 'message' => 'Missing user_id'], 422);
        }

      $target = Users::query()
    ->select(
        'id','first_name','last_name','email',
        'timezone','shift_enabled','shift_start','shift_end','shift_days','role'
    )
    ->findOrFail($targetId);


        // Only allow admins/managers (superadmin can see both)
        abort_unless(in_array(strtolower((string)$target->role), ['admin','manager'], true), 403);

        // Force target timezone
        $displayTz = $target->timezone ?: 'UTC';
        try { new \DateTimeZone($displayTz); }
        catch (\Throwable $e) { $displayTz = 'UTC'; }

        $anchor = $request->input('anchor'); // YYYY-MM-DD
        $from   = $request->input('from');   // YYYY-MM-DD
        $to     = $request->input('to');     // YYYY-MM-DD

        if ($range !== 'lifetime' && $anchor) {
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$anchor)) {
                return response()->json(['ok' => false, 'message' => 'Invalid anchor date'], 422);
            }
        }

        if ($range === 'custom') {
            if ($from && !preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$from)) {
                return response()->json(['ok' => false, 'message' => 'Invalid from date'], 422);
            }
            if ($to && !preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$to)) {
                return response()->json(['ok' => false, 'message' => 'Invalid to date'], 422);
            }
        }

        $payload = $svc->buildForUser(
            (int) $target->id,
            $range,
            $displayTz,
            $anchor ? (string)$anchor : null,
            $from ? (string)$from : null,
            $to ? (string)$to : null
        );

        // Shift label
        $dayMap = [1=>'Mon',2=>'Tue',3=>'Wed',4=>'Thu',5=>'Fri',6=>'Sat',7=>'Sun'];

        $shiftEnabled = (bool) ($target->shift_enabled ?? false);
        $shiftStart   = $target->shift_start;
        $shiftEnd     = $target->shift_end;

        $days = $target->shift_days ?: [];
        if (is_string($days)) {
            $decoded = json_decode($days, true);
            $days = is_array($decoded) ? $decoded : [];
        }
        if (!is_array($days)) $days = [];

        $days = array_values(array_unique(array_map('intval', $days)));
        sort($days);

        if ($shiftEnabled) {
            $ss = $shiftStart ? substr((string)$shiftStart, 0, 5) : '—';
            $se = $shiftEnd   ? substr((string)$shiftEnd,   0, 5) : '—';
            $d  = $days
                ? implode(', ', array_map(fn($x) => $dayMap[$x] ?? (string)$x, $days))
                : '—';
            $shiftLabel = "{$d} • {$ss}–{$se}";
        } else {
            $shiftLabel = 'Shift Disabled';
        }

        $targetName = trim(($target->first_name.' '.$target->last_name));
if ($targetName === '') $targetName = $target->email;

        return response()->json([
            'ok'         => true,
            'range'      => $range,
            'user_id'    => (int)$target->id,
            'target_name' => $targetName,

            'display_tz' => $displayTz,
            'anchor'     => $anchor,
            'custom'     => ['from' => $from, 'to' => $to],
            'shift'      => [
                'enabled' => $shiftEnabled,
                'start'   => $shiftStart ? substr((string)$shiftStart, 0, 5) : null,
                'end'     => $shiftEnd   ? substr((string)$shiftEnd,   0, 5) : null,
                'days'    => $days,
                'label'   => $shiftLabel,
            ],
        ] + $payload);
    }
}
